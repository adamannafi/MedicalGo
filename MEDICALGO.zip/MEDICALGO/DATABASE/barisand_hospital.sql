-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 04, 2020 at 02:08 PM
-- Server version: 5.7.31-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `barisand_hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `bebanbiaya`
--

CREATE TABLE `bebanbiaya` (
  `idbeban` int(10) NOT NULL,
  `feeadmin` varchar(100) NOT NULL,
  `komisiafiliasi` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bebanbiaya`
--

INSERT INTO `bebanbiaya` (`idbeban`, `feeadmin`, `komisiafiliasi`) VALUES
(1, '5', '20');

-- --------------------------------------------------------

--
-- Table structure for table `infobank`
--

CREATE TABLE `infobank` (
  `idinfo` int(5) NOT NULL,
  `namabank` varchar(30) NOT NULL,
  `namaorang` varchar(100) NOT NULL,
  `norek` varchar(100) NOT NULL,
  `jambuka` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infobank`
--

INSERT INTO `infobank` (`idinfo`, `namabank`, `namaorang`, `norek`, `jambuka`) VALUES
(1, 'Mandiri', 'PT. Barisan', '122-200-9920', '0200200');

-- --------------------------------------------------------

--
-- Table structure for table `layanan`
--

CREATE TABLE `layanan` (
  `id_layanan` int(5) NOT NULL,
  `nama_layanan` varchar(30) NOT NULL,
  `keterangan_layanan` varchar(200) NOT NULL,
  `harga_layanan` varchar(30) NOT NULL,
  `picture` varchar(400) NOT NULL,
  `per` varchar(10) NOT NULL,
  `khusus` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `layanan`
--

INSERT INTO `layanan` (`id_layanan`, `nama_layanan`, `keterangan_layanan`, `harga_layanan`, `picture`, `per`, `khusus`) VALUES
(1, 'Mommy Massage', 'Layanan Terapis pijat untuk ibu hamil', '75000', 'hamil.png', '1', '50000'),
(11, 'Kids Massage', 'Layanan Pijat Terapi untuk Balita', '75000', 'kids.png', '1', '50000'),
(12, 'Baby Massage', 'Layanan Pijat Untuk bayi', '75000', 'baby-icon-6.png', '1', '50000'),
(14, 'Perawatan Pra/Pasca Kelahiran', 'Layanan untuk perawatan serta pendampingan pra/pasca kelahiran bayi', '200000', 'baby_pram_icon.png', '8', '100000'),
(15, 'Pijat Relaksasi', 'Layanan pijat untuk kesegaran badan, meringankan otot yang kaku karena banyaknya aktifitas', '75000', 'relaxa.png', '1', '50000'),
(16, 'Sihatsu Massage', 'Shiatsu adalah metode pijat yang berasal dari Jepang, yang melibatkan penggunaaan jari-jari untuk memijat tubuh pada titik-titik tertentu.', '100000', 'sihatsu.png', '1', '75000'),
(17, 'Terapi Refleksi', 'Refleksi Kaki dan Tangan pasien', '75000', 'refg.png', '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `liburnasional`
--

CREATE TABLE `liburnasional` (
  `id_liburan` int(5) NOT NULL,
  `tanggal_liburan` varchar(100) NOT NULL,
  `keterangan_liburan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `liburnasional`
--

INSERT INTO `liburnasional` (`id_liburan`, `tanggal_liburan`, `keterangan_liburan`) VALUES
(15, '2018-01-01', 'Tahun Baru Kalender Masehi 2018'),
(16, '2018-02-16', 'Tahun Baru imlek'),
(17, '2018-03-17', 'Hari Raya Nyepi'),
(18, '2018-03-30', 'Wafat isa Almasih'),
(19, '2018-04-14', 'Isra Mikraj Nabi Muhammad SAW'),
(20, '2018-05-01', 'Hari Buruh Internasional'),
(21, '2018-05-10', 'Kenaikan Isa Al Masih'),
(26, '2018-05-29', 'Hari Raya Waisak 2562'),
(27, '2018-06-01', 'Hari Lahir Pancasila'),
(28, '2018-06-15', 'Hari Raya Idul Fitri 1439 Hijriyah'),
(29, '2018-06-16', 'Hari Raya Idul Fitri 1439 Hijriyah'),
(30, '2018-08-17', 'Hari Kemerdekaan Republik Indonesia'),
(31, '2018-08-22', 'Hari Raya Idul Adha 1439 Hijriyah'),
(32, '2018-09-11', 'Tahun Baru Islam 1440 Hijriyah'),
(33, '2018-11-20', 'Maulid Nabi Muhammad SAW'),
(34, '2018-12-25', 'Hari Raya Natal'),
(35, '2018-12-24', 'Hari Raya Natal');

-- --------------------------------------------------------

--
-- Table structure for table `mitra`
--

CREATE TABLE `mitra` (
  `id_mitra` int(25) NOT NULL,
  `nama_mitra` varchar(200) NOT NULL,
  `foto_mitra` varchar(40) NOT NULL,
  `kelamin` varchar(40) NOT NULL,
  `tempatlahir` varchar(50) NOT NULL,
  `tgllahir` varchar(20) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `latmitra` varchar(25) NOT NULL,
  `lngmitra` varchar(25) NOT NULL,
  `nomorhp` varchar(20) NOT NULL,
  `no_ktp` varchar(33) NOT NULL,
  `mitra_email` varchar(70) NOT NULL,
  `mitra_pass` varchar(100) NOT NULL,
  `dokumen` varchar(100) NOT NULL,
  `nomor_hp2` varchar(40) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `alamatkantor` varchar(200) NOT NULL,
  `catatan` varchar(500) NOT NULL,
  `sebagai` varchar(30) NOT NULL,
  `referalmitra` varchar(40) NOT NULL,
  `tgldaftar` varchar(20) NOT NULL,
  `comission` varchar(20) NOT NULL,
  `signaturecode` varchar(100) NOT NULL,
  `gbrsignature` varchar(500) NOT NULL,
  `namadokumen` varchar(100) NOT NULL,
  `nomorsurat` varchar(100) NOT NULL,
  `saldo` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mitra`
--

INSERT INTO `mitra` (`id_mitra`, `nama_mitra`, `foto_mitra`, `kelamin`, `tempatlahir`, `tgllahir`, `alamat`, `latmitra`, `lngmitra`, `nomorhp`, `no_ktp`, `mitra_email`, `mitra_pass`, `dokumen`, `nomor_hp2`, `nik`, `alamatkantor`, `catatan`, `sebagai`, `referalmitra`, `tgldaftar`, `comission`, `signaturecode`, `gbrsignature`, `namadokumen`, `nomorsurat`, `saldo`) VALUES
(1, 'hospital', '2.jpg', 'Pria', '-', '-', '-', '-7.150975', '110.14025939999999', '089609715005', '3273231406650004', 'admin@hospital.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Admin', '08312121233', '311001111', 'Banyubiru blok O no 1 Bandung', '0', 'admin', '', '2017-07-11', '10', '0', '1', 'Amd Keb', '2010', '95000'),
(171, 'Perawat', '2.jpg', 'Pria', '-', '-', '-', '-7.150975', '110.14025939999999', '089609715005', '3273231406650004', 'perawat@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Terapis', '08312121233', '311001111', '-', '0', 'Medis', '', '2017-07-11', '10', '0', '1', '', '2010', '95000');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(255) NOT NULL,
  `art_id` int(255) NOT NULL,
  `total_votes` int(255) NOT NULL,
  `total_points` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `art_id`, `total_votes`, `total_points`) VALUES
(5, 1, 0, 0),
(6, 7, 10, 40),
(7, 21, 5, 17),
(8, 26, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sensor`
--

CREATE TABLE `sensor` (
  `id_sensor` int(25) NOT NULL,
  `nama_sensor` varchar(200) NOT NULL,
  `latsensor` varchar(50) NOT NULL,
  `lngsensor` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tarif`
--

CREATE TABLE `tarif` (
  `id_tarif` int(10) NOT NULL,
  `transportasi` int(10) NOT NULL,
  `makanan` int(10) NOT NULL,
  `paket` int(10) NOT NULL,
  `transportasimobil` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tarif`
--

INSERT INTO `tarif` (`id_tarif`, `transportasi`, `makanan`, `paket`, `transportasimobil`) VALUES
(1, 2000, 2, 2, 8);

-- --------------------------------------------------------

--
-- Table structure for table `tracking`
--

CREATE TABLE `tracking` (
  `idtracking` int(10) NOT NULL,
  `kodetrans` varchar(100) NOT NULL,
  `ip` varchar(200) NOT NULL,
  `hostname` varchar(300) NOT NULL,
  `city` varchar(200) NOT NULL,
  `region` varchar(200) NOT NULL,
  `country` varchar(200) NOT NULL,
  `loc` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tracking`
--

INSERT INTO `tracking` (`idtracking`, `kodetrans`, `ip`, `hostname`, `city`, `region`, `country`, `loc`) VALUES
(1, '56', '139.194.187.164', 'fm-dyn-139-194-187-164.fast.net.id', 'Surabaya', 'East Java', 'ID', '-7.2492,112.7510'),
(2, '47', '139.194.187.164', 'the host', 'Makassar', 'Sulawesi selatan', 'Indonesia', ''),
(3, '51', '139.194.187.164', 'localhost', 'Makassar', '', '', ''),
(4, '52', '139.194.187.164', 'localhost', 'Palu', '', '', ''),
(5, '53', '139.194.187.164', 'localhost', 'Makassar', '', '', ''),
(6, '54', '139.194.187.164', 'localhost', 'Palu', '', '', ''),
(7, '55', '139.194.187.164', 'localhost', 'Ujung pandang', '', '', ''),
(8, '57', '182.1.188.52', '', '', '', 'ID', '-6.1750,106.8290'),
(9, '57', '182.1.188.52', '', '', '', 'ID', '-6.1750,106.8290'),
(10, '62', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(11, '63', '114.125.214.120', '', 'Samarinda', 'East Kalimantan', 'ID', '-0.4917,117.1460'),
(12, '65', '114.125.214.120', '', 'Samarinda', 'East Kalimantan', 'ID', '-0.4917,117.1460'),
(13, '65', '114.125.214.120', '', 'Samarinda', 'East Kalimantan', 'ID', '-0.4917,117.1460'),
(14, '66', '114.125.214.120', '', 'Samarinda', 'East Kalimantan', 'ID', '-0.4917,117.1460'),
(15, '66', '114.125.214.120', '', 'Samarinda', 'East Kalimantan', 'ID', '-0.4917,117.1460'),
(16, '67', '139.194.187.164', 'fm-dyn-139-194-187-164.fast.net.id', 'Surabaya', 'East Java', 'ID', '-7.2492,112.7510'),
(17, '87', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(18, '88', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(19, '88', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(20, '90', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(21, '90', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(22, '91', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(23, '91', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(24, '', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(25, '', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(26, '', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(27, '91', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(28, '91', '36.79.158.135', '', 'Karanganyar', 'Central Java', 'ID', '-7.2939,109.5770'),
(29, '93', '114.125.184.212', '', 'Makassar', 'South Sulawesi', 'ID', '-5.1486,119.4320'),
(30, '93', '114.125.184.212', '', 'Makassar', 'South Sulawesi', 'ID', '-5.1486,119.4320'),
(31, '93', '114.125.184.212', '', 'Makassar', 'South Sulawesi', 'ID', '-5.1486,119.4320'),
(32, '113', '36.75.143.195', '', 'Gorontalo', 'Gorontalo', 'ID', '0.5375,123.0620'),
(33, '115', '36.75.143.195', '', 'Gorontalo', 'Gorontalo', 'ID', '0.5375,123.0620'),
(34, '117', '36.75.143.243', '', 'Gorontalo', 'Gorontalo', 'ID', '0.5375,123.0620'),
(35, '117', '36.75.143.243', '', 'Gorontalo', 'Gorontalo', 'ID', '0.5375,123.0620'),
(36, '120', '180.246.248.241', '', 'Surabaya', 'East Java', 'ID', '-7.2492,112.7510'),
(37, '121', '36.82.100.210', '', 'Surabaya', 'East Java', 'ID', '-7.2492,112.7510');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_trans` int(10) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `id_users` varchar(20) NOT NULL,
  `id_mitra` varchar(10) NOT NULL,
  `nama_rumah` varchar(30) NOT NULL,
  `keterangan` varchar(150) NOT NULL,
  `lat` varchar(90) NOT NULL,
  `lng` varchar(90) NOT NULL,
  `timepicker1` varchar(20) NOT NULL,
  `harga` varchar(40) NOT NULL,
  `status_trans` varchar(10) NOT NULL,
  `aktif` varchar(5) NOT NULL,
  `nomor` varchar(25) NOT NULL,
  `mitra_attach` varchar(500) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `online` varchar(15) NOT NULL,
  `layanan` varchar(50) NOT NULL,
  `deskripsi` varchar(400) NOT NULL,
  `invoice` varchar(50) NOT NULL,
  `foto_ktp` varchar(500) NOT NULL,
  `tgl_boking` varchar(20) NOT NULL,
  `per` varchar(10) NOT NULL,
  `tipebayar` varchar(50) NOT NULL,
  `testimoni` varchar(500) NOT NULL,
  `timestart` varchar(100) NOT NULL,
  `timeend` varchar(100) NOT NULL,
  `awal` varchar(20) NOT NULL,
  `transport` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_trans`, `tanggal`, `id_users`, `id_mitra`, `nama_rumah`, `keterangan`, `lat`, `lng`, `timepicker1`, `harga`, `status_trans`, `aktif`, `nomor`, `mitra_attach`, `alamat`, `online`, `layanan`, `deskripsi`, `invoice`, `foto_ktp`, `tgl_boking`, `per`, `tipebayar`, `testimoni`, `timestart`, `timeend`, `awal`, `transport`) VALUES
(99, '2020-09-26 07:29:32', '131', '143', 'Hidayat P', 'Pegal', '-6.9647142', '107.6633018', '08:01 AM', '77000', 'finish', 'no', '0818294547', '', 'banyubiru Blok o 1 bandung', 'read', 'Pijat Relaksasi', '0', 'R5VRCD', 'R5VRCDsignature (1).png', '', '1', 'cash', 'Layanan baik', '2020-09-26 08:12:06', '2020-09-26 09:12:06', '75000', '2000'),
(100, '2020-09-26 09:43:06', '131', '143', 'Hidayat P', 'Kaki bengka', '-6.9647141', '107.6633019', '09:51 AM', '77000', 'finish', 'no', '0818294547', '', 'banyubiru Blok o 1 bandung', 'read', 'Terapi Refleksi', '0', 'MHT5IDW', '', '', '1', 'cash', '', '2020-09-26 09:49:39', '2020-09-26 10:49:39', '75000', '2000'),
(101, '2020-09-26 09:43:06', '131', '143', 'Hidayat P', 'Kaki bengka', '-6.9647141', '107.6633019', '09:51 AM', '77000', 'finish', 'no', '0818294547', '', 'banyubiru Blok o 1 bandung', 'read', 'Terapi Refleksi', '0', 'MHT5IDW', '', '', '1', '0', '', '0', '0', '75000', '2000'),
(78, '2020-09-12 01:10:27', '74', '65', 'Hidayat Purwoputro', 'Pegal ', '-6.9646745', '107.6633471', '02:16 PM', '77000', 'finish', 'no', '0818294547', '', 'Jl banyubiru bklo o no 1', 'read', 'Terapi Refleksi', '0', '1IN8C3O2', '1IN8C3O2My-signature.jpg', '', '1', 'cash', 'Bagus', '2020-09-13 21:25:34', '2020-09-13 22:25:34', '75000', '2000'),
(93, '2020-09-16 09:48:02', '116', '103', 'Rahma Puji Anggraeni', 'Pusing', '-3.323159', '114.6038737', '09:48 PM', '77000', 'finish', 'no', '082210857601', '', 'Mercure Hotel', 'read', 'Pijat Relaksasi', '0', 'MGV6GXV4', '', '', '1', 'cash', 'Tengkyu', '2020-09-16 23:13:11', '2020-09-17 00:13:11', '75000', '2000');

-- --------------------------------------------------------

--
-- Table structure for table `trans_sopir`
--

CREATE TABLE `trans_sopir` (
  `idsaldo` int(10) NOT NULL,
  `idsopir` varchar(20) NOT NULL,
  `tipesaldo` varchar(20) NOT NULL,
  `jumlahsaldo` varchar(50) NOT NULL,
  `statussaldo` varchar(10) NOT NULL,
  `tgl_request` varchar(30) NOT NULL,
  `banksaldo` varchar(20) NOT NULL,
  `namauser` varchar(100) NOT NULL,
  `nomorrek` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trans_sopir`
--

INSERT INTO `trans_sopir` (`idsaldo`, `idsopir`, `tipesaldo`, `jumlahsaldo`, `statussaldo`, `tgl_request`, `banksaldo`, `namauser`, `nomorrek`) VALUES
(27, '58', 'topup', '300000', 'finish', '29-06-2020', 'BRI', 'pakjim', '2030490200'),
(28, '76', 'withdraw', '50000', 'dijemput', '05-09-2020', 'BCA', 'Yulianti', '6760407265');

-- --------------------------------------------------------

--
-- Table structure for table `trans_user`
--

CREATE TABLE `trans_user` (
  `idsaldo` int(10) NOT NULL,
  `id_users` varchar(20) NOT NULL,
  `tipesaldo` varchar(20) NOT NULL,
  `jumlahsaldo` varchar(50) NOT NULL,
  `statussaldo` varchar(10) NOT NULL,
  `tgl_request` varchar(30) NOT NULL,
  `banksaldo` varchar(20) NOT NULL,
  `namauser` varchar(100) NOT NULL,
  `nomorrek` varchar(25) NOT NULL,
  `id_trans` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trans_user`
--

INSERT INTO `trans_user` (`idsaldo`, `id_users`, `tipesaldo`, `jumlahsaldo`, `statussaldo`, `tgl_request`, `banksaldo`, `namauser`, `nomorrek`, `id_trans`) VALUES
(43, '45', 'topup', '109000', 'finish', '29-01-2020', 'BNI', 'pakjim tes', '03930939', '49'),
(45, '45', 'topup', '211000', 'finish', '19-06-2020', 'BRI', 'imam', '3333333212222', '60'),
(46, '143', 'deposit', '50000', 'minta', '25-09-2020', '0', '0', '0', '-'),
(47, '154', 'deposit', '100', 'minta', '02-10-2020', '0', '0', '0', '-');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `lat` varchar(40) NOT NULL,
  `lng` varchar(40) NOT NULL,
  `forgot_pass_identity` varchar(200) NOT NULL,
  `fotouser` varchar(500) NOT NULL,
  `modified` varchar(100) NOT NULL,
  `status` varchar(30) NOT NULL,
  `jeniskelamin` varchar(30) NOT NULL,
  `ktp` varchar(20) NOT NULL,
  `referal` varchar(20) NOT NULL,
  `userlahir` varchar(20) NOT NULL,
  `usertgllahir` varchar(30) NOT NULL,
  `useralamat` varchar(40) NOT NULL,
  `kunci` varchar(5) NOT NULL,
  `point` varchar(100) NOT NULL,
  `promohabis` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `email`, `password`, `phone`, `lat`, `lng`, `forgot_pass_identity`, `fotouser`, `modified`, `status`, `jeniskelamin`, `ktp`, `referal`, `userlahir`, `usertgllahir`, `useralamat`, `kunci`, `point`, `promohabis`) VALUES
(45, 'tes', 'tes@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '0813334343434', '-7.5360639', '112.2384017', '', '0', '0', '0', 'pria', '351000202222', '', 'Surabaya', '21 Februari 1983', 'Jl. margomulyo 12 Surabaya', '0', '1', '-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bebanbiaya`
--
ALTER TABLE `bebanbiaya`
  ADD PRIMARY KEY (`idbeban`);

--
-- Indexes for table `infobank`
--
ALTER TABLE `infobank`
  ADD PRIMARY KEY (`idinfo`);

--
-- Indexes for table `layanan`
--
ALTER TABLE `layanan`
  ADD PRIMARY KEY (`id_layanan`);

--
-- Indexes for table `liburnasional`
--
ALTER TABLE `liburnasional`
  ADD PRIMARY KEY (`id_liburan`);

--
-- Indexes for table `mitra`
--
ALTER TABLE `mitra`
  ADD PRIMARY KEY (`id_mitra`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sensor`
--
ALTER TABLE `sensor`
  ADD PRIMARY KEY (`id_sensor`);

--
-- Indexes for table `tracking`
--
ALTER TABLE `tracking`
  ADD PRIMARY KEY (`idtracking`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_trans`);

--
-- Indexes for table `trans_sopir`
--
ALTER TABLE `trans_sopir`
  ADD PRIMARY KEY (`idsaldo`);

--
-- Indexes for table `trans_user`
--
ALTER TABLE `trans_user`
  ADD PRIMARY KEY (`idsaldo`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bebanbiaya`
--
ALTER TABLE `bebanbiaya`
  MODIFY `idbeban` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `infobank`
--
ALTER TABLE `infobank`
  MODIFY `idinfo` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `layanan`
--
ALTER TABLE `layanan`
  MODIFY `id_layanan` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `liburnasional`
--
ALTER TABLE `liburnasional`
  MODIFY `id_liburan` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `mitra`
--
ALTER TABLE `mitra`
  MODIFY `id_mitra` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sensor`
--
ALTER TABLE `sensor`
  MODIFY `id_sensor` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `tracking`
--
ALTER TABLE `tracking`
  MODIFY `idtracking` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_trans` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `trans_sopir`
--
ALTER TABLE `trans_sopir`
  MODIFY `idsaldo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `trans_user`
--
ALTER TABLE `trans_user`
  MODIFY `idsaldo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
