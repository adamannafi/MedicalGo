<?php
//default time zone
date_default_timezone_set("Asia/Jakarta");
//fungsi check tanggal merah
function tanggalMerah($value) {
	$array=json_decode(file_get_contents("https://raw.githubusercontent.com/guangrei/Json-Indonesia-holidays/master/libur_nasional_apple.json"),true);
	//check tanggal merah berdasarkan libur nasional
	if(isset($array[$value]))
:		echo"tanggal merah $array[$value]";
	//check tanggal merah berdasarkan hari minggu
	elseif(
date("D",strtotime($value))==="Sun")
:		echo"tanggal merah hari libur";
	//bukan tanggal merah
	else
		:echo"bukan tanggal merah";
	endif;
}
//testing
$static_date=date("d-m-Y");
$dynamic_date=date("Ymd");
$bay = date('D', strtotime($static_date));
$bayList = array(
	'Sun' => 'Minggu',
	'Mon' => 'Senin',
	'Tue' => 'Selasa',
	'Wed' => 'Rabu',
	'Thu' => 'Kamis',
	'Fri' => 'Jumat',
	'Sat' => 'Sabtu'
);
echo"<h3>Check untuk hari ini '".$bayList[$bay]."' (".date("d-m-Y",strtotime($dynamic_date)).")</h3>";
tanggalMerah($dynamic_date);
echo "<br>";

?>