<link rel="stylesheet" href="../css/bemo.css">
<link rel="stylesheet" href="../dist/ladda.min.css">
<body style="font-family:Segoe UI;padding:20px;"><br>
<meta http-equiv="refresh" content="60">
<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: fdex.php#login");
}	
$res=mysql_query("SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
$id_mitra = $_SESSION['mitra'];
$view=mysql_query("SELECT * FROM transaksi where id_mitra='$id_mitra' and status_trans='dijemput'");
while($row=mysql_fetch_array($view)){
	?>
<?php 
if(count($_POST)>0) {
mysql_query("UPDATE transaksi set status_trans='otw' WHERE id_trans='" . $_POST["id_trans"] . "'");
header("Location: jemput.php");
}
?>

<br><center><small><b style="color:green">Menyetujui Layanan <?php echo $row["layanan"]; ?></b></small></center>
<br style="font-size:12px;color:#565656"><b><small>Kode Invoice :</small></b><br/><?php echo $row["invoice"]; ?>
<br style="font-size:12px;color:#565656"><b><small>Tanggal Request :</small></b><br/><?php echo $row['tanggal']; ?>
<br style="font-size:12px;color:#565656"><b><small>Keterangan Keluhan :</small></b><br/><?php echo $row['keterangan']; ?>
<br style="font-size:12px;color:#565656"><b><small>Atas Nama :</small></b><br/><?php echo $row['nama_rumah']; ?>
<br style="font-size:12px;color:#565656"><b><small>No. Handphone :</small></b><br/><?php echo $row['nomor']; ?>
<br style="font-size:12px;color:#565656"><b><small>Alamat Tujuan :</small></b><br/><?php echo $row['alamat']; ?>
<br style="font-size:12px;color:#565656"><b><small>Harga Layanan :</small></b><br/>Rp. <?php $awal = $row['awal'];$kapi = number_format($awal,0,",",".");echo $kapi; ?>
<br style="font-size:12px;color:#565656"><b><small>Tarif transport :</small></b><br/>Rp. <?php $transport = $row['transport'];$porti = number_format($transport,0,",",".");echo $porti; ?>
<br style="font-size:12px;color:#565656"><b><small>Status :</small></b><br/>Menunggu Pembayaran
<p>

<div class="mop"style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">
<b><small>Total Biaya: Rp. <?php echo $row['harga']; ?></small>
</b></div>
<label style="color:grey">Lokasi Alamat Pasien <?php echo $row['nama_rumah'];?> :
</label><iframe width="100%"height="250"frameborder="0"scrolling="yes"marginheight="0"marginwidth="0"src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=<?php echo $row['lat']?>,<?php echo $row['lng']?> (custom heading)&amp;output=embed"></iframe></p>


<small><label style="color:grey"><br>
<br> Yth. Mitra Medis, <br>Mohon menunggu Pasien menyelesaikan pembayaran <b>persiapkan beberapa perlengkapan yang dibutuhkan untuk terapi Pasien
<br>
<?php }?>

<?php 
$id_mitra = $_SESSION['mitra'];
$jim=mysql_query("SELECT * FROM transaksi where id_mitra='$id_mitra' and status_trans='otw'");
while($jow=mysql_fetch_array($jim)){
	?><br>
<br><center><small><b style="color:green">Menyetujui Layanan <?php echo $jow["layanan"]; ?></b></small></center>
<p>
<label style="color:#444">Alamat Pasien (Alamat <?php echo $jow['nama_rumah'];?>) :<br>
<?php echo $jow['alamat']; ?>
</label><br><br>
<small>Untuk menggunakan maps realtime klik Refresh map, atau more option pada peta untuk menggunakan Gmaps</small>
<iframe style="z-index:9999"width="100%" height="400" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/directions?origin=<?php echo $rows['latmitra']?>,<?php echo $rows['lngmitra']?>&amp;destination=<?php echo $jow['lat']?>,<?php echo $jow['lng']?>&amp;key=AIzaSyAO4lbxY6SKygcJxTuzu-Qi7kAAP9SdAwM" allowfullscreen="no"></iframe>
<br>
<script type="text/javascript"src="//maps.google.com/maps/api/js?sensor=true"></script>
<script>if(!navigator.geolocation){alert("Your phone does not support maps Location.")}navigator.geolocation.getCurrentPosition(success,error);function success(f){var g=f.coords.latitude;var e=f.coords.longitude;var h=f.coords.accuracy;document.getElementById("lat").value=g;document.getElementById("lng").value=e}function error(b){alert("Aktifkan GPS pada Smartphone anda!!!")};
</script>
<form id="form"action="mape.php" enctype="multipart/form-data"  method="post" name="postform">
<?php
$id_mitra = $_SESSION['mitra'];
$query=mysql_fetch_array(mysql_query("select * from mitra where id_mitra='$id_mitra'"));
$id_mitra=$query['id_mitra'];
	?>
<input type="hidden"name="lat"id="lat"/>
<input type="hidden"name="lng"id="lng"/>
<input type="hidden" name="id_mitra" value="<?php echo $id_mitra;?>"/>
<button style="border-radius:10px;border:0;background:green;color:#fff;" type="submit" name="kirim" /><center>Refresh Lokasi</center></button><br>
    </form>
</p>
<br style="font-size:12px;color:#565656"><b><small>Kode Invoice:</small></b><br/><?php echo $jow["invoice"]; ?>
<br style="font-size:12px;color:#565656"><b><small>Tanggal Request:</small></b><br/><?php echo $jow['tanggal']; ?>
<br style="font-size:12px;color:#565656"><b><small>Keterangan Keluhan:</small></b><br/><?php echo $jow['keterangan']; ?>
<br style="font-size:12px;color:#565656"><b><small>Atas Nama:</small></b><br/><?php echo $jow['nama_rumah']; ?>
<br style="font-size:12px;color:#565656"><b><small>No. Handphone:</small></b><br/><?php echo $jow['nomor']; ?>
<br style="font-size:12px;color:#565656"><b><small>Alamat Tujuan:</small></b><br/><?php echo $jow['alamat']; ?>
<br style="font-size:12px;color:#565656"><b><small>Tipe pembayaran:</small></b><br/>
<?php
$cash=$jow['tipebayar'];
if ($cash=='cash') { ?>
<small>Pasien memilih pembayaran cash, Medis bisa meminta pembayaran cash ke Pasien sesuai nominal layanan <br>Mohon tidak meminta uang tambahan kepada Pasien</small>
<?php } 
if ($cash=='point') {?>
<small>Pasien memilih pembayaran Point, 10 Point dari Pasien Akan ditambahkan dalam balance anda setelah layanan selesai <br>Mohon tidak meminta uang tambahan kepada Pasien</small>
<?php } 
if ($cash=='transfer') {?>
<small>Pasien memilih pembayaran Transfer, Pembayaran anda sudah diterima admin untuk diberikan kepada Medis <br>Mohon tidak meminta uang tambahan kepada Pasien</small>
<?php  } ?><br>
<br style="font-size:12px;color:#565656"><b><small>Harga Layanan :</small></b><br/>Rp. <?php $awal = $jow['awal'];$kapi = number_format($awal,0,",",".");echo $kapi; ?>
<br style="font-size:12px;color:#565656"><b><small>Tarif transport :</small></b><br/>Rp. <?php $transport = $jow['transport'];$porti = number_format($transport,0,",",".");echo $porti; ?><br>
<div class="mop"style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">
<b><small>Total Biaya: Rp. <?php echo $jow['harga']; ?> </small>
</b></div>
<?php 
$id_users=$jow['id_users'];
$bensult = mysql_query("SELECT * FROM users WHERE id='$id_users'");
$yup= mysql_fetch_array($bensult);
?>
<table width="100%" style="background: #fbfb41;padding: 10px;"><tr><td style="font-size:11px;color:#000;font-weight:bold"width="80%">
Hubungi Pasien: <?php echo $jow['nama_rumah'];?>: <br>
<?php echo $jow['alamat']; ?>, <?php echo $yup['phone']; ?>.<br>
</td><td width="20%">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<a href="http://hospital.barisandata.com/mitra/call.php?id_trans=<?php echo $jow['id_trans']; ?>" target="_blank"><center><i style="font-size:60px;color:green" class="fa fa-phone-square" aria-hidden="true"></i></a>
</td></tr></table>
<br>Silahkan Menuju ke alamat Pasien dan melayani request sesuai permintaan Pasien <br>
<br>Apabila Medis sudah sampai alamat Pasien dan akan mulai terapi, Medis bisa klik Mulai Terapi
<center>
<p><a href="finish.php?id_trans=<?php echo $jow['id_trans'] ?>">
<button class="ladda-button" data-color="blue" data-style="expand-right"><small>Mulai Terapi</small></button>
</a></p></center>
<?php }?>
<br></body>
<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.6.1.min.js"></script>		
<script type="text/javascript" src="autosave5/jquery-1.6.1.js"></script>		
	<script type="text/javascript">
	$(document).ready(function(){	
	
		autosave();
	});
	
	function autosave()
	{
		
		var t = setTimeout("autosave()", 5000);
		$('#timestamp').show(50).delay(8000);	
		var id = $("#id").val();
		var lat = $("#lat").val();
		var lng = $("#lng").val();
		
		if (lat.length > 0 || lng.length > 0)
		{
			$.ajax(
			{
				type: "POST",
				url: "autosave.php",
				data: "&id=" + id + "&lat=" + lat + "&lng=" + lng,
				cache: false,
				success: function(message)
				{	
					$('#timestamp').hide(50).delay(3000);
					$("#timestamp").empty().append(message);
				}
			});
		}
	} 
	</script>	
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=true"></script><br><br><br>
<script>if(!navigator.geolocation){alert("Your phone does not support maps Location.")}navigator.geolocation.getCurrentPosition(success,error);function success(c){var b=c.coords.latitude;var d=c.coords.longitude;var a=c.coords.accuracy;document.getElementById("lat").value=b;document.getElementById("lng").value=d}function error(a){}</script>
<form id="article_form" method="post" action="autosave.php">
<input type="hidden" id="id" name="id" value="<?php echo $rows['id_mitra'];?>" />
<input type="hidden" id="lat" type="float" name="lat"/>
<input type="hidden" id="lng" type="float" name="lng"/>
</form><br>