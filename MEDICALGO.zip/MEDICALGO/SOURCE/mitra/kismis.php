<link rel="stylesheet" href="../css/bemo.css">
<link rel="stylesheet" href="../dist/ladda.min.css">
<body style="padding:20px;"><br>
<meta http-equiv="refresh" content="60">
<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: fdex.php#login");
}	
$id_mitra = $_SESSION['mitra'];
	?>

<?php 
$id_mitra = $_SESSION['mitra'];
$jim=mysql_query("SELECT * FROM transaksi where id_mitra='$id_mitra' and status_trans='otw'");
while($jow=mysql_fetch_array($jim)){
	?><br>
<p>
<label style="color:grey">Lokasi Tujuan Antar:
</label><iframe width="100%"height="250"frameborder="0"scrolling="yes"marginheight="0"marginwidth="0"src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=<?php echo $jow['tujuan']?>(custom heading)&amp;output=embed"></iframe></p>
<p>
<div style="font-size:13px"><b><small>Permintaan <?php echo $jow["sekolah"]; ?></small></b><br>
<?php 
if($jow['sekolah']=='Cleaning Service')
      { ?>
<br>Upah tenaga kerja: IDR <?php echo $jow['price']; ?>
<br>Jam kerja: <?php echo $jow['jarak']; ?><br>
<br>Kriteria Cleaning Service: <?php echo $jow['keterangan']; ?>
<br>Alamat tujuan : <?php echo $jow['tujuan']; ?>.<br>
	  <?php } ?>
<?php 
if($jow['sekolah']=='Tukang')
      { ?>
<br>Upah Tukang: IDR <?php echo $jow['price']; ?>
<br>Jam kerja: <?php echo $jow['jarak']; ?><br>
<br>Alamat tujuan : <?php echo $jow['tujuan']; ?>.<br><br>
	  <?php } ?>	  
<?php 
if($jow['sekolah']=='Chemical Order')
      { ?>
Nama Chemical: <?php echo $jow['keterangan'];?><br>
Harga Satuan: <?php echo $jow['harga'];?><br>
Jumlah Order: <?php echo $jow['alamat'];?><br>
<br>Alamat tujuan kirim: <?php echo $jow['tujuan']; ?>.<br>
	  <?php } ?>
<?php 
if($jow['sekolah']=='Desain Interior')
      { ?>
Alamat Survei: <?php echo $jow['tujuan'];?><br>
Kecamatan: <?php echo $jow['alamat'];?><br>
Kota & Provinsi: <?php echo $jow['jarak'];?><br>
Keterangan: <br><?php echo $jow['keterangan']; ?>.<br>
	  <?php } ?>
Atas nama: <?php echo $jow['nama_rumah'];?><br>
Phone <?php echo $jow['nama_rumah']; ?> : <?php echo $jow['nomor']; ?>.<br>
</div>
<div class="mop"style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">
<b>Total Biaya: Rp. <?php echo $jow['price']; ?>
</b></div>

<br>Silahkan mengantarkan pesanan Customer ke lokasi Tujuan <b>apabila Sudah sampai lokasi tujuan, pastikan Medis menerima pembayaran dari customer sesuai nominal</b>
<br>Kemudian Medis  bisa klik selesai
<center>
<p><a href="finish.php?id_trans=<?php echo $jow['id_trans'] ?>">
<button class="ladda-button" data-color="blue" data-style="expand-right"><small>Selesai</small></button>
</a></p></center>
<?php }?>
<br></body>