<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT * FROM transaksi INNER JOIN mitra on transaksi.id_mitra=mitra.id_mitra");
?>
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>
<body style="font-family:Monospace;font-weight:bold;padding:10px;">
<table width="100%;background:#fff"><tr>
<td style="border-right:none;background:none;color:#444;">
<h3>Seluruh Data Transaksi Medical GO</h3>
Untuk Mencari data silahkan menggunakan kolom search.<br>
</td>
<td style="border-right:none;background:none">
<center><a href="print.php" target="_blank"><div style="background:green;width:200px" class="testbutton"><small>Print Seluruh data</small></div></a>
</center></td>
</tr></table>

		<table class="table table-bordered" style="font-size:12px;" id="dataTable" width="100%" cellspacing="0">
 <thead>
	<tr>
		<th>Tanggal <br>layanan</th>
		<th>Nama Pelanggan & Contact</th>
		<th>Medis</th>
		<th>Layanan</th>
		<th>Kode invoice</th>
		<th>Harga layanan</th>
		<th>Jarak</th>
		<th>Biaya transport</th>
		<th>Total Biaya</th>
		<th>Fee Medis</th>
		<th>10% Medical Go</th>
		<th> Tipe pembayaran </th>
		<th>-</th>
		<th>Navigasi</th>
	
	</tr> </thead>
	<?php 
	while($res = mysql_fetch_array($result)) {
		
	
$guy_rows = $res['harga']; 
$awal = $res['awal']; 
$deskripsi = $res['deskripsi']; 
$transport = $res['transport'];
$harga = number_format($guy_rows,0,",",".");

$bagian=10/100;
$cumi = $guy_rows*$bagian; 
$lspa = number_format($cumi,0,",",".");


$propmob= $guy_rows-$cumi;
$terapis = number_format($propmob,0,",",".");

		echo "<tr>";
		echo "<td>".$res['tanggal']."</td>";
		echo "<td><b>".$res['nama_rumah']."</b><br><br>".$res['alamat']."<br>".$res['nomor']."</td>";
		echo "<td><b>".$res['nama_mitra']."</b><br><br>".$res['nomorhp']."</td>";
		echo "<td><b>".$res['layanan']."</b><br><br>".$res['keterangan']."<br>Kunjungan jam: ".$res['timepicker1']."</td>";	
		echo "<td>".$res['invoice']."</td>";
		echo "<td style=font-weight:bold;color:grey> Rp.".$awal."</td>";
		echo "<td style=font-weight:bold;color:grey>".$deskripsi."Km</td>";
		echo "<td style=font-weight:bold;color:grey> Rp.".$transport."</td>";
		echo "<td style=font-weight:bold;color:grey> Rp.".$harga."</td>";
		echo "<td style=font-weight:bold;color:grey> Rp.".$terapis."</td>";
		echo "<td style=font-weight:bold;color:grey> Rp.".$lspa."</td>";
		echo "<td>".$res['tipebayar']."</td>";
		echo "<td> <a href=\"delete.php?id_trans=$res[id_trans]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";	
			echo "<td width=5%>";
	if($res['status_trans']=='finish')
      {
	
		echo "<a href=\"cetak.php?id_trans=$res[id_trans]\" style=font-weight:bold;color:green target=_blank><img src=printer.png width=30px/></a>";	
  }
  if($res['status_trans']=='dijemput')
      {
echo "<a href=\"layani.php?id_trans=$res[id_trans]\" style=font-weight:bold;color:green target=_blank>Konfirmasi pembayaran</a>";
  }
  if($res['status_trans']=='minta')   {
echo "Menunggu Medis...";		
		
  } 
  echo "</td>";
		
		}
	?>
	</table>

  <link href="../assets/bootstrap.min.css" rel="stylesheet">

    <link href="../assets/datatables.bootstrap4.min.css" rel="stylesheet">

    <!-- Bootstrap core JavaScript-->
    <script src="../assets/jquery.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../assets/jquery.datatables.min.js"></script>

    <script src="../assets/datatables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#dataTable').DataTable();
        });
    </script>

		<div style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">
<p><b><small>Seluruh Penghasilan</small></b></p>
<table width="100%"style="text-decoration:justify;border-bottom:1px solid #000;color:#000;">
<tr style="border-top:1px solid #000;border-bottom:1px solid #000"><td><b>Pembayaran yang sudah Diterima: </b></td><td>
<b> Rp. <?php
$query = "SELECT sum(harga) AS total FROM transaksi where status_trans='otw' or status_trans='finish'"; 
$result = mysql_query($query); 
$values = mysql_fetch_assoc($result); 
$num_rows = $values['total']; 
$laba = number_format($num_rows,0,",",".");
echo $laba;
 ?> ,-</b>
</td></tr><tr style="border-top:1px solid #000;border-bottom:1px solid #000"><td><b>Total Penghasilan Transaksi: </b></td><td>
<b> Rp. <?php
$query = "SELECT sum(harga) AS total FROM transaksi"; 
$result = mysql_query($query); 
$values = mysql_fetch_assoc($result); 
$num_rows = $values['total']; 
$laba = number_format($num_rows,0,",",".");
echo $laba;
 ?> ,-</b>
</td></tr>
</table>
</p>
<table width="100%;background:#fff"><tr>
<td style="border-right:none;background:none"><center>
<a href="harian.php" target="_blank"><div style="background:green;width:200px" class="testbutton"><small>Lihat Transaksi Harian</small></div></a>
</center></td>
<td style="border-right:none;background:none">
<center><a href="bulanan.php" target="_blank"><div style="background:green;width:200px" class="testbutton"><small>Lihat Transaksi bulanan</small></div></a>
</center></td>
<td style="border-right:none;background:none">
<center><a href="tahunan.php" target="_blank"><div style="background:green;width:200px" class="testbutton"><small>Lihat Transaksi Tahunan</small></div></a>
</center></td>
</tr></table>
</div>
</body>
</html>
