<?php
session_start();
include_once '../dbconnect.php';
$id_trans= $_GET["id_trans"];
$result = mysql_query("SELECT * FROM transaksi INNER JOIN users on transaksi.id_users=users.id where transaksi.id_trans='$id_trans'");
$row= mysql_fetch_array($result);
?><head><meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../../demo.css"/></head><body onload="window.print()" style="background: -moz-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* ff3.6+ */
background: -webkit-gradient(linear, left bottom, right top, color-stop(0%, rgba(168,252,255,1)), color-stop(100%, rgba(59,127,255,1))); /* safari4+,chrome */
background: -webkit-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* safari5.1+,chrome10+ */
background: -o-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* opera 11.10+ */
background: -ms-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* ie10+ */
background: linear-gradient(61deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* w3c */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#A8FCFF', endColorstr='#3B7FFF',GradientType=1 ); /* ie6-9 */" onkeydown="javascript:if(window.event.keyCode == 13) window.event.keyCode = 9;"><!--sodrops top bar-->
<div style="background: #fff;
    -webkit-box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
    box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
    display: block;
    margin: 0 auto;
    min-height: 0;
    width: 450px;padding:15px;color:#000"><br><br>
<small>Nota user: <?php echo $row['first_name']; ?></small><br><br>
<center><b style="color:green">Layanan <?php echo $row["layanan"]; ?></b></center>
<p style="font-size:12px;color:#565656"><b><small>Kode Invoice:</small></b><br/><?php echo $row["invoice"]; ?></p>
<p style="font-size:12px;color:#565656"><b><small>Tanggal Request:</small></b><br/><?php echo $row['tanggal']; ?></p>
<p style="font-size:12px;color:#565656"><b><small>Jenis Layanan:</small></b><br/><?php echo $row['layanan']; ?></p>
<p style="font-size:12px;color:#565656"><b><small>Keterangan Keluhan:</small></b><br/><?php echo $row['keterangan']; ?></p>
<p style="font-size:12px;color:#565656"><b><small>Atas Nama:</small></b><br/><?php echo $row['nama_rumah']; ?></p>
<p style="font-size:12px;color:#565656"><b><small>No. Handphone:</small></b><br/><?php echo $row['nomor']; ?></p>
<p style="font-size:12px;color:#565656"><b><small>Alamat Tujuan:</small></b><br/><?php echo $row['alamat']; ?></p>
<p style="font-size:12px;color:#565656"><b><small>Harga Layanan:</small></b><br/>Rp. <?php $awal = $row['awal'];$kapi = number_format($awal,0,",",".");echo $kapi; ?></p>
<p style="font-size:12px;color:#565656"><b><small>Biaya transport:</small></b><br/>Rp. <?php $transport = $row['transport'];$porti = number_format($transport,0,",",".");echo $porti; ?></p>
<p>
<div class="mop"style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">
<b>Total Biaya: Rp. <?php 
$layanan = $row['harga'];
$harga = number_format($layanan,0,",",".");
echo $harga;?> (LUNAS)
</b></div></p>

</td></tr>
<center>Click Ctrl+P untuk mencetak dengan printer</center></div>
</body>