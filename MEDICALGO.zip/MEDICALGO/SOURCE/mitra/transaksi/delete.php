<?php
//including the database connection file
include("config.php");

//getting id of the data from url
$id_trans = $_GET['id_trans'];

//deleting the row from table
$result = mysql_query("DELETE FROM transaksi WHERE id_trans=$id_trans");

//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>

