<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT * FROM transaksi");
?>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/> 
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>
<body style="padding:25px;"onload="window.print()"><center>
<h3>Data Transaksi Medical GO</h3></center>
<div id="content">
<table width='100%' border=0>

	<tr>
		<th>Tanggal <br>layanan</th>
		<th>Nama Pelanggan & Alamat</th>
		<th>Layanan</th>
		<th>Waktu kunjungan</th>
		<th>Deskripsi Keluhan</th>
		<th>Kode invoice</th>
		<th>Ponsel Pasien</th>
		<th>Total Biaya</th>
	</tr>
	<?php 
	while($res = mysql_fetch_array($result)) {
		
	
$guy_rows = $res['harga']; 
$harga = number_format($guy_rows,0,",",".");

$bagian=5/100;
$cumi = $guy_rows*$bagian; 
$pemilik = number_format($cumi,0,",",".");


$propmob= $guy_rows-$cumi;
$terapis = number_format($propmob,0,",",".");

		echo "<tr>";
		echo "<td>".$res['tanggal']."</td>";
		echo "<td><b>".$res['nama_rumah']."</b><br><br>".$res['alamat']."</td>";
echo "<td>".$res['layanan']."</td>";
echo "<td>".$res['timepicker1']."</td>";
		echo "<td>".$res['keterangan']."</td>";	
		echo "<td>".$res['invoice']."</td>";
		echo "<td>".$res['nomor']."</td>";
		echo "<td style=font-weight:bold;color:grey> Rp.".$harga."</td>";
		}
	?>
	</table>
		<div style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">
<p><b><small>Seluruh Penghasilan</small></b></p>
<table width="100%"style="text-decoration:justify;border-bottom:1px solid #000;color:#000;">
<tr style="border-top:1px solid #000;border-bottom:1px solid #000"><td><b>Pembayaran yang sudah Diterima: </b></td><td>
<b> Rp. <?php
$query = "SELECT sum(harga) AS total FROM transaksi where status_trans='otw' or status_trans='finish'"; 
$result = mysql_query($query); 
$values = mysql_fetch_assoc($result); 
$num_rows = $values['total']; 
$laba = number_format($num_rows,0,",",".");
echo $laba;
 ?> ,-</b>
</td></tr>
</table>
</p>
</div></div>
<div id="editor"></div>
</body>
</html>
<script>
var doc = new jsPDF();
var specialElementHandlers = {
    '#editor': function (element, renderer) {
        return true;
    }
};

$('#cmd').click(function () {
    doc.fromHTML($('#content').html(), 15, 15, {
        'width': 170,
            'elementHandlers': specialElementHandlers
    });
    doc.save('sample-file.pdf');
});
</script>
