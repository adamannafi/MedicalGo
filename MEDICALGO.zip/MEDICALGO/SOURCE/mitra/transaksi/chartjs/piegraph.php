<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/ilmudetil.css">
	<script src="assets/js/highcharts.js"></script>
	
	<script src="assets/js/jquery-1.10.1.min.js"></script>
	
	<script>
		var chart; 
		$(document).ready(function() {
			  chart = new Highcharts.Chart(
			  {
				  
				 chart: {
					renderTo: 'mygraph',
					plotBackgroundColor: null,
					plotBorderWidth: null,
					plotShadow: false
				 },   
				 title: {
					text: 'Statistik Peminat Kos'
				 },
				 tooltip: {
					formatter: function() {
						return '<b>'+
						this.point.name +'</b>: '+ Highcharts.numberFormat(this.percentage, 2) +' % ';
					}
				 },
				 
				
				 plotOptions: {
					pie: {
						allowPointSelect: true,
						cursor: 'pointer',
						dataLabels: {
							enabled: true,
							color: '#000000',
							connectorColor: 'green',
							formatter: function() 
							{
								return '<b>' + this.point.name + '</b>: ' + Highcharts.numberFormat(this.percentage, 2) +' % ';
							}
						}
					}
				 },
       
					series: [{
					type: 'pie',
					name: 'Browser share',
					data: [
					<?php
$con = mysqli_connect("localhost", "root", "root", "rento");
						$query = mysqli_query($con,"SELECT nama_barang FROM barang where pemilik='43'");
					 
						while ($row = mysqli_fetch_array($query)) {
							$kapasitas = $row['nama_barang'];
						 
							$data = mysqli_fetch_array(mysqli_query($con,"SELECT count(kapasitas) as total from barang inner join transaksi on barang.id_barang=transaksi.kapasitas where barang.nama_barang='$kapasitas'"));
							$jumlah = $data['total'];
							?>
							[ 
								'<?php echo $kapasitas ?>', <?php echo $jumlah; ?>
							],
							<?php
						}
						?>
			 
					]
				}]
			  });
		});	
	</script>
	
        
</head><center><div id ="mygraph" style="position: none;overflow: none;width: 600px;height: 250px;font-size:6px"></div></center>
			
<script src="assets/js/highcharts.js"></script>
<script src="assets/js/jquery-1.10.1.min.js"></script>