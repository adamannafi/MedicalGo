<html>
<body>
<?php
//including the database connection file
include_once("config.php");
if(isset($_POST['submit'])) {	
	$tanggal_liburan = $_POST['tanggal_liburan'];
	$keterangan_liburan = $_POST['keterangan_liburan'];
$result = mysql_query("INSERT INTO liburnasional(tanggal_liburan,keterangan_liburan) VALUES('$tanggal_liburan','$keterangan_liburan')");
header("Location:index.php");		//display success message
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='index.php'>View Result</a>";
	}
	
?>
</body>
</html>
