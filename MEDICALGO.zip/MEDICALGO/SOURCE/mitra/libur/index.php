<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT * FROM liburnasional");
?>
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>
<body><br><br>

<h3>Data Hari libur nasional</h3>
<a href="add.html"><div class="testbutton">Add New Data</div></a><br/>
Untuk reward Medis yang melayani pada hari libur nasional. Medis atau bidan akan mendapatkan tambahan 2 Point
	<table width='100%' border=0>

	<tr>
		<th>Tanggal Libur</th>
		<th>Keterangan Hari Libur</th>
<th>-</th>
<th>x</th>
	
	</tr>
	<?php 
	while($res = mysql_fetch_array($result)) { 		
		echo "<tr>";
		echo "<td>".$res['tanggal_liburan']."</td>";
		echo "<td>".$res['keterangan_liburan']."</td>";
		echo "<td> <a href=\"update.php?id_liburan=$res[id_liburan]\">Edit</a></td>";
echo "<td> <a href=\"delete.php?id_liburan=$res[id_liburan]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";				
	}
	?>
	</table>
</body>
</html>