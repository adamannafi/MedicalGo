<?php

$session_lifetime = 3600 * 24 * 860; // 2 days
session_set_cookie_params ($session_lifetime);
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	?>
<?php
}
if(isset($_POST['btn-login']))
{
	$mitra_email = mysql_real_escape_string($_POST['mitra_email']);
	$mitra_pass = mysql_real_escape_string($_POST['mitra_pass']);
	
	$mitra_email = trim($mitra_email);
	$mitra_pass = trim($mitra_pass);
	
	$res=mysql_query("SELECT id_mitra, mitra_email, mitra_pass FROM mitra WHERE mitra_email='$mitra_email'");
	$row=mysql_fetch_array($res);
	
	$count = mysql_num_rows($res); // if uname/pass correct it returns must be 1 row
	
	if($count == 1 && $row['mitra_pass']==md5($mitra_pass))
	{
		$_SESSION['mitra'] = $row['id_mitra'];
		header("Location: home.php#dashboard");
	}
	else
	{
		?><style>
#hideme {
    -webkit-animation: cssAnimation 15s forwards; 
    animation: cssAnimation 15s forwards;
}
@keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
@-webkit-keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
</style>
<div id="hideme"style="width:100%;position:relative;color:#ef2525;z-index:99999;top:0px;padding:20px;box-shadow:5px 2px 8px 1px rgba(0,0,0,0.15);background-color:rgba(255, 255, 82, 0.95)"><center>Email atau Password tidak cocok...
<br>
<br><center><b><a href="firli.php">Ulangi Login</a></b></center>
</div>
		<?php
	}
	
}
?><head><meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0"><link rel="stylesheet"type="text/css"href="../demo.css"/><link rel="stylesheet"href="../css/bemo.css"><link rel="stylesheet"href="../dist/ladda.min.css"></head>
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:#000;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:-50px;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#cari{display:none}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<body>
<br><br><br>
<div class="w3-container w3-center w3-animate-top">
<center><h3 style="color:#801900">Medical Go Medis</h3>
<img src="../logobig.png"width="200px"/>
<br><br></div>

<style>
::-webkit-input-placeholder { /* WebKit, Blink, Edge */
    color:    #ada7a7;
}
:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
   color:    #ada7a7;
   opacity:  1;
}
::-moz-placeholder { /* Mozilla Firefox 19+ */
   color:    #ada7a7;
   opacity:  1;
}
:-ms-input-placeholder { /* Internet Explorer 10-11 */
   color:    #ada7a7;
}
::-ms-input-placeholder { /* Microsoft Edge */
   color:    #ada7a7;
}
#input {
	color: #fff;
    position: relative;
    display: inline-block;
	width:100%
}

nav {
	position: absolute;
	content: '';
	height: 40px;
	height: 2px;
    background: #b10505;
    transition: all 0.2s linear;
    width: 0;
    bottom: 1px;  
}

input:hover ~ nav {
	width: 100%;
}
</style>
<link rel="stylesheet" href="../w3.css"><script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
<form id="form" method="post" style="width:100%">
<div id="input"><input style="color:#000;background: url(../email.png) no-repeat 12px;
    padding-left: 40px;
    vertical-align: middle;
    border-bottom: 1px solid #ada7a7;
    background-size: 20px;" type='text'name="mitra_email"class='holo'placeholder="Email" aria-required="true" required="required"/>
<nav></nav></div>
<br><br>
<style>
.field-icon {
  float: right;
  margin-right: 8px;
  margin-top: -23px;
  position: relative;
  z-index: 2;
  cursor:pointer;
}
</style>
<div id="input"><input id="password" style="color:#000;background:url(../password.png) no-repeat 12px;padding-left:40px;vertical-align:middle;border-bottom:1px solid #ada7a7;background-size:20px" type="password" name="mitra_pass"class='holo'placeholder="Password" aria-required="true" required="required"/>
<nav></nav></div><span style="color:grey" toggle="#toggle-password" id="eye" class="fa fa-lg fa-eye field-icon toggle-password"></span>
<br>
<script>
$(document).ready(function () {
        $("#eye").click(function () {
            if ($("#password").attr("type") === "password") {
                $("#password").attr("type", "text");
            } else {
                $("#password").attr("type", "password");
            }
        });
  });
</script>
<div style="float:right;padding:20px"><a href="loginregister/forgotPassword.php"style="color:#ada7a7" onclick="javascript:showDiv();"><small>Forgot password</small></a></div></p>
<br>
<section style="width:100%;padding:0"class="button-demo"><button style="background:#b10505;width: 90%;border-radius: 100px;height:auto"type="submit"name="btn-login"class="ladda-button"data-color="green"data-style="expand-right"><small>Sign In</small></button></section>
</form>
<div class="w3-container w3-center w3-animate-bottom">
<p><center>
<small><div style="color:#ada7a7;">Tidak memiliki Akun? <a style="color:#ada7a7" href="reg.php#kon"> Daftar Sekarang</a>
</small></div></p>
</center>
<script src="../dist/spin.min.js">
</script>
<script src="../dist/ladda.min.js">
</script></section>
<script>Ladda.bind(".button-demo button");Ladda.bind(".progress-demo button",{callback:function(a){var c=0;var b=setInterval(function(){c=Math.min(c+Math.random()*0.1,1);a.setProgress(c);if(c===1){a.stop();clearInterval(b)}},200)}});
</script></body>
<style>#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("../hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<div id="loading" style="display:none">
</div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>