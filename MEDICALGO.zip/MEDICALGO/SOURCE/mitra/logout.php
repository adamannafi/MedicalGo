<?php
session_start();
include "dbconnect.php";  
$id_mitra=$_SESSION['mitra'];

if(!isset($_SESSION['mitra']))
{
	header("Location: fdex.php#login");
}
else if(isset($_SESSION['user'])!="")
{
	header("Location: fdex.php#login");
}

if(isset($_GET['logout']))
{

	session_destroy();
	unset($_SESSION['mitra']);
	header("Location: fdex.php#login");
}
?>