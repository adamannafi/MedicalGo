<?php
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: firli.php#login");
}
$res=mysql_query("SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
?>	
<script type="text/javascript" src="autosave5/jquery-1.6.1.js"></script>		
	<script type="text/javascript">
	$(document).ready(function(){	
	
		autosave();
	});
	
	function autosave()
	{
		
		var t = setTimeout("autosave()", 5000);
		$('#timestamp').show(50).delay(8000);	
		var id = $("#id").val();
		var lat = $("#lat").val();
		var lng = $("#lng").val();
		
		if (lat.length > 0 || lng.length > 0)
		{
			$.ajax(
			{
				type: "POST",
				url: "autosave.php",
				data: "&id=" + id + "&lat=" + lat + "&lng=" + lng,
				cache: false,
				success: function(message)
				{	
					$('#timestamp').hide(50).delay(3000);
					$("#timestamp").empty().append(message);
				}
			});
		}
	} 
	</script>	
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=true"></script>
<script>if(!navigator.geolocation){alert("Your phone does not support maps Location.")}navigator.geolocation.getCurrentPosition(success,error);function success(c){var b=c.coords.latitude;var d=c.coords.longitude;var a=c.coords.accuracy;document.getElementById("lat").value=b;document.getElementById("lng").value=d}function error(a){}</script>
<form id="article_form" method="post" action="autosave.php">
<input type="hidden" id="id" name="id" value="<?php echo $rows['id_mitra'];?>" />
<input type="hidden" id="lat" type="float" name="lat"/>
<input type="hidden" id="lng" type="float" name="lng"/>
</form>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../demo.css"/>
<link rel="stylesheet"type="text/css"href="../w3.css"/>
<link rel="stylesheet"href="../css/bemo.css">
<link rel="stylesheet"href="../dist/ladda.min.css">
<div style="border-bottom:1px solid #8c8c8c;color:#616161;font-size:14px">Permintaan Baru
</div>
<center>
<div style="z-index:1;color:grey;font-size:18px;font-weight:bold">
</div>
</center>
<?php 
$view=mysql_query("SELECT * FROM transaksi where status_trans='minta'");
while($data=mysql_fetch_array($view)){
?>
<?php 
     
 if($data['aktif']=='yes')
      { ?>
<table style="margin-top:5px;width:100%">
<tr><td style="background-color:#f9f9f9;padding:15px;">
<div style="font-size:12px">
<b style="color:#444"><small>Request <?php echo $data["layanan"]; ?></small></b><br>
<table style="width:100%">
<tr style="font-size:12px;color:#565656"><td>Kode Invoice</td><td>:</td><td width="50%"> <?php echo $data['invoice']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Tanggal Request</td><td>:</td><td width="50%"> <?php echo $data['tanggal']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Waktu Kunjungan</td><td>:</td><td width="50%"> <?php echo $data['timepicker1']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Harga Layanan</td><td>:</td><td width="50%"> Rp.<?php 
$jika = $data['harga'];
$toto = number_format($jika,0,",",".");
echo $toto;?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Atas Nama</td><td>:</td><td width="50%"> <?php echo $data["nama_rumah"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Alamat</td><td>:</td><td width="50%"> <?php echo $data["alamat"]; ?></td></tr>

</table>

</div><br>
<script src="../dist/spin.min.js"></script>
<script src="../dist/ladda.min.js"></script>
<script>Ladda.bind(".button-demo button");Ladda.bind(".progress-demo button",{callback:function(b){var a=0;var c=setInterval(function(){a=Math.min(a+Math.random()*0.1,1);b.setProgress(a);if(a===1){b.stop();clearInterval(c)}},200)}});</script>
</p>

<center style="border-top: 2px solid #d8d8d8;border-bottom: 1px solid #afafaf;">
<a onclick="javascript:showDiv();" href="edit.php?id_trans=<?php echo $data["id_trans"]; ?>"><button style="z-index:9999;border-radius:50%;float:right;width:100px;font-size:12px;height:auto;margin-top:-25px;padding-bottom:20px;z-index:0"class="ladda-button"data-color="green">Layani</button></a>
</center>

</td>
</tr>
</table>
	  <?php  }     
	} ;
 ?>
 <style>#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
 <div id="loading" style="display:none"></div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>