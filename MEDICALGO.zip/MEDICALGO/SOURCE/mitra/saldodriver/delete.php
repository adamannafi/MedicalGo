<?php
//including the database connection file
include("config.php");

//getting id of the data from url
$id_saldo = $_GET['idsaldo'];

//deleting the row from table
$result = mysql_query("DELETE FROM trans_sopir WHERE idsaldo='$id_saldo'");

//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>

