<?php
session_start();
include_once '../dbconnect.php';
$idsaldo = $_GET["idsaldo"];
$result = mysql_query("SELECT id_mitra, idsopir, saldo, idsaldo, nama_mitra, tipesaldo, jumlahsaldo, statussaldo, tgl_request, banksaldo, namauser, nomorrek, nomorhp FROM trans_sopir INNER JOIN mitra on trans_sopir.idsopir=mitra.id_mitra where idsaldo='$idsaldo'");
$row= mysql_fetch_array($result);
if(isset($_POST['topup'])){
$saldo=$_POST['awal'];
$total=$_POST['jumlahsaldo'];
$pensaldoan=$saldo+$total;
mysql_query("UPDATE trans_sopir set statussaldo='finish' WHERE idsaldo='" . $_POST["idsaldo"] . "' and statussaldo='dijemput'");
mysql_query("UPDATE mitra set saldo='$pensaldoan' WHERE id_mitra='" . $_POST["id_mitra"] . "'");
header("Location: index.php"); }

if(isset($_POST['withdraw'])){
$bando=$_POST['awal'];
$bopang=$_POST['jumlahsaldo'];
$withdraw=$bando-$bopang;
mysql_query("UPDATE trans_sopir set statussaldo='finish' WHERE idsaldo='" . $_POST["idsaldo"] . "' and statussaldo='dijemput'");
mysql_query("UPDATE mitra set saldo='$withdraw' WHERE id_mitra='" . $_POST["id_mitra"] . "'");
header("Location: index.php"); }
?><head><meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../../demo.css"/></head><body style="background: -moz-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* ff3.6+ */
background: -webkit-gradient(linear, left bottom, right top, color-stop(0%, rgba(168,252,255,1)), color-stop(100%, rgba(59,127,255,1))); /* safari4+,chrome */
background: -webkit-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* safari5.1+,chrome10+ */
background: -o-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* opera 11.10+ */
background: -ms-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* ie10+ */
background: linear-gradient(61deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* w3c */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#A8FCFF', endColorstr='#3B7FFF',GradientType=1 ); /* ie6-9 */" onkeydown="javascript:if(window.event.keyCode == 13) window.event.keyCode = 9;"><!--sodrops top bar-->
<div style="background: #fff;
    -webkit-box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
    box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
    display: block;
    margin: 0 auto;
    min-height: 0;
    width: 450px;padding:15px;color:#000"><br><br>
<center><small><b>Request from <?php echo $row['nama_mitra']; ?></b></small><br><br>
<?php 
if($row['tipesaldo']=='topup')
      { ?> 
<b>Topup</b><br>
<table><br>
<tr style="font-size:12px;color:#565656"><td>Nota</td><td>:</td><td width="50%"> <?php echo $row['idsaldo']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>date<td>:</td><td width="50%"> <?php echo $row["tgl_request"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Nama user</td><td>:</td><td width="50%"> <?php echo $row['nama_mitra']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Jumlah Deposit</td><td>:</td><td width="50%">Rp. <?php
$nominal = $row['jumlahsaldo']; 
$jumlah = number_format($nominal,0,",",".");
echo $jumlah; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Atas Nama</td><td>:</td><td width="50%"> <?php echo $row['namauser']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Nama Bank</td><td>:</td><td width="50%"> <?php echo $row["banksaldo"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Nomor Rekening</td><td>:</td><td width="50%"> <?php echo $row["nomorrek"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>
<br><br>Tujuan Transfer:<br>
Nama Bank: <?php 
$her=mysql_query("SELECT * FROM infobank where idinfo='1'");
$mul=mysql_fetch_array($her);
echo $mul['namabank'];?><br>
Nomor Rekening: <?php echo $mul['norek'];?><br>
Atas Nama: <?php echo $mul['namaorang'];?><br><br>
Jika user <?php echo $row['first_name']; ?> Sudah melakukan pembayaran ke rekening admin kedai-Ku, Silahkan confirmation.

</td></tr>

</table>
<form name="frmUser"method="post"action="<?php echo $_SERVER['PHP_SELF']?>"><br><br>
<center>
<input type="hidden"name="jumlahsaldo" value="<?php echo $row['jumlahsaldo']; ?>">
<input type="hidden"name="awal" value="<?php echo $row['saldo']; ?>">
<input type="hidden"name="id_mitra" value="<?php echo $row['id_mitra']; ?>">
<input type="hidden"name="idsaldo" value="<?php echo $row['idsaldo']; ?>">
<p><button style="border:1px solid green;padding:4px;color:green;font-size:18px;"type="submit"name="topup"class="btnSubmit"> Confirmation</button></p><br>
</form>
	  <?php } ?>
	  <?php 
if($row['tipesaldo']=='withdraw')
      { ?>
<b>Withdraw</b><br>
<table><br>
<tr style="font-size:12px;color:#565656"><td>No</td><td>:</td><td width="50%"> <?php echo $row['idsaldo']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>date<td>:</td><td width="50%"> <?php echo $row["tgl_request"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Nama Mitra</td><td>:</td><td width="50%"> <?php echo $row['nama_mitra']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Jumlah Withdraw</td><td>:</td><td width="50%">Rp. <?php
$nominal = $row['jumlahsaldo']; 
$jumlah = number_format($nominal,0,",",".");
echo $jumlah; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Atas Nama</td><td>:</td><td width="50%"> <?php echo $row['namauser']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Nama Bank</td><td>:</td><td width="50%"> <?php echo $row["banksaldo"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Nomor Rekening</td><td>:</td><td width="50%"> <?php echo $row["nomorrek"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>
Jika Request withdraw Sudah ditransfer admin ke rekening <?php echo $row['nama_mitra']; ?>, Silahkan Klik confirm.
</td></tr>
</table>
<form name="frmUser"method="post"action="<?php echo $_SERVER['PHP_SELF']?>"><br><br>
<center>
<input type="hidden"name="jumlahsaldo" value="<?php echo $row['jumlahsaldo']; ?>">
<input type="hidden"name="awal" value="<?php echo $row['saldo']; ?>">
<input type="hidden"name="id_mitra" value="<?php echo $row['id_mitra']; ?>">
<input type="hidden"name="idsaldo" value="<?php echo $row['idsaldo']; ?>">
<p><button style="border:1px solid green;padding:4px;color:green;font-size:18px;"type="submit"name="withdraw"class="btnSubmit"> Confirm</button></p><br>
</form>
	  <?php } ?></center><br>
</center>
<p><a href="index.php"style="color:orange">Back</a>
</center></div>
</body>