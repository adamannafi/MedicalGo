<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT * from trans_sopir");
?>
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>
<body style="font-family:Monospace;">
<table width="100%;background:#fff"><tr>
<td style="border-right:none;background:none;color:grey"><center>
<h3>All request Medis</h3>
	</center></td>

</tr></table>
<table width='100%' border=0>

	<tr>
		<th>No</th>
		<th>Date request</th>
		<th>Name Partner</th>
		<th>Balance saat ini</th>
		<th>Phone</th>
		<th>Type Request</th>
<th>Nominal Request</th>
<th>Confirmation by admin</th>
		<th>Name bank</th>
		<th>Bank account name</th>
		<th>Nomor Rekening</th>
		<th>Navigation</th>
		<th>[x]</th>
	
	</tr>
	<?php 
	while($res = mysql_fetch_array($result)) {
$id_mitra=$res['idsopir'];

$sentinel = mysql_query("SELECT * from mitra where id_mitra='$id_mitra'");
$timen = mysql_fetch_array($sentinel);

$nominal = $res['jumlahsaldo']; 
$jumlah = number_format($nominal,0,",",".");
		echo "<tr>";
		echo "<td>".$res['idsaldo']."</td>";
		echo "<td>".$res['tgl_request']."</td>";
		echo "<td>".$timen['nama_mitra']."</td>";
		echo "<td>".$timen['saldo']."</td>";
		echo "<td>".$timen['nomorhp']."</td>";
		echo "<td>".$res['tipesaldo']."</td>";
		echo "<td>Rp.".$jumlah."</td>";	echo "<td width=5%>";
	if($res['statussaldo']=='dijemput')
      {
echo "Sudah Konfirmasi";		
		
  }echo "</td>";
		echo "<td>".$res['banksaldo']."</td>";
		echo "<td>".$res['namauser']."</td>";
		echo "<td>".$res['nomorrek']."</td>";
			echo "<td width=5%>";
	if($res['statussaldo']=='dijemput')
      {
echo "<a href=\"layani.php?idsaldo=$res[idsaldo]\" style=background:green;padding:10px;color:#fff>Confirmation</a>";		
		
  }
  if($res['statussaldo']=='finish')
      {
echo "Done";
  }
  if($res['statussaldo']=='minta')   {
echo "pending...";		
		
  }
	  
  echo "</td>";
	
echo "<td> <a href=\"delete.php?idsaldo=$res[idsaldo]\" onClick=\"return confirm('Are you sure you want to delete request?')\">Delete</a></td>";		
	
}
	?>
	</table>
</body>
</html>
