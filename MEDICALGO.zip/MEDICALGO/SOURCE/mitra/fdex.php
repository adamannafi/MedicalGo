<?php
$session_lifetime = 3600 * 24 * 860; // 2 days
session_set_cookie_params ($session_lifetime);
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	?>
<script>document.location.href="firli.php#login";
</script><?php
}
if(isset($_POST['btn-login']))
{
	$mitra_email = mysql_real_escape_string($_POST['mitra_email']);
	$mitra_pass = mysql_real_escape_string($_POST['mitra_pass']);
	
	$mitra_email = trim($mitra_email);
	$mitra_pass = trim($mitra_pass);
	
	$res=mysql_query("SELECT id_mitra, mitra_email, mitra_pass FROM mitra WHERE mitra_email='$mitra_email'");
	$row=mysql_fetch_array($res);
	
	$count = mysql_num_rows($res); // if uname/pass correct it returns must be 1 row
	
	if($count == 1 && $row['mitra_pass']==md5($mitra_pass))
	{
		$_SESSION['mitra'] = $row['id_mitra'];
		header("Location: fdex.php#jogin");
	}
	else
	{
		?><style>
#hideme {
    -webkit-animation: cssAnimation 15s forwards; 
    animation: cssAnimation 15s forwards;
}
@keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
@-webkit-keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
</style>
<div id="hideme"style="width:100%;position:relative;color:#ef2525;z-index:99999;top:0px;padding:20px;box-shadow:5px 2px 8px 1px rgba(0,0,0,0.15);background-color:rgba(255, 255, 82, 0.95)"><center>Email atau Password tidak cocok...
<br>
<br><center><b><a href="fdex.php#login">Ulangi Login</a></b></center>
</div>
		<?php
	}
	
}
?><head><meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0"><link rel="stylesheet"type="text/css"href="../demo.css"/><link rel="stylesheet"href="../css/bemo.css"><link rel="stylesheet"href="../dist/ladda.min.css"></head>
<body>
<div id="jogin"class="panel" style="border-radius:0;">
<div class="content"style="width:100%;right:0;left:0;padding-top:0px;border:none;">
<link rel="stylesheet" media="screen" href="../js/twitnotif.css">
<style>
        #notification_count {
			font-weight:bold
            padding: 4px;
            color: #ffffff;
            font-weight: bold;
            border-radius: 9px;
            -moz-border-radius: 9px;
            -webkit-border-radius: 9px;
            position: absolute;
            margin-top: -1px;
            font-size: 11px;
        }
    </style>

    <script src="../js/twitnotif2.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" charset="utf-8">
        function addmsg(type, msg) {

            $('#notification_count').html(msg);
        }

        function waitForMsg() {

            $.ajax({
                type: "GET",
                url: "../select.php",

                async: true,
                cache: false,
                timeout: 25000,

                success: function(data) {
                    addmsg("new", data);
                    setTimeout(
                        waitForMsg,
                        20000
                    );
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    addmsg("error", textStatus + " (" + errorThrown + ")");
                    setTimeout(
                        waitForMsg,
                        25000);
                }
            });
        };

        $(document).ready(function() {

            waitForMsg();

        });
    </script>

</head>
<body onload="getLocation()" >
<div class="sodrops-top" style="border-radius:0;">
<div id="HTMLnoti" style="border-radius:0;margin-left:20px;textalign:center"><a><img src="../notif.png"width="25px"/><span id="notification_count"></span></a></div>
<script src="../js/twitnotif3.js"></script>
<script src="../js/twitnotif4.js"></script>
<div style="color:#fff;margin-right:40px;margin-top:13px;font-size:18px;font-weight:bold"><center>Medical Go Mitra </center>
</div>
</div>
<center><br><br><br>
<?php
$res=mysql_query("SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
?>
<p></p>Hallo <?php echo $rows['nama_mitra']; ?>, <br><small>Silahkan pilih menu</small><br><br>
<p>
<table style="border:none">
  <tr style="padding:10px">
    <td ><a href="../simobil.php#home"style="color:#000;font-size:14px;font-weight:bold" ><img src="../sewamobil-min.png"style="padding:5px;max-width:85px;height:auto" onclick="javascript:showDiv();"/></a>
</td>
    <td ><a href="../simobil.php#home"style="color:#888;font-size:14px;font-weight:bold" onclick="javascript:showDiv();">Pemilik Kendaraan<br><small>Anda bisa menyewakan mobil <br>(Pickup, Truck Kecil, Truck Besar, MVP, city car, LCGC, Sedan, Bus, Box, dll)</small></a></td>
  </tr>
  <tr >
    <td ><a href="../pemilik.php#home" style="color:#000;font-size:14px;font-weight:bold"><img src="../sewarumah-min.png" style="padding:5px;max-width:85px;height:auto" onclick="javascript:showDiv();"/></a></td>
    <td ><a href="../pemilik.php#home" style="color:#888;font-size:14px;font-weight:bold" onclick="javascript:showDiv();" >Pemilik property<br><small>Anda bisa menyewakan kontrakan, kos, villa, Gudang, Ruko, apartemen dll</small></a></td>
  </tr>
  <tr>
    <td ><a href="#setting"><img src="../pengaturan-min.png"style="padding:5px;max-width:85px;height:auto" /></a></td>
    <td ><a href="#setting"style="color:#888;font-size:14px;font-weight:bold" >Setting<br><small>Pengaturan data profil anda</small></a></td>
 </tr>
  <tr>
    <td ><a href="#prosedur" style="color:#000;font-size:14px;font-weight:bold"><img src="../payment-min.png"style="padding:5px;max-width:85px;height:auto"/></a></td>
    <td ><a href="#prosedur"style="color:#888;font-size:14px;font-weight:bold">Prosedur pembayaran<br><small>Lihat Prosedur pembayaran di aplikasi Medical Go</small></a></td>
 </tr>
  <tr>
    <td ><a href="logoutmitra.php?logout" style="color:#000;font-size:14px;font-weight:bold"><img src="../logout-min.png"style="padding:5px;max-width:85px;height:auto"/></a></td>
    <td ><a href="logoutmitra.php?logout"style="color:#888;font-size:14px;font-weight:bold">Logout<br><small>Keluar akun, login dengan akun berbeda</small></a></td>
  </tr>
  
</table>
</p><br><br>
</div></div>
<div id="setting"class="panel">
<div class="content"><br>
<div style="border-bottom:1px solid #8c8c8c;color:#616161;font-size:14px">Setting Profile
</div><style>
#hideme {
    -webkit-animation: cssAnimation 15s forwards; 
    animation: cssAnimation 15s forwards;
}
@keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
@-webkit-keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
</style>
<?php if($rows['pengalaman']=='')
      { ?>
<div id="hideme"style="width:100%;position:relative;color:#ef2525;z-index:99999;top:0px;padding:20px;box-shadow:5px 2px 8px 1px rgba(0,0,0,0.15);background-color:rgba(255, 255, 82, 0.95)">
<center><small>Lengkapi Informasi Nama pemilik rekening atau rekening anda, untuk tujuan transfer pembeli</small>
<br></center>
</div><?php }else{ ?>
<?php } ?>
<form style="font-size:11px" id="form"action="save.php" enctype="multipart/form-data"  method="post" name="postform">
    <?php
include_once("dbconnect.php");
$id_mitra = $_SESSION['mitra'];
$query=mysql_fetch_array(mysql_query("select * from mitra where id_mitra='$id_mitra'"));
$id_mitra=$query['id_mitra'];
$nama_mitra = $query['nama_mitra'];
$mitra_email = $query['mitra_email'];
$kendaraan = $query['kendaraan'];
$nomorhp = $query['nomorhp'];
$no_ktp = $query['no_ktp'];
$pengalaman = $query['pengalaman'];
	?>
<input type="hidden" name="id_mitra" value="<?php echo $id_mitra;?>"/>
<br><br>
<table style="font-size:11px;color:#000;">
<tr>
<td>Nama </td>
<td><input type="text" name="nama_mitra"required="required" value="<?php echo $nama_mitra;?>"></td>
</tr>
<tr>
<td>Nomor KTP/ID </td>
<td><input type="text" name="no_ktp"required="required" value="<?php echo $no_ktp;?>"></td>
</tr>
<tr>
<tr>
<tr>
<td>Login Email </td>
<td><input type="email" name="mitra_email"required="required" value="<?php echo $mitra_email;?>"></td>
</tr>
<tr>
<td>Login Password </td>
<td><input type="password" name="mitra_pass" placeholder="isikan password!!"required="required" value=""></td>
</tr>
<tr>
<td>Nomor Handphone </td>
<td><input type="number" name="nomorhp"required="required" value="<?php echo $nomorhp;?>"></td>
</tr><tr><td>Alamat Rumah </td><td><input type="text" name="kendaraan"required="required" value="<?php echo $kendaraan;?>"></td></tr>
<tr><td>Nama Bank - Nomor Rekening</td><td><input type="text" name="pengalaman"required="required" value="<?php echo $pengalaman;?>"></td></tr>
	<tr>
      <td></td>
      <td><br><button style="width:200px;font-size:12px;height:auto;margin-top:-20px;padding-bottom:20px;"class="ladda-button"data-color="blue" type="submit" name="kirim">Simpan</button>
	  <br> 	</td>
     
    </tr>
    </table>
    
    </form>
<br><center><a href="firli.php"><img src="../back.png" width="20px"/><b> Kembali</b></a></center><br><br>
</div>
</div>

<div id="reg" class="panel"><div class="content" style="font-size:11px;padding:20px">
<h3>KEBIJAKAN PRIVASI</h3><br>
Kami di Aplikasi Medical Go menjaga privasi Anda dengan sangat serius. Kami percaya bahwa privasi elektronik sangat penting bagi keberhasilan berkelanjutan dari Internet. Kami percaya bahwa informasi ini hanya dan harus digunakan untuk membantu kami menyediakan layanan yang lebih baik. Itulah sebabnya kami telah menempatkan kebijakan untuk melindungi informasi pribadi Anda.
<br><br>
<h3>RINGKASAN KEBIJAKAN</h3>

Secara umum, Anda akan tetap sebagai anonim ketika Anda menggunakan Aplikasi web kami dan mengakses informasi. Sebelum kami meminta Anda untuk mengisi informasi, kami akan menjelaskan bagaimana informasi ini akan digunakan. Kami tidak akan memberikan informasi pribadi Anda kepada perusahaan lain atau individu tanpa se-izin Anda.

Beberapa bagian dari Aplikasi kami memerlukan pendaftaran untuk mengaksesnya, walaupun biasanya semua yang diminta adalah berupa alamat e-mail dan beberapa informasi dasar tentang Anda.

Ada bagian di mana kami akan meminta informasi tambahan. Kami melakukan ini untuk dapat lebih memahami kebutuhan Anda, dan memberikan Anda palayanan yang kami percaya mungkin berharga bagi Anda. Beberapa contoh informasi Aplikasi kami butuhkan seperti nama, email, alamat rumah, dan info pribadi. Kami memberikan Anda kesempatan untuk memilih untuk tidak menerima materi informasi dari kami.
<br><br>
<h3>PERLINDUNGAN PRIVASI</h3>

Kami akan mengambil langkah yang tepat untuk melindungi privasi Anda. Setiap kali Anda memberikan informasi yang sensitif (misalnya, nomor kartu kredit untuk melakukan pembelian), kami akan mengambil langkah-langkah yang wajar untuk melindungi, seperti enkripsi nomor kartu Anda. Kami juga akan mengambil langkah-langkah keamanan yang wajar untuk melindungi informasi pribadi Anda dalam penyimpanan. Nomor kartu kredit hanya digunakan untuk proses pembayaran dan bukan disimpan untuk tujuan pemasaran. Kami tidak akan memberikan informasi pribadi Anda kepada perusahaan lain atau individu tanpa izin Anda. "Proses order anda kami pastikan aman sebab dengan sistem pembayaran sewa langsung. pembayaran diterima oleh pemilik Mitra Kendaraan/property"
<br><br>
<h3>PENGGUNAAN COOKIE</h3>

Aplikasi ini menggunakan "cookies" untuk mengidentifikasi sesi pengguna pada Aplikasi dan dengan demikian menawarkan kontinuitas selama anggota bernavigasi di dalam Aplikasi. Cookie hanya digunakan pada Aplikasi untuk menyimpan data yang non-kritis. Cookies adalah potongan informasi dimana informasi tersebut ditransfer ke hard drive Smartphone Anda untuk tujuan menyimpan catatan.

Cookie memungkinkan Aplikasi web untuk menjaga informasi pengguna di seluruh koneksi. Cookie berupa string kecil berupa karakter yang digunakan oleh banyak Aplikasi untuk mengirimkan data ke Smartphone Anda, dan dalam keadaan tertentu, mengembalikan informasi ke Aplikasi web. Cookie hanya berisi informasi yang direlakan oleh anggota, dan mereka tidak memiliki kemampuan infiltrasi hard drive pengguna dan mencuri informasi pribadi. Fungsi sederhana cookie adalah membantu pengguna bernavigasi di Aplikasi dengan dengan kendala sesedikit mungkin.

Aplikasi Medical Go mungkin menggunakan perusahaan iklan luar untuk menampilkan iklan di Aplikasi kami. Iklan ini mungkin mengandung cookies, yang tampaknya datang dari Aplikasi web, tetapi pada kenyataannya mereka datang dari mitra kami yang melayani iklan di Aplikasi. Aplikasi tertentu dapat menempatkan "cookie" pada Smartphone Anda untuk memberikan layanan personalisasi dan / atau mempertahankan identitas Anda di beberapa halaman dalam satu sesi.
<br><br>
<h3>KEAMANAN</h3>

Aplikasi ini memiliki langkah-langkah keamanan untuk melindungi kehilangan, penyalahgunaan dan perubahan informasi di dalam kendali kita. Langkah-langkah ini meliputi metode perlindungan data dasar dan kompleks, penyimpanan informasi tertentu secara offline dan pengamanan server database kami. Aplikasi ini memberikan pilihan bagi para pengguna untuk menghapus informasi mereka dari database kami untuk tidak menerima informasi kedepannya atau untuk tidak lagi menerima layanan kami.
<br><br><p>
<center>
<a href="reg.php#reg" onclick="javascript:showDiv();"><button style="width:200px;font-size:12px;height:auto;margin-top:-20px;padding-bottom:20px;"class="ladda-button"data-color="blue">Setuju & Lanjutkan</button></a>
</p><br><br></center>
</div></div>		
<div id="prosedur"class="panel"style="z-index:9999">
<div class="content"style="width:100%;right:0;left:0;">
<center><h3 style="color:#5792b5;font-size:16px">Prosedur pembayaran</h3>
<p><center>
<img src="../prosedurpembayaran.png" width="90%"/></center></p>
<br><center><a href="#jogin"><img src="../back.png" width="20px"/><b> Kembali</b></a></center><br><br>
</div>
</div>
<div id="loading" style="display:none">
</div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>
</body>