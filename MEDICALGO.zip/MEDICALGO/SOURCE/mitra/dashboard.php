<?php
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: ../admin-MedicalGO/index.php");
}
$res=mysql_query("SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
$sebagai=$rows['sebagai'];
$result = mysql_query("DELETE FROM transaksi WHERE status_trans='minta' and DATE(tanggal) < CURDATE()");
$result = mysql_query("DELETE FROM trans_user WHERE statussaldo='minta' and DATE(tgl_request) < CURDATE()");
$result = mysql_query("DELETE FROM trans_sopir WHERE statussaldo='minta' and DATE(tgl_request) < CURDATE()");
$result = mysql_query("UPDATE transaksi set status_trans='minta' WHERE status_trans='dijemput' and CURDATE() - INTERVAL 30 MINUTE;"); 
?>
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../demo.css"/>
<script src="https://code.jquery.com/jquery-1.9.1.js" integrity="sha256-e9gNBsAcA0DBuRWbm0oZfbiCyhjLrI6bmqAl5o+ZjUA=" crossorigin="anonymous"></script>
</head>
   <script>
        function test() {
            var myIFrame = document.getElementById("ora");
            var links = myIFrame.contentWindow.document.getElementsByTagName("a");
            for (var index = 0; index < links.length; index++) {
                links[index].removeAttribute('href');
            }
        }
    </script>

<body onload="test();">
<div class="sodrops-top">
<span class="actions">
<ul>
<?php if($sebagai == 'admin'){ ?>
<li><a onclick="refreshIframe();" style="color:#fff" href="dashboard.php" title="Refresh"><img src="refresh.png"width="25px"/></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#dashboard" title="Dashboard"><img src="fa-list-ul.png" width="25px"/><br><center>Dashboard</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#Mitra" title="Mitra MedicalGO"><img src="aka.png" width="25px"/><br><center>Medis</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#user" title="Pasien MedicalGO"><img src="user.png" width="25px"/><br><center>Pasien</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#transaksi" title="Transaksi hari ini"><img src="fa-usd.png" width="25px"/><br><center>Transaksi</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#link" title="Layanan Medical GO"><img src="link.png" width="25px"/><br><center>Layanan</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff"href="#saldo" title="Payment User"><img src="pay.png" width="25px"/><br><center>Payment<br><small>User</small></center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff"href="#salda" title="Payment Medis"><img src="pay.png" width="25px"/><br><center>Payment<br><small>Medis</small></center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff"href="#pengaturan" title="Pengaturan Biaya Charge"><img src="pengaturan.png" width="25px"/><br><center>Rekening <br><small>& Transport</small></center></center></a></li>
<li><a onclick="refreshIframe();"style="color:#fff" href="http://hospital.barisandata.com/livehelper/index.php/site_admin/user/login" target="_blank" title="Customer support"><img src="akom.png" width="25px"/><br><center>Support</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="http://hospital.barisandata.com/cpanel" target="_blank" title="Cpanel"><img src="database.png" width="25px"/><br><center>Cpanel</center></a></li>
<?php }if($sebagai == 'demo'){ ?>
<li><a onclick="refreshIframe();" style="color:#fff" href="dashboard.php" title="Refresh"><img src="refresh.png"width="25px"/></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#dashboard2" title="Dashboard"><img src="fa-list-ul.png" width="25px"/><br><center>Dashboard</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#Mitra2" title="Mitra MedicalGO"><img src="aka.png" width="25px"/><br><center>Medis</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#user2" title="Pasien MedicalGO"><img src="user.png" width="25px"/><br><center>Pasien</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#transaksi2" title="Transaksi hari ini"><img src="fa-usd.png" width="25px"/><br><center>Transaksi</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#fing2" title="Pengaturan Hari Libur"><img src="calendar.png" width="25px"/><br><center>Libur Nasional</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="#link2" title="Layanan Medical GO"><img src="link.png" width="25px"/><br><center>Layanan</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff"href="#saldo2" title="Payment User"><img src="pay.png" width="25px"/><br><center>Payment<br><small>User</small></center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff"href="#salda2" title="Payment Medis"><img src="pay.png" width="25px"/><br><center>Payment<br><small>Medis</small></center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff"href="#pengaturan2" title="Pengaturan Biaya Charge"><img src="pengaturan.png" width="25px"/><br><center>Rekening <br><small>& Transport</small></center></center></a></li>
<li><a onclick="refreshIframe();"style="color:#fff" href="http://hospital.barisandata.com/livehelper/index.php/site_admin/user/login" target="_blank" title="Customer support"><img src="akom.png" width="25px"/><br><center>Support</center></a></li>
<li><a onclick="refreshIframe();" style="color:#fff" href="http://hospital.barisandata.com/cpanel" target="_blank" title="Cpanel"><img src="database.png" width="25px"/><br><center>Cpanel</center></a></li>

<?php } ?>
</ul>
</span>
<div style="margin-left:20px;font-size:18px;font-weight:bold"><img src="../logobig.png"width="50px" style="vertical-align:middle"/> Administrator
</div>
</div>
<div id="sidebar"><br><br><center>
<h3>Panel Admin,</h3>
<p class="sindent">
<img style="max-width:550px;height:auto"src="../logo.png"/>
<p>
<b><i>"MedicalGO App"</i></b>
<p>
<table width="100%"style="text-decoration:justify;border-bottom:1px solid #000;color:#000;">
<tr style="border-top:1px solid #000"><td>Jumlah Pasien:</td><td>
<?php
$query = "SELECT COUNT(*) AS total FROM users"; 
$result = mysql_query($query); 
$values = mysql_fetch_assoc($result); 
$num_rows = $values['total']; 
echo $num_rows;
 ?> Pasien
</td></tr>
<tr style="border-top:1px solid #000"><td>Jumlah Medis :</td><td>
<?php
$query = "SELECT COUNT(*) AS total FROM mitra"; 
$result = mysql_query($query); 
$values = mysql_fetch_assoc($result); 
$num_rows = $values['total']; 
echo $num_rows;
 ?> Medis
</td></tr>
<tr style="border-top:1px solid #000;border-bottom:1px solid #000"><td>Jumlah Transaksi: </td><td>
<?php
$query = "SELECT COUNT(*) AS total FROM transaksi"; 
$result = mysql_query($query); 
$values = mysql_fetch_assoc($result); 
$num_rows = $values['total']; 
echo $num_rows;
 ?> Transaksi
</td></tr><tr style="border-top:1px solid #000;border-bottom:1px solid #000"><td>Pasien Request Hari ini: </td><td>
<?php
$jatuhtempo=date('d-m-Y');
$query = "SELECT COUNT(*) AS total FROM transaksi WHERE tanggal='$jatuhtempo'"; 
$result = mysql_query($query); 
$values = mysql_fetch_assoc($result); 
$jim_rows = $values['total'];
echo $jim_rows; 
 ?> Pasien
</td></tr>
</table>
</p>
<?php if($jim_rows == '1'){ ?>
<audio controls autoplay style="visibility:hidden"name="Android" id="Android" src="Android.mp3" preload="auto"></audio>
<audio name="Android" id="Android" src="Android.mp3" preload="auto"></audio>
<?php }?>
<?php if($jim_rows >= '1'){ ?>
<audio controls autoplay style="visibility:hidden"name="Android" id="Android" src="Android.mp3" preload="auto"></audio>
<audio name="Android" id="Android" src="Android.mp3" preload="auto"></audio>
<?php }?>
<a href="javascript:history.go(0)"><div class="testbutton" style="background-color:blue">Refresh</div></a><br>
<a href="http://hospital.barisandata.com/livehelper/index.php/site_admin/user/login" target="_blank"><div class="testbutton" style="background-color:#3581c1">Portal Cs Support</div></a><br>
<a href="logoutadmin.php?logout"><div class="testbutton" style="background-color:#960505">Logout</div></a><br>
</center></div>
<div id="pengaturan"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content" style="height:100%;overflow:auto"><br><br>
<iframe src="rekening/upadatetarif.php" style="width:100%;height:725px" align="center" scrolling="yes" frameborder="0"></iframe>
</div></div>
<div id="saldo"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="saldo/index.php" style="width:100%;height:725px" align="center" scrolling="yes" frameborder="0"></iframe>
</div></div>
<div id="salda"class="panel" style="height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="saldodriver/index.php" style="width:100%;height:725px" align="center" scrolling="yes" frameborder="0"></iframe>
</div></div>
<div id="tarif"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="tarif/index.php" style="background:#fff;width:100%;height:800px" align="center" scrolling="yes" frameborder="0"></iframe>
</div></div>
<div id="Mitra"class="panel" style="background:#fff;width:100%;height:900px">
<div class="content"><br><br>
<iframe src="mitra/index.php" style="background:#fff;width:100%;height:800" align="center" scrolling="yes" frameborder="0"></iframe>
</div></div>
<div id="user"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="user/index.php" style="background:#fff;width:100%;height:600px" align="center" scrolling="yes" frameborder="0"></iframe>
</div></div>
<div id="link"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="town/index.php" style="background:#fff;width:100%;height:800px" align="center" scrolling="yes" frameborder="0"></iframe>
</div></div>
<div id="fing"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="libur/index.php" style="background:#fff;width:100%;height:800px" align="center" scrolling="yes" frameborder="0"></iframe>
</div></div>
<div id="transaksi"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="transaksi/index.php" style="background:#fff;width:100%;height:800px" align="center" scrolling="yes" frameborder="0"></iframe>
</div></div>
<div id="pengaturan2"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content" style="height:100%;overflow:auto"><br><br>
<iframe src="rekening/upadatetarif.php" style="width:100%;height:725px;pointer-events: none;" align="center" scrolling="yes" id="ora" name="ora" frameborder="0" sandbox></iframe>
</div></div>
<div id="saldo2"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="saldo/index.php" style="width:100%;height:725px;pointer-events: none;" align="center" scrolling="yes" id="ora" name="ora" frameborder="0" sandbox></iframe>
</div></div> 
<div id="salda2"class="panel" style="height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="saldodriver/index.php" style="width:100%;height:725px;pointer-events: none;" align="center" scrolling="yes" id="ora" name="ora" frameborder="0" sandbox></iframe>
</div></div>
<div id="tarif2"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="tarif/index.php" style="background:#fff;width:100%;height:800px;pointer-events: none;" align="center" scrolling="yes" id="ora" name="ora" frameborder="0" sandbox></iframe>
</div></div> 
<div id="Mitra2"class="panel" style="pointer-events: none;background:#fff;width:100%;height:900px">
<div class="content"><br><br>
<iframe src="mitra/index.php" style="background:#fff;width:100%;height:800;pointer-events: none;" align="center" scrolling="yes" id="ora" name="ora" frameborder="0" sandbox></iframe>
</div></div>
<div id="user2"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="user/index.php" style="background:#fff;width:100%;height:600px;pointer-events: none;" align="center" scrolling="yes" id="ora" name="ora" frameborder="0" sandbox></iframe>
</div></div>
<div id="link2"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="town/index.php" style="background:#fff;width:100%;height:800px;pointer-events: none;" align="center" scrolling="yes" id="ora" name="ora" frameborder="0" sandbox></iframe>
</div></div>
<div id="fing2"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="libur/index.php" style="background:#fff;width:100%;height:800px;pointer-events: none;" align="center" scrolling="yes" id="ora" name="ora" frameborder="0" ></iframe>
</div></div>
<div id="transaksi2"class="panel" style="width:100%;height:100%;overflow:auto;background:#fff">
<div class="content"><br><br>
<iframe src="transaksi/index.php" style="background:#fff;width:100%;height:800px;pointer-events: none;" align="center" scrolling="yes" id="ora" name="ora" frameborder="0" sandbox></iframe>
</div></div>
<div id="dashboard"class="parel" onkeydown="javascript:if(window.event.keyCode==13)window.event.keyCode=9">
<div class="content"><br><br><br><br>

<div style="border-bottom:1px solid #8c8c8c;color:#616161;font-size:14px">*** Jadwal Job Sedang berlangsung
</div>
<center>
<div style="z-index:1;color:grey;font-size:18px;font-weight:bold">
</div>
</center>
<br>
<?php
//including the database connection file
include_once("config.php");
?>
    <style>
      #map-canvas {
        width: 100%;
        height: 500px;
      }
    </style>
  <script type="text/javascript" src="//maps.google.com/maps/api/js?sensor=true"></script>
  <script type="text/javascript"src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAO4lbxY6SKygcJxTuzu-Qi7kAAP9SdAwM&callback=initMap"></script> <script>
    var marker;
      function initialize() {
        var mapCanvas = document.getElementById('map-canvas');
        var mapOptions = {
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }     
        var map = new google.maps.Map(mapCanvas, mapOptions);
        var infoWindow = new google.maps.InfoWindow;      
        var bounds = new google.maps.LatLngBounds();
 
 
        function bindInfoWindow(marker, map, infoWindow, html) {
          google.maps.event.addListener(marker, 'click', function() {
            infoWindow.setContent(html);
            infoWindow.open(map, marker);
          });
        }
 
          function addMarker(lat, lng, info) {
            var pt = new google.maps.LatLng(lat, lng);
            bounds.extend(pt);
var iconBase = 'https://hospital.barisandata.com/terapis.png';
            var marker = new google.maps.Marker({
				icon: iconBase,
                map: map,
                position: pt
            });       
            map.fitBounds(bounds);
            bindInfoWindow(marker, map, infoWindow, info);
          }
 
          <?php
            $query = mysql_query("SELECT * FROM transaksi INNER JOIN users ON transaksi.id_users=users.id where aktif='yes'");
          while ($data = mysql_fetch_array($query)) {
			$id_mitra=$data['id_mitra'];
			$lulu = mysql_query("SELECT * FROM mitra where id_mitra='$id_mitra'");
			$ata = mysql_fetch_array($lulu);
            $nama_mitra = $ata['nama_mitra'];
            $lat = $data['lat'];
            $lng = $data['lng'];
            $first_name = $data['first_name'];
			$id_trans = $data['id_trans'];
			$phone = $data['phone'];
			$sebagai = $data['sebagai'];
			$alamat = $data['alamat'];
			$tujuan = $data['tujuan'];
            $harga= $data['harga'];
            $layanan= $data['layanan'];
            $tipe= $data['tipe'];
            echo ("addMarker($lat, $lng, '<a href=transaksi/printing.php?id_trans=$id_trans target=_blank style=font-size:11px;color:#000><b>$first_name Request $layanan</b> <br>Medis: $nama_mitra <br>Ke alamat: $alamat <br>Biaya layanan: Rp. $awal <br>Biaya Transport: Rp. $transport <br>Total Invoice: Rp. $harga <br> Phone $first_name : $phone <br></a>');\n");                        
          }
          ?>
        }
      google.maps.event.addDomListener(window, 'load', initialize);
    </script>
    <div id="map-canvas"></div> <center style="color:#000">Klik titik maps untuk melihat detil<br><br>
	
<p style="color:#000;font-size:13px">**Login default untuk portal Customer support<br> Username: MedicalGO<br>Password: MedicalGO1234</p>
	</center>
    <script>
function refreshIframe() {
    var ifr = document.getElementsByName('Right')[0];
    ifr.src = ifr.src;
}
function refreshIframe() {
    var ifr = document.getElementsByName('Mit')[0];
    ifr.src = ifr.src;
}
function refreshIframe() {
    var ifr = document.getElementsByName('PIK')[0];
    ifr.src = ifr.src;
}
    </script>
<script>/*<![CDATA[*/function openCity(b,c){var e,a,d;a=document.getElementsByClassName("mainpanel");for(e=0;e<a.length;e++){a[e].style.display="none"}d=document.getElementsByClassName("tablinks");for(e=0;e<d.length;e++){d[e].className=d[e].className.replace(" active","")}document.getElementById(c).style.display="block";b.currentTarget.className+=" active"}document.getElementById("defaultOpen").click();/*]]>*/</script>

</body>