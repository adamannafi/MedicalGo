<?php

session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: fdex.php#login");
}
$res=mysql_query("SELECT * FROM users WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
?>
<?php
$jiew=mysql_query("SELECT * FROM transaksi where idsopir=".$_SESSION['mitra']);
while($jow=mysql_fetch_array($jiew)){
	?><?php 
 if($jow['status_trans']=='minta')
      { ?>
<script>document.location.href="home.php#asrent";</script><?php }
?>
<?php 
 if($jow['status_trans']=='dijemput')
      { ?>
<script>document.location.href="home.php#asrent";</script><?php }
?>
<?php
if($jow['status_trans']=='otw')
      {?>
<script>document.location.href="home.php#asrent";</script><?php }};?>
<?php
if(isset($_POST['tambah'])){
if (empty($_POST['jumlahsaldo'])) {
   ?>
<script>window.alert("isi nominal!");window.history.back(-2);</script><?php
  return false;
}
$jumlahsaldo=$_POST['jumlahsaldo'];
$limit=$_POST['limit'];
if($jumlahsaldo>=$limit)
      {   ?>
<script>window.alert("Widthraw ditolak. Melebihi total saldo anda");window.history.back(-2);</script><?php
  return false;
}
$idsopir = $_POST['idsopir'];
$tipesaldo	= $_POST['tipesaldo'];
$jumlahsaldo = $_POST['jumlahsaldo'];
$statussaldo = $_POST['statussaldo'];
$tgl_request = $_POST['tgl_request'];

$banksaldo = $_POST['banksaldo'];
$namauser = $_POST['namauser'];
$nomorrek = $_POST['nomorrek'];
$input = "SELECT idsopir FROM trans_sopir WHERE idsopir='$idsopir' and statussaldo='minta' or statussaldo='dijemput'";
$result = mysql_query($input);
$count = mysql_num_rows($result); // if email not found then register
if($count == 0){
if(mysql_query("INSERT INTO `trans_sopir` (`idsaldo`, `idsopir`, `tipesaldo`, `jumlahsaldo`, `statussaldo`, `tgl_request`, `banksaldo`, `namauser`, `nomorrek`) VALUES (NULL, '$idsopir', 'withdraw', '$jumlahsaldo', 'dijemput', '$tgl_request', '$banksaldo', '$namauser', '$nomorrek');"))
		{

			?>
<script>document.location.href="home.php#saldo";</script><?php
		}
		else
		{
			?>
<?php
		}		
	}
	else{
			?>
<?php
	}
	
}
?>
<?php 
$id_mitra = $_GET['id_mitra'];
$view=mysql_query("SELECT * FROM mitra where id_mitra='$id_mitra'");
while($row=mysql_fetch_array($view)){
?>
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../demo.css"/>
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:#000;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:-50px;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#home{display:none}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<link rel="stylesheet"href="../css/bemo.css">
<link rel="stylesheet"href="../dist/ladda.min.css">
<link rel="stylesheet"href="../themes/base/jquery.ui.all.css">
<script src="../js/jquery.min.js">
</script>
<script src="../js/jquery-ui.min.js">
</script>

<body onkeydown="javascript:if(window.event.keyCode==13)window.event.keyCode=9">
<body style="width:100%;background:#fff;padding:0;font-family:Segoe UI">
<div class="sodrops-top">
<span class="actions" style="float:left">
<ul>
<li><a href="javascript:history.back()" onclick="javascript:showDiv();"><img src="../back.png"width="25px"/></i></a></li>
</ul>
</span>
<div style="margin-top:20px;font-size:18px;font-family:Segoe UI light"><center>Withdraw saldo</center>
</div>
</div>
<center style="width:100%;"><br><br><br>
<img src="wd.jpg" style="width:100%;height:200px;"/>
</center>
<div style="width:100%;color:#fff;position:absolute;">
<table width="100%" style="background-color:rgba(1, 102, 185, 0.76);">
<tr>
<td width="30%" style="background-color:#36a2cc;padding:10px;"><center>
1. Tulis nominal withdraw
</center></td>
<td width="30%" style="background-color:#3a3b3c;padding:10px;"><center>
2. Isi informasi Bank anda
</center></td>
<td width="30%" style="background-color:#b71313;padding:10px;"><center>
3. Uang di transfer ke rekening anda
</center></td>
</tr>
</table>
<center style="padding:10px;background-color:rgba(1, 102, 185, 0.76);border-bottom:5px solid #5cb55c">Anda harus mengikuti tahapan</center>
</div>
<div style="color:#000;padding:20px"><br><br><br><br><br><center>

</div>
<form id="form" action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
<input name="tipesaldo" type="hidden" value="withdraw"/>
<input name="statussaldo" type="hidden" value="dijemput"/>
<input name="idsopir" type="hidden" value="<?php echo $_SESSION['mitra'];?>"/>
<input type="hidden"name="tgl_request"value="<?php echo date('d-m-Y'); ?>"/>
<input name="limit" type="hidden" value="<?php echo $row['saldo'];?>"/>
<center style="color:#000"><div id_mitra="input">Berapa jumlah Withdraw :<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='number'name="jumlahsaldo"class='holo' placeholder="Tulis nominal Rp." aria-required="true" min="100" max="<?php echo $row['saldo'];?>" value="<?php echo $row['saldo'];?>" required="required"/>
<nav></nav></div><br></center>
<br><br>
<input name="idsopir" type="hidden" value="<?php echo $_SESSION['mitra'];?>"/>
<center style="color:#000"><div id_mitra="input">Nama bank :<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='text'name="banksaldo"class='holo' placeholder="Tulis Nama bank anda" aria-required="true" required="required"/>
<nav></nav></div><br>
<center style="color:#000"><div id_mitra="input">Nomor Rekening :<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='number'name="nomorrek"class='holo' placeholder="Tulis Nomor rekening anda" aria-required="true" required="required"/>
<nav></nav></div><br>
<center style="color:#000"><div id_mitra="input">Atas Nama :<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='text'name="namauser"class='holo' placeholder="Tulis Nama akun pemilik rekening" aria-required="true" required="required"/>
<nav></nav></div><br><br><br><br><br><br><br>
<table width="100%" style="width:100%;z-index:9999;bottom:0;position:fixed;background-color:#000;box-shadow: 0 2px 5px rgba(0,0,0,.26);"><tr>
<td style="font-size:12px;padding:20px;color:#fff"width="50%">lanjutkan dengan klik submit
</td>
<td style="font-size:15px;padding:20px;color:#fff;"width="50%">
<center>
<button type="submit"name="tambah" style="color:#fff;background:green;border:none;padding:10px;border-radius:20px;" onclick="javascript:showDiv();">Submit</button>
</div>
</form>
</div>
</td>
</tr>
</table>
</body>
<?php 	}
 ?>