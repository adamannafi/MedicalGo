<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT * FROM users");
?>
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>
<body style="font-family:Monospace;">
<h3>Data Pasien Medical GO App</h3>
Untuk Mencari data nama berdasarkan kata, tanggal dan angka, klik tombol "ctrl+F" lalu ketikkan kata
	<table width='100%' border=0>

	<tr>
		<th>Nama lengkap</th>
		<th>Pria/wanita</th>
		<th>Alamat</th>
		<th>Email</th>
		<th>Nomor Handphone</th>
		<th>(x)</th>
	
	</tr>
	<?php 
	while($res = mysql_fetch_array($result)) { 		
$gadi=$res['point'];	
		echo "<tr>";
		echo "<td>".$res['first_name']."</td>";
		echo "<td>".$res['jeniskelamin']."</td>";
		echo "<td>".$res['useralamat']."</td>";
		echo "<td>".$res['email']."</td>";
		echo "<td>".$res['phone']."</td>";
		echo "<td> <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
	}
	?>
	</table>
</body>
</html>
