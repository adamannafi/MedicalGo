<?php
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: fdex.php#login");
}
$res=mysql_query("SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
?>

<head>
<meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../demo.css"/><link rel="stylesheet"href="../css/bemo.css"><link rel="stylesheet"href="../dist/ladda.min.css"></head>
<body onkeydown="javascript:if(window.event.keyCode == 13) window.event.keyCode = 9;"><!--sodrops top bar-->
<div class="sodrops-top" style="height:60px;background-color:#d00909">
<span class="actions" style="float:left">
<ul>
<li><a style="margin-left:-20px;" href="home.php#saldo" onclick="javascript:showDiv();"><img src="../back.png"width="25px"/></i></a></li>
</ul>
</span>
<div style="font-size:18px;font-family:Segoe UI light;float:right;padding-right:20px;">
<a href="javascript:history.go(0)"><img src="refresh.png"width="25px"/></a>
</div>
</div>
<div id="saldo"class="panel" style="background:#fff"><div class="content" style="background:#fff;color:#000"><br><br><br><br>
<center style="color:#000"><h4>Your Balance:</h4>
<b><?php 
$sistim = $rows['saldo'];
$saldo = number_format($sistim,0,",",".");
$givetime = $sistim/1000;
echo $givetime;?> Point</b>
</center><br>
<br>
<center style="padding:10px;font-size:12px;color:grey;font-family:Segoe UI light">Saldo Deposit minimal Rp. 20.000,- atau 20 Point Untuk bisa mengambil job, untuk deposit klik Topup</center>
<br>
<center style="font-size:14px;color:#000;font-family:Segoe UI;background:#dedede;border-top:1px solid grey;border-bottom:1px solid grey;border-style:dashed;">
<?php 
$her=mysql_query("SELECT * FROM infobank where idinfo='1'");
$mul=mysql_fetch_array($her);
$milk=mysql_query("SELECT * FROM trans_sopir where idsopir=".$_SESSION['mitra']);
while($ent=mysql_fetch_array($milk)){
 if($ent['statussaldo']=='minta')
      { 
   if($ent['tipesaldo']=='topup')
      { ?>
<style> .red{visibility:hidden}</style>
  <b><small>Anda  request Topup</small></b><br><br>
Senilai: Rp. <?php echo $ent['jumlahsaldo'];?><br>
Silahkan melakukan transfer ke rekening Medical GO:<br>
Nama Bank: <?php echo $mul['namabank'];?><br>
Nomor Rekening: <?php echo $mul['norek'];?><br>
Atas Nama: <?php echo $mul['namaorang'];?><br><br>
<small>Setelah melakukan transfer ke rekening Medical GO, silahkan konfirmasi</small><br><br>
Untuk Konfirmasi pembayaran harap hubungi: <?php echo $mul['jambuka'];?> (Sms/Telp/Whatsapp)<br><small>Wajib melakukan konfirmasi pembayaran</small>
<br><br>
<center>
<a href="#konfirmasi">
<button style="width:100%;font-size:15px;height:auto;margin-top:0px;padding-bottom:20px;border-radius:0px;"class="ladda-button"data-color="green">Konfirmasi pembayaran</button>
</a>
</center>
	  <?php }
	  if($ent['tipesaldo']=='withdraw')
      {?>

<style> .red{visibility:hidden}</style>
<b><small>Anda request Withdrawal, 
Senilai: Rp. <?php echo $ent['jumlahsaldo'];?><br><br>Tunggu ...</small></b><br><br>

	  <? }}
 if($ent['statussaldo']=='dijemput')
 {
?>
<style> .red{visibility:hidden}</style>
<br>
<b><small>Request <?php echo $ent['tipesaldo'];?> Waiting for admin confirmation</small></b><br><br>
<?php }}?>
 </center><center>
<div class="red">
<?php
$id_driver = $_SESSION['mitra'];
$query=mysql_fetch_array(mysql_query("select * from transaksi where id_driver='$id_driver' and lunas='no'"));
$count = mysql_num_rows($query);
if($count == 0){
?>
<section class="button-demo" style="padding:0;width:100%">
<a href="topupdriver.php?id_mitra=<?php echo $rows['id_mitra'];?>"><button style="width:100%;border-radius:0px;" class="ladda-button" data-color="blue" data-style="expand-right">
<small>Toup Up/Deposit Balance</small></button></a>
</section>
<?php } else {?>
<section class="button-demo" style="font-size:13px;padding:0;width:100%">
<a href="topupdriver.php?id_mitra=<?php echo $rows['id_mitra'];?>&&jumlahsaldo=<?php 
$id_driver = $_SESSION['mitra'];
$murberu = "SELECT sum(total) AS total FROM transaksi where id_driver='$id_driver' and aktif='no' and lunas='no'"; 
$result = mysql_query($murberu); 
$values = mysql_fetch_assoc($result); 
$num_rows = $values['total']; 
echo $num_rows;?>"><button style="font-size:13px;width:100%;border-radius:0px;" class="ladda-button" data-color="blue" data-style="expand-right">
<small>Segera Lakukan Deposit Setoran senilai: </small><br>
Rp. <?php
$id_driver = $_SESSION['mitra'];
$murberu = "SELECT sum(total) AS total FROM transaksi where id_driver='$id_driver' and aktif='no' and lunas='no'"; 
$result = mysql_query($murberu); 
$values = mysql_fetch_assoc($result); 
$num_rows = $values['total']; 
$laba = number_format($num_rows,0,",",".");
echo $laba;
 ?>

</button></a>
</section>
<?php } ?>
</div>
</div></div>
<div id="konfirmasi"class="panel" style="background:#fff"><div class="content" style="background:#fff;color:#000"><br>
<center>
<b><small>Konfirmasikan pembayaran anda</small></b></center>
<br>
<form id="form"action="topupdriver.php" method="post">
<input name="id_mitra" type="hidden" value="<?php echo $_SESSION['mitra'];?>"/>
<center style="color:#000"><div id="input">Nama bank :<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='text'name="banksaldo"class='holo' placeholder="Tulis Nama bank anda" aria-required="true" required="required"/>
<nav></nav></div><br>
<center style="color:#000"><div id="input">Nomor Rekening :<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='number'name="nomorrek"class='holo' placeholder="Tulis Nomor rekening anda" aria-required="true" required="required"/>
<nav></nav></div><br>
<center style="color:#000"><div id="input">Atas Nama :<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='text'name="namauser"class='holo' placeholder="Tulis Nama akun pemilik rekening" aria-required="true" required="required"/>
<nav></nav></div><br>
<button type="submit"name="konfirmasi" style="width:200px;color:#fff;background:green;border:none;padding:10px;border-radius:20px;" onclick="javascript:showDiv();">Konfirm</button>
<br><br>
<a href="saldohabis.php#saldo"style="color:orange">Kembali</a>
</center>
</form>
</div></div>

</body>
<?php 
$id_trans=$_GET['id_trans'];
$mitra = $_SESSION['mitra'];
$view=mysql_query("SELECT * FROM transaksi where id_mitra='$mitra' and id_trans='$id_trans'");
while($row=mysql_fetch_array($view)){
	?><?php 
 if($row['status_trans']=='dijemput')
      { ?><script>document.location.href="home.php#Pasien";</script><?php }	} ;
 ?>