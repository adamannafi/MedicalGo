<?php
include_once("config.php");
if(isset($_POST['kirim'])){
	$idinfo=$_POST['idinfo'];
	$namabank = $_POST['namabank'];
	$namaorang = $_POST['namaorang'];
	$norek = $_POST['norek'];
	$jambuka = $_POST['jambuka'];
	$transportasi = $_POST['transport'];
$query=mysql_query("update infobank set namabank='$namabank', namaorang='$namaorang', norek='$norek', jambuka='$jambuka' where idinfo='$idinfo'");	
$query=mysql_query("update tarif set transportasi='$transportasi' where id_tarif='1'");					
	if($query){
		?>
	<script>document.location.href="upadatetarif.php";</script>
		<?php
	}else{
		echo mysql_query();
	}
	

}else{
	unset($_POST['kirim']);
}
?>