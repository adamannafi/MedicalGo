   <body style="padding:10px;color:#444;font-family:Segoe UI"> 
    <?php
	include_once("config.php");
$idinfo = $_GET['idinfo'];
	$query=mysql_fetch_array(mysql_query("select * from infobank where idinfo='1'"));
	$idinfo=$query['idinfo'];
	$namabank = $query['namabank'];
	$namaorang = $query['namaorang'];
	$norek = $query['norek'];
	$jambuka = $query['jambuka'];
	?>
<style>
input[type=text] {
  width: 100px;
  -webkit-transition: width .35s ease-in-out;
  transition: width .35s ease-in-out;
}
input[type=text]:focus {
  width: 250px;
}
</style>
<form id="form"action="simpantarif.php" enctype="multipart/form-data"  method="post" name="postform">
<input type="hidden" name="idinfo" value="<?php echo $idinfo;?>" />
<center><h3>Update Rekening Bersama dan pengaturan tarif transport Medical GO</h3></center>
<table width="50%">
<tr>
<td style="border-bottom:1px solid grey"> Bank Name :<br>
* Nama Bank </td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="text" name="namabank"required="required" value="<?php echo $namabank;?>"></td>
</tr>
<tr>
<td style="border-bottom:1px solid grey">Bank Account number :<br>
* Nomor Rekening Bank
</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;"type="text" name="norek"required="required" value="<?php echo $norek;?>"></td>
</tr>
<tr>
<td style="border-bottom:1px solid grey">Name Account owner :<br>
* Atas Nama / Pemilik Rekening
</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="text" name="namaorang"required="required" value="<?php echo $namaorang;?>"></td>
</tr>
<tr>
<td style="border-bottom:1px solid grey">Phone :<br>
* Nomor Ponsel untuk konfirmasi user
</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;"type="text" name="jambuka"required="required" value="<?php echo $jambuka;?>"></td>
</tr>
<tr>
<td style="border-bottom:1px solid grey">Transport per KM (Dalam Rupiah):<br>
* Biaya transport tiap Km, untuk tarif transport 
<?php
	$nok=mysql_fetch_array(mysql_query("select * from tarif where id_tarif='1'"));
	$transport=$nok['transportasi'];
?>
</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;"type="text" name="transport"required="required" value="<?php echo $transport;?>"></td>
</tr>
    <tr>
      <td>&nbsp;</td>
      <td><br><br><center><input type="submit" style="width:100%;padding:15px;color:#fff;border:1px solid #09c;background:#09c;border-radius:20px;" value="Save"  onclick="return confirm('Sure to change bank information and price transport per Km?')"name="kirim" /></center><br><center><a href="javascript:history.back()" style="width:100%;padding:10px;border:2px solid #d64141;color:#d64141;border-radius:20px;">Cancel</a></center></td>
    </tr>
    </table>
    </form>
    <p><br /></p></body>