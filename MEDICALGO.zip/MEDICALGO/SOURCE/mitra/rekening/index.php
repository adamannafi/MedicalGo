<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT * FROM layanan");
?>
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>
<body style="font-family:Monospace;">
<h3>Data Layanan MedicalGO App</h3>
Untuk mengatur biaya layanan<br>
<table width='100%' border=0>

	<tr>
		<th>Nama Layanan</th>
		<th>Keterangan Layanan</th>
		<th>Biaya Layanan</th>
		<th> -/- </th>
	
	</tr>
	<?php 
	while($res = mysql_fetch_array($result)) {
		echo "<tr>";
		echo "<td>".$res['nama_layanan']."</td>";
		echo "<td>".$res['keterangan_layanan']."</td>";
echo "<td> Rp. ".$res['harga_layanan']."</td>";
		echo "<td> <a href=\"upadatetarif.php?id_layanan=$res[id_layanan]\" onClick=\"return confirm('ingin mengubah Biaya layanan?')\">Edit</a></td>";		
	}
	?>
	</table>
</body>
</html>
