<?php
include_once("dbconnect.php");
if(isset($_POST['kirim'])){
	$id_barang=$_POST['id_barang'];
	$gambar= $_POST['gambar'];
	
	if(empty($_FILES['gambar']['name'])){
		$gambar=$_POST['gambar'];
	}else{
		$gambar=$_FILES['gambar']['name'];
		
		//definisikan variabel file dan alamat file
		$uploaddir='../fotobarang/';
		$alamatfile=$uploaddir.$gambar;

		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file($_FILES['gambar']['tmp_name'],$alamatfile);
	}


	$query=mysql_query("update barang set gambar='$gambar' where id_barang='$id_barang'");
						
	if($query){
		?>
<script>document.location.href="barang/index.php";</script>
		<?php
	}else{
		echo mysql_query();
	}
	

}else{
	unset($_POST['kirim']);
}
?>