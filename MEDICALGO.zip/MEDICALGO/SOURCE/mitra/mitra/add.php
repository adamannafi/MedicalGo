<?php
session_start();
include_once 'config.php';

if(isset($_POST['submit']))
{
	
	$uname = mysql_real_escape_string($_POST['uname']);
	$email = mysql_real_escape_string($_POST['email']);
	$upass = md5(mysql_real_escape_string($_POST['upass']));
	$kelamin = mysql_real_escape_string($_POST['kelamin']);
	$no_ktp = mysql_real_escape_string($_POST['no_ktp']);
	$dokumen = mysql_real_escape_string($_POST['dokumen']);
	$foto_mitra = mysql_real_escape_string($_POST['foto_mitra']);
	$tempatlahir = mysql_real_escape_string($_POST['tempatlahir']);
	$tgllahir = mysql_real_escape_string($_POST['tgllahir']);
	$alamat = mysql_real_escape_string($_POST['alamat']);
	$latmitra = mysql_real_escape_string($_POST['latmitra']);
	$lngmitra = mysql_real_escape_string($_POST['lngmitra']);
	$nomorhp = mysql_real_escape_string($_POST['nomorhp']);
	$nomorhp2 = mysql_real_escape_string($_POST['nomorhp2']);
	$nik = mysql_real_escape_string($_POST['nik']);
	$referalmitra = mysql_real_escape_string($_POST['referalmitra']);
	$alamatkantor = mysql_real_escape_string($_POST['alamatkantor']);
	$catatan = mysql_real_escape_string($_POST['catatan']);
	$sebagai = mysql_real_escape_string($_POST['sebagai']);
	$uname = trim($uname);
	$email = trim($email);
	$upass = trim($upass);
	
	// email exist or not
	$query = "SELECT mitra_email FROM mitra WHERE mitra_email='$email'";
	$result = mysql_query($query);
	
	$count = mysql_num_rows($result); // if email not found then register
	
	
	if($count == 0){
		
	$foto_mitra = $_POST['foto_mitra'];
	if(empty($_FILES['foto_mitra']['name'])){
		$foto_mitra=$_POST['foto_mitra'];
	}else{
		$foto_mitra=$_FILES['foto_mitra']['name'];
		//definisikan variabel file dan alamat file
		$uploaddir='../../foto_mitra/';
		$alamatfile=$uploaddir.$foto_mitra;
		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file($_FILES['foto_mitra']['tmp_name'],$alamatfile);
	}
		if(mysql_query("INSERT INTO `mitra` (`id_mitra`, `nama_mitra`, `foto_mitra`, `kelamin`, `tempatlahir`, `tgllahir`, `alamat`, `latmitra`, `lngmitra`, `nomorhp`, `no_ktp`, `mitra_email`, `mitra_pass`, `dokumen`, `nomor_hp2`, `nik`, `alamatkantor`, `catatan`, `sebagai`, `referalmitra`, `tgldaftar`, `comission`, `signaturecode`, `gbrsignature`, `namadokumen`, `nomorsurat`, `saldo`) VALUES (NULL, '$uname', '$foto_mitra', '$kelamin', '$tempatlahir', '$tgllahir', '$alamat', '$latmitra', '$lngmitra', '$nomorhp', '$no_ktp', '$email', '$upass', '$dokumen', '$nomor_hp2', '$nik', '$alamatkantor', '$catatan', '$sebagai', '$referalmitra', '$tgldaftar', '$comission', '$signaturecode', '$gbrsignature', '$namadokumen', '$nomorsurat', '$saldo');"))
		{
			?>
	<script>document.location.href="index.php";</script>
			<?php
		}
		else
		{
			?><div style="color: #FF0000;">Server Sibuk,Coba Ulangi</div><?php
		}		
	}
	else{
			?><div style="color: #FF0000;">Email/ID sudah dimiliki oranglain</div><?php
	}
	
}
?>
<html>
<head>
	<title>Add Data</title>
</head>
<body style="font-family:Segoe UI;margin-left:70px;margin-right:70px">
<center><b style="padding:10px">Tambah Data Mitra</b></center><br>
<form id="form"action="add.php" enctype="multipart/form-data"  method="post" name="postform">

<table style="width:100%;padding:10px">
  <tr style="padding:10px">
    <th colspan="4" style="padding:10px"></th>
  </tr>
  <tr>
  <td style="padding:10px;background:#dadada">Kategori</td>
    <td>
<select style="padding:10px;width:100%" name="sebagai"required=required>
<option value="">-Mendaftar Sebagai-</option>
<option name="sebagai"value="Medis">Medis</option>
<option name="sebagai"value="finance">Finance Admin</option>
<option name="sebagai"value="perawat">perawat</option>
<option name="sebagai"value="dokter">Dokter Spesialis</option>
<option name="sebagai"value="admin">Super Admin</option>
<option name="sebagai"value="demo">Demo Admin (test)</option>
</select></td>
<td style="padding:10px;background:#dadada">Alamat kantor</td>
    <td><input style="padding:10px;width:100%"type="text" name="alamatkantor"required="required"></td>  
  </tr>
  <tr>
    <td style="padding:10px;background:#dadada">Nama Lengkap</td>
    <td><input style="padding:10px;width:100%"type="text" name="uname"required="required"></td>
    <td style="padding:10px;background:#dadada">No. KTP/NIK</td>
    <td><input style="padding:10px;width:100%"type="number" name="no_ktp"></td>
  </tr>
  <tr>
    <td style="padding:10px;background:#dadada">Jenis Kelamin</td>
    <td>
	<select style="padding:10px;width:100%" name="kelamin"required=required>
<option name="kelamin" value="">-Pilih-</option>
<option name="kelamin"value="pria">Pria</option>
<option name="kelamin"value="wanita">wanita</option>
</select></td>
    <td style="padding:10px;background:#dadada">Ijazah Pendidikan & Sertifikasi</td>
    <td><input style="padding:10px;width:100%"type="text" name="namadokumen"></td>
  </tr>
  
   <tr>
    <td style="padding:10px;background:#dadada">Alamat</td>
    <td><input style="padding:10px;width:100%"type="text" name="alamat"required="required"></td>
    <td style="padding:10px;background:#dadada">Tahun ijazah</td>
    <td><input style="padding:10px;width:100%"type="date" name="nomorsurat"></td>
  </tr>
    <tr>
    <td style="padding:10px;background:#dadada">Tempat Lahir</td>
    <td><input style="padding:10px;width:100%"type="text" name="tempatlahir"></td>
    <td style="padding:10px;background:#dadada">Tanggal Lahir</td>
    <td><input style="padding:10px;width:100%"type="date" name="tgllahir"></td>
  </tr>
    <tr>
    <td style="padding:10px;background:#dadada">No. Handphone</td>
    <td><input style="padding:10px;width:100%" type="number" name="nomorhp"required="required"></td>
    <td style="padding:10px;background:#dadada">Email</td>
    <td><input style="padding:10px;width:100%"type="email" name="email"required="required"></td>
  </tr>
  </tr>
 
      <tr>

    <td style="padding:10px;background:#dadada">Foto profil</td>
    <td>

	<input style="border:1px solid grey;padding:10px;width:100%" ID="FileUpload1" onchange="IsFileSelected()" type="file" name="foto_mitra" size="999999" required="required"></td>

	<td style="padding:10px;background:#dadada">Passsword</td>
    <td><input style="padding:10px;width:100%"type="password" name="upass"required="required"></td>
  </tr>
<input style="padding:20px;width:100%"type="hidden" name="catatan"value="0">


			<tr> 
			  <td>		
</td>
    <td></td><td>
<input type="hidden" name="latmitra" value="-7.230642" />
<input type="hidden" name="lngmitra" value="112.702747" />
<input name="catatan"type="hidden"value="Daftar baru"/>
<input name="tgldaftar"type="hidden"value="<?php echo date('d-m-Y'); ?>"/>
<input name="dokumen"type="hidden"value="Belum"/>
<input name="signaturecode"type="hidden"value="0"/>
<input name="gbrsignature"type="hidden"value="0"/>
<input type="hidden" name="referalmitra"value="
<?php
function resi(){
$gpass=NULL;
$n = 8; // jumlah karakter yang akan di bentuk.
$chr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
for($i=0;$i<$n;$i++){
$rIdx = rand(1,strlen($chr));
$gpass .=substr($chr,$rIdx,1);
}
return $gpass;
};
echo resi(); 
?>"/>
<center><a href="index.php"><div style="background:red;width:200px;border:none;padding:10px;width:90%;color:#fff" class="testbutton">Batal</div></a>
</center>
				</td>
				<td><center><button style="background:green;width:200px;border:none;padding:10px;width:90%;color:#fff" class="testbutton" type="submit" name="submit" value="Simpan Data">Simpan Data</button></center></td>
			</tr>
		</table>
  
		<br>
	</form>
</body>
</html>

