<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT * FROM mitra ORDER BY id_mitra Asc");
?>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/> 
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>
<body style="padding:25px;"onload="window.print()"><center>
<h3>Data Mitra Medical GO</h3></center>
<div id="content">
<table width='100%'>

	<tr>
	<th >Foto</th>
		<th >Nama</th>
		<th >Alamat Kantor</th>
		<th >Pria / Wanita</th>
		<th >Alamat Tinggal</th>
		<th >Nomor handphone</th>
		<th >Kategori Medis</th>
		<th >Email</th>
	
		
	</tr>
	<?php 
	while($res = mysql_fetch_array($result)) { 		
		echo "<tr>";
		echo "<td width=10%><img width=100px src=../../foto_mitra/$res[foto_mitra]> </img></td>";
		echo "<td width=15%><b>".$res['nama_mitra']."  (".$res['kelamin'].")</b><br><br>KTP: ".$res['no_ktp']."<br>Tempat/Tgl Lahir: <br>".$res['tempatlahir']."/".$res['tgllahir']."<br><br>Pendidikan/ijazah :".$res['namadokumen']."<br>Tahun ijazah: ".$res['nomorsurat']."</td>";
		echo "<td width=5%>".$res['alamatkantor']."</td>";	
		echo "<td width=5%>".$res['kelamin']."</td>";	
		echo "<td width=15%>".$res['alamat']."</td>";
		echo "<td width=5%>".$res['nomorhp']."</td>";
		echo "<td width=10%>".$res['sebagai']."</td>";
		echo "<td width=10%>".$res['mitra_email']."</td>";
		echo "</tr>";	
		
	}
	?>
	</table><br>
</div>
<div id="editor"></div>
</body>
</html>
<script>
var doc = new jsPDF();
var specialElementHandlers = {
    '#editor': function (element, renderer) {
        return true;
    }
};

$('#cmd').click(function () {
    doc.fromHTML($('#content').html(), 15, 15, {
        'width': 170,
            'elementHandlers': specialElementHandlers
    });
    doc.save('sample-file.pdf');
});
</script>
