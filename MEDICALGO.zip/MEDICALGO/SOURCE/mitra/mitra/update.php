   <body> 
    <?php
	include_once("config.php");
$id_sopir = $_GET['id_sopir'];
	$query=mysql_fetch_array(mysql_query("select * from sopir where id_sopir='$id_sopir'"));
	$id_sopir=$query['id_sopir'];
	$nama_sopir = $query['nama_sopir'];
	$no_ktp = $query['no_ktp'];
	$foto_sopir = $query['foto_sopir'];
	$kelamin = $query['kelamin'];
	$sim = $query['sim'];
	$pengalaman = $query['pengalaman'];
	$kendaraan = $query['kendaraan'];
	$latsopir = $query['latsopir'];
	$lngsopir = $query['lngsopir'];
	$nomorhp = $query['nomorhp'];
	$dokumen = $query['dokumen'];
	$sopir_pass= $query['sopir_pass'];
	$sopir_email = $query['sopir_email'];
	?>
<form id="form"action="simpanupdate.php" enctype="multipart/form-data"  method="post" name="postform">
<input type="hidden" name="latsopir" value="<?php echo $latsopir;?>" />
<input type="hidden" name="lngsopir" value="<?php echo $lngsopir;?>" />
<input type="hidden" name="id_sopir" value="<?php echo $id_sopir;?>" />
<input type="hidden" name="foto_sopir" value="<?php echo $foto_sopir?>" />
<input type="hidden" name="sopir_pass" value="<?php echo $query['sopir_pass'];?>" />
<input  type="hidden" name="art_id" value="<?php echo $id_sopir;?>" />
<table>
<tr>
<td>Nama Mitra</td>
<td><input type="text" name="nama_sopir"required="required" value="<?php echo $nama_sopir;?>"></td>
</tr>
<tr>
<td>Foto Mitra</td>
<td><input type="file" name="foto_sopir" size="999999" value="<?php echo $foto_sopir;?>"/></td>
</tr>
<tr>
<td>Nomor KTP</td>
<td><input type="text" name="no_ktp"required="required" value="<?php echo $no_ktp;?>"></td>
</tr>
<tr>
<td>Pria / Wanita</td>
<td><input type="text" name="kelamin"required="required" value="<?php echo $kelamin;?>"></td>
</tr>
<tr>
<td>Alamat</td>
<td><input type="text" name="kendaraan"required="required" value="<?php echo $kendaraan;?>"></td>
</tr>
<input type="hidden" name="sim"value="0">
<td>Pengalaman (tahun)</td>
<td><input type="text" name="pengalaman"required="required" value="<?php echo $pengalaman;?>"></td>
</tr>
<tr>
<td>Nomor handphone</td>
<td><input type="int" name="nomorhp"required="required" value="<?php echo $nomorhp;?>"></td>
</tr>
<tr>
<td>Divisi/bagian</td>
<td>
<select name="dokumen"required=required>
<option name="dokumen" value="">-Pilihan sebagai-</option>
<option name="dokumen"value="admin">admin (hak akses super admin)</option>
<option name="dokumen"value="motor">Mitra</option>
<option name="dokumen"value="ambulance">Mitra dengan Ambulance</option>
</select></td>
      <td ><p></p></td>
    </tr>
<tr>
<td>Email</td>
<td><input type="email" name="sopir_email"required="required" value="<?php echo $sopir_email;?>"></td>
</tr>
<?php
if($dokumen=='admin')
      { ?>
<script>document.location.href="upadateadmin.php?id_sopir=<?php echo $id_sopir; ?>";</script>	  
	<?php
} else {?>
<tr>
<td>Password</td>
<td><input type="hidden" name="sipas"value="<?php echo $sopir_pass;?>"> Password Mitra tidak bisa diubah oleh Admin
</tr>
<?php } ?>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><input type="submit" value="Simpan"  onclick="return confirm('Apakah Anda yakin akan mengubah account?')"name="kirim" /><br><br><a href="index.php"style="color:orange">Batal Ubah data</a></td>
    </tr>
    </table>
    </form>
    <p><br /></p></body>