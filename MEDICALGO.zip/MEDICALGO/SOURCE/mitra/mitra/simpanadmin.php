<?php
include_once("../dbconnect.php");
if(isset($_POST['kirim'])){
	if (empty($_POST['mitra_pass'])) {
   ?>
<script>window.alert("Error... anda belum mengisi kolom password");document.location.href="about.php#open";</script><?php
  return false;
}

	$mitra_pass = $_POST['mitra_pass'];
	$kelamin = $_POST['kelamin'];
	$tempatlahir = $_POST['tempatlahir'];
	$tgllahir = $_POST['tgllahir'];
	$mitra_pass = md5($mitra_pass);
	$id_mitra=$_POST['id_mitra'];
	$nama_mitra = $_POST['nama_mitra'];
	$latmitra = $_POST['latmitra'];
	$lngmitra = $_POST['lngmitra'];
	$nomorhp = $_POST['nomorhp'];
	$alamat = $_POST['alamat'];
	$alamatkantor = $_POST['alamatkantor'];
    $no_ktp = $_POST['no_ktp'];
	$mitra_email = $_POST['mitra_email'];
	if(empty($_FILES['foto_mitra']['name'])){
		$foto_mitra=$_POST['foto_mitra'];
	}else{
		$foto_mitra=$_FILES['foto_mitra']['name'];
		//definisikan variabel file dan alamat file
		$uploaddir='../../foto_mitra/';
		$alamatfile=$uploaddir.$foto_mitra;
		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file($_FILES['foto_mitra']['tmp_name'],$alamatfile);
	}

	$query=mysql_query("UPDATE `mitra` SET `nama_mitra` = '$nama_mitra', `tempatlahir` = '$tempatlahir', `tgllahir` = '$tgllahir', `kelamin` = '$kelamin', `foto_mitra` = '$foto_mitra', `alamat` = '$alamat', `nomorhp` = '$nomorhp', `no_ktp` = '$no_ktp', `mitra_email` = '$mitra_email', `mitra_pass` = '$mitra_pass', `alamatkantor` = '$alamatkantor' WHERE `mitra`.`id_mitra` = '$id_mitra';");
	if($query){
		?>
		<script>document.location.href="index.php";</script>
		<?php
	

}}
?>