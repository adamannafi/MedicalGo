   <body> 
    <?php
	include_once("config.php");
$id_mitra = $_GET['id_mitra'];
	$query=mysql_fetch_array(mysql_query("select * from mitra where id_mitra='$id_mitra'"));
	$id_mitra=$query['id_mitra'];
	$nama_mitra = $query['nama_mitra'];
	$no_ktp = $query['no_ktp'];
	$foto_mitra = $query['foto_mitra'];
	$kelamin = $query['kelamin'];
	$sim = $query['sim'];
	$pengalaman = $query['pengalaman'];
	$alamat = $query['alamat'];
	$alamatkantor = $query['alamatkantor'];
	$latmitra = $query['latmitra'];
	$tempatlahir = $query['tempatlahir'];
	$tgllahir = $query['tgllahir'];
	$lngmitra = $query['lngmitra'];
	$nomorhp = $query['nomorhp'];
	$dokumen = $query['dokumen'];
	$mitra_pass= $query['mitra_pass'];
	$mitra_email = $query['mitra_email'];
	?>
<form id="form"action="simpanadmin.php" enctype="multipart/form-data"  method="post" name="postform">
<input type="hidden" name="latmitra" value="<?php echo $latmitra;?>" />
<input type="hidden" name="lngmitra" value="<?php echo $lngmitra;?>" />
<input type="hidden" name="id_mitra" value="<?php echo $_GET['id_mitra'];?>" />
<table>
<tr>
<td>Nama Admin</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="text"  name="nama_mitra"required="required" value="<?php echo $nama_mitra;?>"></td>
</tr>
<tr>
<td>Foto Admin</td>
<td><input type="file" style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" name="foto_mitra" size="999999" value="<?php echo $foto_mitra;?>"/></td>
</tr>
<tr>
<td>Nomor KTP</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="text"  name="no_ktp" required="required" value="<?php echo $no_ktp;?>"></td>
</tr>
<tr>
<td>Jenis Kelamin</td>
<td>
<select style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" name="kelamin">
<option value="">-Pilih Pria/Wanita-</option>
<option name="kelamin"value="Pria">Pria</option>
<option name="kelamin"value="Wanita">Wanita</option>
</select><br></td>
</tr>
<tr>
<td>Kota kelahiran</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="text"  name="tempatlahir"required="required" value="<?php echo $tempatlahir;?>"></td>
</tr>
<tr>
<td>Tgl Lahir</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="date"  name="tgllahir" value="<?php echo date('d-m-Y');?>"></td>
</tr>
<tr>
<td>Alamat tinggal</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="text"  name="alamat"required="required" value="<?php echo $alamat;?>"></td>
</tr>
<tr>
<td>Alamat kantor</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="text"  name="alamatkantor"value="<?php echo $alamatkantor;?>"></td>
</tr>
<input type="hidden" name="sim"value="0">
<tr>
<td>Nomor handphone</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="number"  name="nomorhp"required="required" value="<?php echo $nomorhp;?>"></td>
</tr>
<tr>
<td>Email</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="email" name="mitra_email"required="required" value="<?php echo $mitra_email;?>"></td>
</tr>
<tr>
<td>Password</td>
<td><input style="padding:15px;color:grey;width:100%;border:1px solid #09c;border-radius:20px;" type="password" name="mitra_pass"required="required" placeholder="Isikan Password, Jangan kosong">
</tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><input type="submit" value="Simpan"  onclick="return confirm('Apakah Anda yakin akan mengubah account?')"name="kirim" style="color:#09c;border:3px solid #09c;border-radius:20px;" />
	  <br><br><a href="index.php"style="color:orange">Batal Ubah data</a></td>
    </tr>
    </table>
    </form>
    <p><br /></p></body>