<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT * FROM mitra ORDER BY id_mitra Asc");
?>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/> 
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>

<body style="font-family:Monospace;"><center>
<h3>Data Mitra Medical GO</h3></center>
<table width="100%;background:#fff"><tr>
<td style="border-right:none;background:none"><center>
<a href="add.php"><div style="background:green;width:200px" class="testbutton"><small>Tambah Data Mitra Medical GO</small></div></a>
</center></td>
<td style="border-right:none;background:none">
<center><a href="lacaksales.php"><div style="background:green;width:200px" class="testbutton"><small>Tampilkan Lokasi Semua Mitra</small></div></a>
</center></td>
<td style="border-right:none;background:none">
<center><a href="print.php" target="blank"><button id="cmd" style="background:green;border:none"><div style="background:green;width:200px" class="testbutton"><small>Print Data Mitra</small></div></button></a>
</center></td>
</tr></table>
<div id="content">
<table width='100%'>

	<tr>
	<th >Foto</th>
		<th >Profile</th>
		<th >Alamat Kantor</th>
		<th >Pria / Wanita</th>
		<th >Alamat Tinggal</th>
		<th >Nomor handphone</th>
		<th >Kategori Medis</th>
		<th >Email</th>
<th >(x)</th>
	
		
	</tr>
	<?php 
	while($res = mysql_fetch_array($result)) { 	
$gadi=$res['saldo'];	
$saldo=$gadi/1000;
$sebagai=$res['sebagai'];
		echo "<tr>";
			echo"<td width='10%'>";?>
	<?php 
if (empty($res['foto_mitra'])) { ?>
<img src="../doctor-icon-png-24.png" style="width:100px"/>
<?php }else{ ?>
		<?php
	if($res['foto_mitra']=='0')
      {
		echo "<img width=100px src=../doctor-icon-png-24.png> </img>";
		  }
		  else {?>
<img src="../../foto_mitra/<?php echo $res['foto_mitra'];?>" style="width:100px"/>
<?php }}
		echo"</td>";
		echo "<td width=15%><b>".$res['nama_mitra']."  (".$res['kelamin'].")</b><br><br>KTP: ".$res['no_ktp']."<br>Tempat/Tgl Lahir: <br>".$res['tempatlahir']."/".$res['tgllahir']."<br>Saldo: RP.".$res['saldo']."</td>";
		echo "<td width=5%>".$res['alamatkantor']."</td>";	
		echo "<td width=5%>".$res['kelamin']."</td>";	
		echo "<td width=15%>".$res['alamat']."</td>";
		echo "<td width=5%>".$res['nomorhp']."</td>";
		echo "<td width=10%>".$res['sebagai']."</td>";
		echo "<td width=10%>".$res['mitra_email']."";
		?><br><center>
	<?php  if($res['catatan']=='1')
      {?>
	<small style="color:red">SUSPENSED</small><br><br>
		<a style="padding:5px;color:#fff;background:Orange" href="aktifkan.php?id_mitra=<?php echo $res['id_mitra'];?>">Activated</a>
 <?php }
  if($res['catatan']=='0')
      {?>
<small style=color:green>Active</small><br><br>
		<a style="padding:5px;color:#fff;background:red" href="suspens.php?id_mitra=<?php echo $res['id_mitra'];?>">SUSPEND</a>
  <?php }?></center>
	<?php
		echo "</td>";
		if($sebagai=='admin')
      {
		echo "<td width=5%> Admin jangan dihapus, nanti tidak bisa login di app admin<br><br>
		<a style=color:orange href=\"upadateadmin.php?id_mitra=$res[id_mitra]\">Edit data</a>
		</td>";  
	  }else {
		echo "<td width=5%> <a href=\"delete.php?id_mitra=$res[id_mitra]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
	  }
		echo "</tr>";	
		
	}
	?>
	</table><br>
</div>
<div id="editor"></div>
</body>
</html>
<script>
var doc = new jsPDF();
var specialElementHandlers = {
    '#editor': function (element, renderer) {
        return true;
    }
};

$('#cmd').click(function () {
    doc.fromHTML($('#content').html(), 15, 15, {
        'width': 170,
            'elementHandlers': specialElementHandlers
    });
    doc.save('sample-file.pdf');
});
</script>
