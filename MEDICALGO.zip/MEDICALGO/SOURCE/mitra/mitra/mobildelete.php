<?php
//including the database connection file
include("config.php");

//getting id of the data from url
$idambulance= $_GET['idambulance'];

//deleting the row from table
$result = mysql_query("DELETE FROM kendaraan WHERE idambulance=$idambulance");

//redirecting to the display page (index.php in our case)
header("Location:car.php");
?>

