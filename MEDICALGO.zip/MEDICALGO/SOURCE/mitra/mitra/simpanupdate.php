<?php
include_once("config.php");
if(isset($_POST['kirim'])){
	$id_sopir=$_POST['id_sopir'];
	$nama_sopir = $_POST['nama_sopir'];
	$foto_sopir = $_POST['foto_sopir'];
	$kelamin = $_POST['kelamin'];
	$sim = $_POST['sim'];
	$pengalaman = $_POST['pengalaman'];
	$kendaraan = $_POST['kendaraan'];
	$latsopir = $_POST['latsopir'];
	$lngsopir = $_POST['lngsopir'];
	$nomorhp = $_POST['nomorhp'];
        $no_ktp = $_POST['no_ktp'];
	$dokumen = $_POST['dokumen'];
	$sopir_email = $_POST['sopir_email'];
$sopir_pass = $_POST['sipas'];
	$art_id = $_POST['art_id'];
	$result = mysql_query("INSERT INTO  'zkeduct1_massase'.'ratings' ('id' ,'art_id' ,'total_votes' ,'total_points')VALUES (NULL ,  '$art_id',  '1',  '1')");
	if(empty($_FILES['foto_sopir']['name'])){
		$foto_sopir=$_POST['foto_sopir'];
	}else{
		$foto_sopir=$_FILES['foto_sopir']['name'];
		//definisikan variabel file dan alamat file
		$uploaddir='../../foto_sopir/';
		$alamatfile=$uploaddir.$foto_sopir;
		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file($_FILES['foto_sopir']['tmp_name'],$alamatfile);
	}

$query=mysql_query("update sopir set nama_sopir='$nama_sopir',foto_sopir='$foto_sopir',kelamin='$kelamin',sim='$sim',pengalaman='$pengalaman',kendaraan='$kendaraan',latsopir='$latsopir',lngsopir='$lngsopir',nomorhp='$nomorhp',no_ktp='$no_ktp',sopir_email='$sopir_email',sopir_pass='$sopir_pass', dokumen='$dokumen' where id_sopir='$id_sopir'");					
	if($query){
		?>
		<blockquote>
          <p></p>
		  <p>Data Anda berhasil disimpan...<br><a href='index.php'>Lihat</a></p>
		  <p></p>
		</blockquote>
		<?php
	}else{
		echo mysql_query();
	}
	

}else{
	unset($_POST['kirim']);
}
?>