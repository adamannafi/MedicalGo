<?php 
include "dbconnect.php";
$q=$_POST['q'];

// query untuk melakukan pencarian
$query=mysql_query("select * from transaksi where tujuan like '%".$q."%'");
// mendapatkan jumlah baris
$row=mysql_num_rows($query);

if ($row > 0) // jika baris lebih dari 0 / data ditemukan
{
	while ($data=mysql_fetch_array($query)) // perulangna untuk menampilkan data
	{
		// menampilkan data dalam bentuk table
		echo "<table width='100%' style='border-bottom:1px solid #d4d4d4;font-size:14px;padding:4px;'>
				<tr>
    				<td>".$data['tujuan']."</td>
    				<td>".$data['id_mitra']."</td>
				</tr>
			</table>";	
	}
}
else // jika data tidak ditemukan
{
	echo "<br><br><center><strong>Data tidak ditemukan</strong></center>";	
}
?>