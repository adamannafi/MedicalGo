<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT * FROM sensor");
?>
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>
<body style="font-family:Monospace;"><br><br>

<h3>Data Kota dengan Harga Khusus</h3><table width="100%"><tr><td>
<a href="../town/index.php"><div class="testbutton" style="width:200px">Kembali ke layanan</div></a></td><td>
<a href="add.html"><div class="testbutton" style="float:right">Add New Data</div></a><br/></td></tr></table>
Data kordinat beberapa titik di kota yang menggunakan harga layanan khusus <br> misalnya untuk menentukan harga layanan terapi di kota cianjur Rp. 50.000<br>
Titik kordinat akan mendeteksi user yang berada di area sekitar dengan jarak 20Km. Sehingga user yang terdeteksi gpsnya, akan mendapatkan harga layanan khusus<br>
	<table width='100%' border=0>

	<tr>
		<th>Nama Titik/Kota</th>
		<th>Latitude</th>
		<th>Longitude</th>
<th>x</th>
	
	</tr>
	<?php 
	while($res = mysql_fetch_array($result)) { 		
		echo "<tr>";
		echo "<td>".$res['nama_sensor']."</td>";
		echo "<td>".$res['latsensor']."</td>";
		echo "<td>".$res['lngsensor']."</td>";
echo "<td> <a href=\"delete.php?id_sensor=$res[id_sensor]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";				
	}
	?>
	</table>
</body>
</html>