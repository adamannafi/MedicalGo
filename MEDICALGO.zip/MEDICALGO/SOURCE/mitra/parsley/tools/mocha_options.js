export default {
  globals: [
    "$",
    "stub",
    "spy",
    "expect",
    "expectWarning",
  ],
};
