<?php
include_once("dbconnect.php");
if(isset($_POST['kirim'])){
	if (empty($_POST['timestart'])) {
   ?>
<script>window.alert("Waktu tidak terdeteksi");window.history.back(-2);</script><?php
  return false;
}
$id_trans=$_POST['id_trans'];
$timestart = $_POST['timestart'];
$timeend = $_POST['timeend'];

	$query=mysql_query("update transaksi set timestart='$timestart',timeend='$timeend' where id_trans='$id_trans'");
						
	if($query){
		?>
<script>window.history.back(-2);</script>
		<?php
	

}}
?>