<?php
session_start();
include "dbconnect.php";  
$id_mitra=$_SESSION['mitra'];

if(!isset($_SESSION['mitra']))
{
	header("Location:  ../admin-MedicalGO/index.php");
}
else if(isset($_SESSION['user'])!="")
{
	header("Location:  ../admin-MedicalGO/index.php");
}

if(isset($_GET['logout']))
{

	session_destroy();
	unset($_SESSION['mitra']);
	header("Location:  ../admin-MedicalGO/index.php");
}
?>