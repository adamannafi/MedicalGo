<?php
if(!mysql_connect("localhost","barisand_hospital","}c63AXvSHcrP"))
{
	die('oops connection problem ! --> '.mysql_error());
}
if(!mysql_select_db("barisand_hospital"))
{
	die('oops database selection problem ! --> '.mysql_error());
}

$jatuhtempo=date('d-m-Y');
$query = "SELECT COUNT(*) AS total FROM transaksi where status_trans='minta'"; 
$result = mysql_query($query); 
$values = mysql_fetch_assoc($result); 
$num_rows = $values['total']; 
echo $num_rows;
	   if ($num_rows==1)
	   {
		 ?>
<script>
document.getElementById('Android').click();
</script>

<?php
		   
	   }
?>
<script>
 function showAndroidDialog(dialogmsg) {
Android.showDialog(dialogmsg);
Android.play();
    }
</script>
<input style="visibility:hidden" type="button" id="Android" name="Android" onClick="showAndroidDialog('Ada request')" />
