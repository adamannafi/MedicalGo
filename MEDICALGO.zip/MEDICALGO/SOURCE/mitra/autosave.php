<?php
$res=mysql_query("SELECT * FROM mitra WHERE id=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
if(!mysql_connect("localhost","barisand_hospital","}c63AXvSHcrP"))
{
	die('oops connection problem ! --> '.mysql_error());
}
if(!mysql_select_db("barisand_hospital"))
{
	die('oops database selection problem ! --> '.mysql_error());
}
session_start();
if(!isset($_SESSION['mitra']))
{
	header("Location: firli.php#login");
}
$id=$_SESSION['mitra'];
$TokenCek = mysql_query("select * from mitra where id_mitra='$id'");
$latmitra = mysql_real_escape_string($_POST['lat']);
$lngmitra = mysql_real_escape_string($_POST['lng']);
$id = (int)$_POST['id'];
$computerId = $_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT'].$_SERVER['LOCAL_ADDR'].$_SERVER['LOCAL_PORT']; $benjo=str_replace(' ', '', $computerId);
if (empty($_POST['latmitra'])) {
mysql_query("update mitra set latmitra='-4.546317', lngmitra='136.889431' where id_mitra='$id'");
}
//save contents to database
mysql_query("update mitra set latmitra='$latmitra', lngmitra='$lngmitra' where id_mitra='$id'");
//get timestamp
//output timestamp
echo 'Last Saved bro '
?>