<?php
include_once("dbconnect.php");
if(isset($_POST['kirim'])){
	if (empty($_POST['lat'])) {
   ?>
<script>window.alert("Location not detected!");window.history.back(-2);</script><?php
  return false;
}
$id_mitra=$_POST['id_mitra'];
$latmitra = $_POST['lat'];
$lngmitra = $_POST['lng'];

	$query=mysql_query("update mitra set latmitra='$latmitra',lngmitra='$lngmitra' where id_mitra='$id_mitra'");
						
	if($query){
		?>
<script>window.history.back(-2);</script>
		<?php
	

}}
?>