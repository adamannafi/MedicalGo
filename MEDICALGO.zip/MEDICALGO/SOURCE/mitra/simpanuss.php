<?php
include_once("mitra/config.php");
if(isset($_POST['kirim'])){
if (empty($_POST['password'])) {
   ?><script>window.alert("Update Gagal!!...password Jangan dikosongkan!!");window.history.go(-1);</script><?php
      return false;
}	
$id =$_POST['id'];
$first_name =$_POST['first_name'];
$fotouser=$_POST['fotouser'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$jeniskelamin = $_POST['jeniskelamin'];
$ktp = $_POST['ktp'];
$password = $_POST['password'];
$password = md5($password);
	if(empty($_FILES['fotouser']['name'])){
		$fotouser=$_POST['fotouser'];
	}else{
		$fotouser=$_FILES['fotouser']['name'];
		
		//definisikan variabel file dan alamat file
		$uploaddir='../fotouser/';
		$alamatfile=$uploaddir.$fotouser;

		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file($_FILES['fotouser']['tmp_name'],$alamatfile);
	}

$query=mysql_query("update users set first_name='$first_name',email='$email',password='$password',phone='$phone',fotouser='$fotouser',jeniskelamin='$jeniskelamin',ktp='$ktp' where id='$id'");
												
if($query){
		?>
	<script>document.location.href="../home.php#setting";
</script>
		<?php
	}else{
		echo mysql_query();
	}
	

}else{
	unset($_POST['kirim']);
}
?>