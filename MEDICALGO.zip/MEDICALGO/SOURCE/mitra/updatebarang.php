<link rel="stylesheet"type="text/css"href="../demo.css"/>
<body style="padding:25px;color:#000">
<form action="simpanbarang.php" enctype="multipart/form-data"  method="post" name="postform">
   <body> 
    <?php
	include_once("dbconnect.php");
$id_barang = $_GET['id_barang'];
	$query=mysql_fetch_array(mysql_query("select * from barang where id_barang='$id_barang'"));
	$id_barang =$query['id_barang'];
	$nama_barang = $query['nama_barang'];
	$tipe= $query['tipe'];
	$keterangan_barang= $query['keterangan_barang'];
	$harga_harian= $query['harga_harian'];
	$harga_bulanan= $query['harga_bulanan'];
	$pemilik= $query['pemilik'];
	$gambar= $query['gambar'];
	$jenis= $query['jenis'];
	$alamat_barang= $query['alamat_barang'];
	$ada= $query['ada'];
$gambar= $query['gambar'];
	?>
<center><h3 style="color:#000">Ubah Data Mobil</h3></center>
<p>
<?php
 if($gambar=='0')
      { ?><center>
<img src="../nopic.png" style="width:300px;top:0;"/>
<?php }else{?>
<img src="../fotobarang/<?php echo $gambar;?>" style="width:300px;top:0;"/></center>
<?php } ?>
</p>
    <input type="hidden" name="id_barang" value="<?php echo $id_barang;?>" />
    <input type="hidden" name="gambar" value="<?php echo $gambar;?>" />
    <input type="hidden" name="ada" value="1" />
<label>Nama Chemical</label>
<input type="text" placeholder="nama barang" name="nama_barang" required="required" value="<?php echo $nama_barang;?>"></br></br>
<label>Ukuran/isi</label>
<input name="tipe" placeholder="tipe"value="<?php echo $tipe;?>"/></br></br>
<label>Tipe Chemical</label>
<input type="text" placeholder="Tipe Chemical" name="jenis"required="required" value="<?php echo $jenis;?>"></br></br>
<label>Harga chemical</label>
<input type="text" placeholder="tuliskan harga chemical (nominal nya saja)" name="harga_bulanan"required="required" value="<?php echo $harga_bulanan;?>"></br></br>
<label>Fungsi Chemical</label>
<textarea type="text" placeholder="Tuliskan Cara penggunaan" name="harga_harian"required="required" value="<?php echo $harga_harian;?>"></textarea></br></br>
<label>Cara penggunaan</label>
<textarea placeholder="alamat"name="alamat_barang"required="required" value="<?php echo $alamat_barang;?>"></textarea></br></br>
<label>Rincian</label>
<textarea style="height:150px"placeholder="Tuliskan rincian warna mobil, fasilitas dan layanan yang diberikan ke customer"name="keterangan_barang"required="required" value="<?php echo $keterangan_barang;?>"></textarea></br></br>

<center>
      <input type="submit" value="Simpan"  onclick="return confirm('Tambahkan Gambar nanti, Apakah Anda yakin akan ubah data barang?')"name="kirim" /><br><br>

    </form>
<a href="javascript:history.go(-1)"style="color:orange">Batal Ubah data</a></center>
   <br /></body>