<?php
session_start();
include_once 'dbconnect.php';

if(isset($_POST['btn-signup']))
{
	$nama_mitra = mysql_real_escape_string($_POST['uname']);
	$mitra_email = mysql_real_escape_string($_POST['email']);
	$mitra_pass = md5(mysql_real_escape_string($_POST['pass']));
	$kelamin = mysql_real_escape_string($_POST['kelamin']);
	$no_ktp = mysql_real_escape_string($_POST['no_ktp']);
	$dokumen = mysql_real_escape_string($_POST['dokumen']);
	$foto_mitra = mysql_real_escape_string($_POST['foto_mitra']);
	$tempatlahir = mysql_real_escape_string($_POST['tempatlahir']);
	$tgllahir = mysql_real_escape_string($_POST['tgllahir']);
	$alamat = mysql_real_escape_string($_POST['alamat']);
	$latmitra = mysql_real_escape_string($_POST['lat']);
	$lngmitra = mysql_real_escape_string($_POST['lng']);
	$nomorhp = mysql_real_escape_string($_POST['nomorhp']);
	$nomorhp2 = mysql_real_escape_string($_POST['nomorhp2']);
	$nik = mysql_real_escape_string($_POST['nik']);
	$tgldaftar = mysql_real_escape_string($_POST['tgldaftar']);
	$referalmitra = mysql_real_escape_string($_POST['referalmitra']);
	$alamatkantor = mysql_real_escape_string($_POST['alamatkantor']);
	$catatan = mysql_real_escape_string($_POST['catatan']);
	$sebagai = mysql_real_escape_string($_POST['sebagai']);
	$signaturecode = mysql_real_escape_string($_POST['signaturecode']);
	$gbrsignature = mysql_real_escape_string($_POST['gbrsignature']);
	$namadokumen = mysql_real_escape_string($_POST['namadokumen']);
	$nomorsurat = mysql_real_escape_string($_POST['nomorsurat']);
	$saldo = mysql_real_escape_string($_POST['saldo']);
	$nama_mitra = trim($nama_mitra);
	$mitra_email = trim($mitra_email);
	$mitra_pass = trim($mitra_pass);
	// email exist or not
	$query = "SELECT mitra_email FROM mitra WHERE mitra_email='$mitra_email'";
	$result = mysql_query($query);
	
	$count = mysql_num_rows($result); // if email not found then register
	
	if($count == 0){
		
		if(mysql_query("INSERT INTO `mitra` (`id_mitra`, `nama_mitra`, `foto_mitra`, `kelamin`, `tempatlahir`, `tgllahir`, `alamat`, `latmitra`, `lngmitra`, `nomorhp`, `no_ktp`, `mitra_email`, `mitra_pass`, `dokumen`, `nomor_hp2`, `nik`, `alamatkantor`, `catatan`, `sebagai`, `referalmitra`, `tgldaftar`, `comission`, `signaturecode`, `gbrsignature`, `namadokumen`, `nomorsurat`, `saldo`) VALUES (NULL, '$nama_mitra', '$foto_mitra', '$kelamin', '$tempatlahir', '$tgllahir', '$alamat', '$latmitra', '$lngmitra', '$nomorhp', '$no_ktp', '$mitra_email', '$mitra_pass', '$dokumen', '$nomor_hp2', '$nik', '$alamatkantor', '$catatan', '$sebagai', '$referalmitra', '$tgldaftar', '$comission', '$signaturecode', '$gbrsignature', '$namadokumen', '$nomorsurat', '$saldo');"))
		{
			?><div style="color: #329600;
    position: fixed;
    z-index: 9999999;
    background-color: #FFF;
    padding: 30px;width:100%;height:100%">Formulir Pendaftaran diterima admin, silahkan login dengan data yang sudah di daftarkan.<br> Tunggu Pesan Email dari kami,<br> kami akan meminta beberapa persyaratan dokumen untuk verifikasi.<br><br> <center><b><a style="color:orange"href="fdex.php#login">Langsung Login</a></b></center></div><?php
		}
		else
		{
			?><div style="color: #FF0000;">Server Sibuk,Coba Ulangi</div><?php
		}		
	}
	else{
			?><div style="color: #FF0000;">Email/ID sudah dimiliki oranglain</div><?php
	}
	
}
?>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../demo.css"/>
<link rel="stylesheet" href="../css/bemo.css">
<link rel="stylesheet" href="../dist/ladda.min.css"></head>
<body>
<link href="parsley/bower_components/bootstrap/dist/css/bootstrap.css" rel="stylesheet">
<link href="parsley/doc/assets/docs.css" rel="stylesheet">
<link href="parsley/src/parsley.css" rel="stylesheet">
<style class="example">
.form-section {
  padding-left: 15px;
  border-left: 2px solid #FF851B;
  display: none;
}
.form-section.current {
  display: inherit;
}
.btn-info, .btn-default {
  margin-top: 10px;
}
</style>

<script src="parsley/bower_components/jquery/dist/jquery.min.js"></script>
<div id="reg"class="panel">
<div class="content">
<script type="text/javascript"src="//maps.google.com/maps/api/js?sensor=true"></script>
<script>if(!navigator.geolocation){alert("Your phone does not support maps Location.")}navigator.geolocation.getCurrentPosition(success,error);function success(f){var g=f.coords.latitude;var e=f.coords.longitude;var h=f.coords.accuracy;document.getElementById("lat").value=g;document.getElementById("lng").value=e}function error(b){alert("ERROR("+b.code+"): "+b.message)};
</script>
<form style="color:#444;padding:20px;" method="post">
<input name="lat"type="hidden"id="lat"/>
<input name="lng"type="hidden"id="lng"/>
<input name="catatan"type="hidden"value="0"/>
<input name="tgldaftar"type="hidden"value="<?php echo date("Y-m-d"); ?>"/>
<input name="comission"type="hidden"value="10"/>
<input name="dokumen"type="hidden"value="Belum"/>
<input name="foto_mitra"type="hidden"value="0"/>
<input name="signaturecode"type="hidden"value="0"/>
<input name="gbrsignature"type="hidden"value="0"/>
<input name="namadokumen"type="hidden"value="0"/>
<input name="nomorsurat"type="hidden"value="0"/>
<input name="saldo"type="hidden"value="100000"/>
<input type="hidden" name="referalmitra"value="
<?php
function resi(){
$gpass=NULL;
$n = 8; // jumlah karakter yang akan di bentuk.
$chr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
for($i=0;$i<$n;$i++){
$rIdx = rand(1,strlen($chr));
$gpass .=substr($chr,$rIdx,1);
}
return $gpass;
};
echo resi(); 
?>"/>
<br>
<center><b>SignUp</b><br><h3>Registrasi Medis Baru</h3></center>
<br>
<label>Lengkapi identitas</label>
<select class="form-control" name="kelamin"required=required>
<option value="">-Pilih Pria/Wanita-</option>
<option name="kelamin"value="Pria">Pria</option>
<option name="kelamin"value="Wanita">Wanita</option>
</select><br>
<input class="form-control" type='text'name="uname"placeholder="Nama Lengkap Anda"required="required"/><br>
<input class="form-control" type='email'name="email"placeholder="Email Untuk Login"required="required"/><br>
<input class="form-control" type='password'name="pass"placeholder="Password Untuk Login"required="required"/><br>
<input class="form-control" type='number'name="no_ktp"placeholder="Nomor KTP"required="required"/><br>
<input class="form-control" type='text'name="nik"placeholder="Masukkan Nip kepegawaian(opsional dari instansi mitra)"/><br>
<input class="form-control" type='text'name="tempatlahir"placeholder="Tempat lahir (Sesuai KTP)"required="required"/><br>
<input class="form-control" type='date'name="tgllahir"placeholder="Tanggal lahir (Sesuai KTP)"required="required"/><br>
<input class="form-control" type='text'name="alamat"placeholder="Alamat tinggal (Sesuai KTP)"required="required"/><br>
<label>Lengkapi Informasi pribadi</label>
<select class="form-control" name="sebagai"required=required>
<option value="">-Mendaftar Sebagai-</option>
<option name="sebagai"value="Medis">Medis</option>
<option name="sebagai"value="Bidan">Perawat/Bidan (Khusus menangani perawatan)</option>
</select><br>
<input class="form-control" type='text'name="alamatkantor"placeholder="Alamat Kantor (opsional)"/><br>
<input class="form-control" type='number'name="nomorhp"placeholder="Nomor Handphone"required="required"/><br>

<br>
<button style="width:100%;height:auto"type="submit"name="btn-signup"class="ladda-button" data-color="blue" data-style="expand-right">Submit</button></form></center></div></div>

<div id="kon" class="panel"><div class="content" style="font-size:11px;padding:20px">
<h3>KEBIJAKAN PRIVASI</h3><br>
Kami di Aplikasi Medical Go menjaga privasi Anda dengan sangat serius. Kami percaya bahwa privasi elektronik sangat penting bagi keberhasilan berkelanjutan dari Internet. Kami percaya bahwa informasi ini hanya dan harus digunakan untuk membantu kami menyediakan layanan yang lebih baik. Itulah sebabnya kami telah menempatkan kebijakan untuk melindungi informasi pribadi Anda.
<br><br>
<h3>RINGKASAN KEBIJAKAN</h3>

Secara umum, Anda akan tetap sebagai anonim ketika Anda menggunakan Aplikasi web kami dan mengakses informasi. Sebelum kami meminta Anda untuk mengisi informasi, kami akan menjelaskan bagaimana informasi ini akan digunakan. Kami tidak akan memberikan informasi pribadi Anda kepada perusahaan lain atau individu tanpa se-izin Anda.

Beberapa bagian dari Aplikasi kami memerlukan pendaftaran untuk mengaksesnya, walaupun biasanya semua yang diminta adalah berupa alamat e-mail dan beberapa informasi dasar tentang Anda.

Ada bagian di mana kami akan meminta informasi tambahan. Kami melakukan ini untuk dapat lebih memahami kebutuhan Anda, dan memberikan Anda palayanan yang kami percaya mungkin berharga bagi Anda. Beberapa contoh informasi Aplikasi kami butuhkan seperti nama, email, alamat rumah, dan info pribadi. Kami memberikan Anda kesempatan untuk memilih untuk tidak menerima materi informasi dari kami.
<br><br>
<h3>PERLINDUNGAN PRIVASI</h3>

Kami akan mengambil langkah yang tepat untuk melindungi privasi Anda. Setiap kali Anda memberikan informasi yang sensitif (misalnya, nomor kartu kredit untuk melakukan pembelian), kami akan mengambil langkah-langkah yang wajar untuk melindungi, seperti enkripsi nomor kartu Anda. Kami juga akan mengambil langkah-langkah keamanan yang wajar untuk melindungi informasi pribadi Anda dalam penyimpanan. Nomor kartu kredit hanya digunakan untuk proses pembayaran dan bukan disimpan untuk tujuan pemasaran. Kami tidak akan memberikan informasi pribadi Anda kepada perusahaan lain atau individu tanpa izin Anda. "Proses order anda kami pastikan aman sebab dengan sistem pembayaran sewa langsung. pembayaran diterima oleh pemilik Mitra Kendaraan/property"
<br><br>
<h3>PENGGUNAAN COOKIE</h3>

Aplikasi ini menggunakan "cookies" untuk mengidentifikasi sesi pengguna pada Aplikasi dan dengan demikian menawarkan kontinuitas selama anggota bernavigasi di dalam Aplikasi. Cookie hanya digunakan pada Aplikasi untuk menyimpan data yang non-kritis. Cookies adalah potongan informasi dimana informasi tersebut ditransfer ke hard drive Smartphone Anda untuk tujuan menyimpan catatan.

Cookie memungkinkan Aplikasi web untuk menjaga informasi pengguna di seluruh koneksi. Cookie berupa string kecil berupa karakter yang digunakan oleh banyak Aplikasi untuk mengirimkan data ke Smartphone Anda, dan dalam keadaan tertentu, mengembalikan informasi ke Aplikasi web. Cookie hanya berisi informasi yang direlakan oleh anggota, dan mereka tidak memiliki kemampuan infiltrasi hard drive pengguna dan mencuri informasi pribadi. Fungsi sederhana cookie adalah membantu pengguna bernavigasi di Aplikasi dengan dengan kendala sesedikit mungkin.

Aplikasi Medical Go mungkin menggunakan perusahaan iklan luar untuk menampilkan iklan di Aplikasi kami. Iklan ini mungkin mengandung cookies, yang tampaknya datang dari Aplikasi web, tetapi pada kenyataannya mereka datang dari mitra kami yang melayani iklan di Aplikasi. Aplikasi tertentu dapat menempatkan "cookie" pada Smartphone Anda untuk memberikan layanan personalisasi dan / atau mempertahankan identitas Anda di beberapa halaman dalam satu sesi.
<br><br>
<h3>KEAMANAN</h3>

Aplikasi ini memiliki langkah-langkah keamanan untuk melindungi kehilangan, penyalahgunaan dan perubahan informasi di dalam kendali kita. Langkah-langkah ini meliputi metode perlindungan data dasar dan kompleks, penyimpanan informasi tertentu secara offline dan pengamanan server database kami. Aplikasi ini memberikan pilihan bagi para pengguna untuk menghapus informasi mereka dari database kami untuk tidak menerima informasi kedepannya atau untuk tidak lagi menerima layanan kami.
<br><br><p>
<center>
<a href="reg.php#reg" onclick="javascript:showDiv();"><button style="width:200px;font-size:12px;height:auto;margin-top:-20px;padding-bottom:20px;"class="ladda-button"data-color="blue">Setuju & Lanjutkan</button></a>
</p><br><br></center>
</div></div>		
</body>
<script src="../dist/spin.min.js"></script>
		<script src="../dist/ladda.min.js"></script>
    <script src="parsley/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="parsley/bower_components/bootstrap/js/affix.js"></script>

    <script src="parsley/dist/parsley.js"></script>
	    <script class="example">
$(function () {
  var $sections = $('.form-section');

  function navigateTo(index) {
    // Mark the current section with the class 'current'
    $sections
      .removeClass('current')
      .eq(index)
        .addClass('current');
    // Show only the navigation buttons that make sense for the current section:
    $('.form-navigation .previous').toggle(index > 0);
    var atTheEnd = index >= $sections.length - 1;
    $('.form-navigation .next').toggle(!atTheEnd);
    $('.form-navigation [type=submit]').toggle(atTheEnd);
  }

  function curIndex() {
    // Return the current index by looking at which section has the class 'current'
    return $sections.index($sections.filter('.current'));
  }

  // Previous button is easy, just go back
  $('.form-navigation .previous').click(function() {
    navigateTo(curIndex() - 1);
  });

  // Next button goes forward iff current block validates
  $('.form-navigation .next').click(function() {
    $('.demo-form').parsley().whenValidate({
      group: 'block-' + curIndex()
    }).done(function() {
      navigateTo(curIndex() + 1);
    });
  });

  // Prepare sections by setting the `data-parsley-group` attribute to 'block-0', 'block-1', etc.
  $sections.each(function(index, section) {
    $(section).find(':input').attr('data-parsley-group', 'block-' + index);
  });
  navigateTo(0); // Start at the beginning
});
    </script>
    <script src="parsley/doc/assets/example.js"></script>
		<script>
			// Bind normal buttons
			Ladda.bind( '.button-demo button' );
			Ladda.bind( '.progress-demo button', {
				callback: function( instance ) {
					var progress = 0;
					var interval = setInterval( function() {
						progress = Math.min( progress + Math.random() * 0.1, 1 );
						instance.setProgress( progress );
						if( progress === 1 ) {
							instance.stop();
							clearInterval( interval );
						}
					}, 200 );
				}
			} );
		</script>