<?php
if(!mysql_connect("localhost","lapakren_android","}c63AXvSHcrP"))
{
	die('oops connection problem ! --> '.mysql_error());
}
if(!mysql_select_db("lapakren_android"))
{
	die('oops database selection problem ! --> '.mysql_error());
}
?>