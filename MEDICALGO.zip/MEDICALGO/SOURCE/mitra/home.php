<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: firli.php#login");
}
$res=mysql_query("SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
 if($rows['sebagai']=='admin')
      {
	header("Location: dashboard.php");	  
	  }
	  	  if($rows['saldo']<'20000')
      { ?>
<script>document.location.href="saldohabis.php#saldo";</script>
<?php }  ?>
<noscript>
<?php
$now = date("Y-m-d");

$tanggalSekarang=$rows['tgldaftar'];
$newTanggalSekarang=strtotime($tanggalSekarang);
$jumlahHari=30*12;
$NewjumlahHari=86400*$jumlahHari;
$hasilJumlah = $newTanggalSekarang + $NewjumlahHari;
$tampilHasil=date('Y-m-d', $hasilJumlah);
if($now>=$tampilHasil)
      { ?>
<script>document.location.href="home.php#registerulang";</script>
<?php } 
?></noscript>
<?php 
$id_mitra = $_SESSION['mitra'];
$view=mysql_query("SELECT * FROM transaksi where id_mitra='$id_mitra'");
while($row=mysql_fetch_array($view)){
	?>
<?php 
 if($row['status_trans']=='dijemput')
      { ?>
<script>document.location.href="jemput.php";</script>
<?php } ?>
<?php 
 if($row['status_trans']=='otw')
      { ?>
<script>document.location.href="jemput.php";</script>
<?php	}} ;
 ?>
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../demo.css"/>
<link rel="stylesheet" media="screen" href="../js/twitnotif.css">
<link rel="stylesheet"href="../css/bemo.css">
<link rel="stylesheet"href="../dist/ladda.min.css">
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:#000;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:0;top:35px;margin-left:-30px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("../hourglass.svg");background-repeat:no-repeat;background-position:center}
</style>
<style>
        #notification_count {
			font-weight:bold
            padding: 4px;
            color: #ffffff;
            font-weight: bold;
            border-radius: 9px;
            -moz-border-radius: 9px;
            -webkit-border-radius: 9px;
            position: absolute;
            margin-top: -1px;
            font-size: 12px;
        }
    </style>

    <script src="../js/twitnotif2.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" charset="utf-8">
        function addmsg(type, msg) {

            $('#notification_count').html(msg);
        }

        function waitForMsg() {

            $.ajax({
                type: "GET",
                url: "select.php",

                async: true,
                cache: false,
                timeout: 25000,

                success: function(data) {
                    addmsg("new", data);
                    setTimeout(
                        waitForMsg,
                        20000
                    );
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    addmsg("error", textStatus + " (" + errorThrown + ")");
                    setTimeout(
                        waitForMsg,
                        25000);
                }
            });
        };

        $(document).ready(function() {

            waitForMsg();

        });
    </script>

</head>
<style>
nav{height:100%;width:280px;background-color:#ffff;left:0;top:0;z-index:9999;position:fixed;overflow-y:auto;overflow-x:visible;transform:translate(-280px,0);-webkit-box-shadow:0 2px 2px 0 rgba(0,0,0,0.14),0 3px 1px -2px rgba(0,0,0,0.12),0 1px 5px 0 rgba(0,0,0,0.2);box-shadow:0 2px 2px 0 rgba(0,0,0,0.14),0 3px 1px -2px rgba(0,0,0,0.12),0 1px 5px 0 rgba(0,0,0,0.2)}.ssm-overlay{position:fixed;top:0;right:0;bottom:0;left:0;background-color:rgba(0,0,0,0.2);display:none;z-index:1}*,*::before,*::after{box-sizing:border-box}ul *{margin:0;padding:0}img{max-width:100%}.is-navOpen{overflow:hidden}a{color:#0a4a3c}h1{font-weight:normal;font-size:50px}nav.nav{z-index:9999;color:#fff}
</style>

<body>
<nav class="nav" style="color:#444;height:100%;background-color:#dedede;z-index:99999">
<center>
<img src="../profile.png" style="margin-top:60px;width:90px;height:auto;top:0"/>
<br><i style="color:#444;margin-top:40px"><?php echo $rows['nama_mitra'];?> (Medis)<br></i></center>

<br><br><a onclick="myFunction()" href="home.php#dashboard" style="padding-left:25px;padding-bottom:20px;font-size:12px;"><img style="vertical-align:middle" src="../dist/pay.png" width="18px" /> Dashboard</a>
<br><br><a onclick="myFunction()" href="home.php#saldo" style="padding-left:25px;padding-bottom:20px;font-size:12px;"><img style="vertical-align:middle" src="../dist/free.png" width="18px"/> Saldo</a>
<br><br><a onclick="myFunction()" href="home.php#setting" style="padding-left:25px;padding-bottom:20px;font-size:12px;"><img style="vertical-align:middle" src="../dist/setting.png" width="18px"/> Pengaturan Profile</a>
<br><br><a onclick="myFunction()" href="home.php#payment" style="padding-left:25px;padding-bottom:20px;font-size:12px;"><img style="vertical-align:middle" src="../dist/history.png" width="18px"/> Riwayat Transaksi</a>
<!---
<li><a href="home.php#promo" style="font-size:12px;"><img style="vertical-align:middle" src="dist/free.png" width="18px"/> Menu Promo</a></li>
<li><a href="home.php#unggul" style="font-size:12px;"><img style="vertical-align:middle" src="dist/free.png" width="18px"/> Menu Unggulan</a></li>
<li><a href="home.php#laris" style="font-size:12px;"><img style="vertical-align:middle" src="dist/free.png" width="18px"/> Menu Terlaris</a></li>
<li><a href="home.php#iklan" style="font-size:12px;"><img style="vertical-align:middle" src="dist/free.png" width="18px"/> Pembayaran Iklan</a></li>
--->
<br><br><a href="logout.php?logout" style="padding-left:25px;padding-bottom:20px;font-size:12px;"><img style="vertical-align:middle" src="../dist/logout.png" width="18px"/> Log Out</a>

</nav>
<script>
function myFunction() {
document.getElementById('ssm-toggle-nav').click();
}
</script>
 <a style="position:fixed;padding-left:25px;padding-top:15px;z-index:999999;" id="ssm-toggle-nav" class="ssm-toggle-nav" ><img src="fa-list-ul.png"width="25px"/></a>


<div class="sodrops-top" style="height:60px;">
<span class="actions">
<ul>
<li style="margin-left:-20px"><div id="HTMLnoti" style="textalign:center;"><a href="home.php#dashboard"><img src="notif.png"width="25px"/><span id="notification_count"></span></a></div></li>
<li><a href="home.php#payment"><img src="fa-usd.png"width="25px"/></a></li>
<script src="../js/twitnotif3.js"></script>
<script src="../js/twitnotif4.js"></script>
</ul>
</span>
<div style="color:#fff;margin-left:60px;font-size:18px;font-weight:bold"><img src="../logo.png"width="40px"/>
</div>
</div>
<main>	
<div id="saldo"class="panel" style="background:#fff"><div class="content" style="background:#fff;color:#000"><br><br><br><br>
<center style="color:#000"><h4>Saldo anda saat ini:</h4>
<b>Rp. <?php 

$sistim = $rows['saldo'];

$saldo = number_format($sistim,0,",",".");

echo $saldo;?></b>
</center><br>
<center style="padding:10px;font-size:12px;color:grey;font-family:Segoe UI light">Saldo minimal untuk ambil job adalah 20.000, anda bisa melakukan deposit ke akun anda atau widthdraw saldo ke rekening anda</center>
<br>
<center style="font-size:14px;color:#000;font-family:Segoe UI;background:#dedede;border-top:1px solid grey;border-bottom:1px solid grey;border-style:dashed">
<?php 

$her=mysql_query("SELECT * FROM infobank where idinfo='1'");

$mul=mysql_fetch_array($her);

$milk=mysql_query("SELECT * FROM trans_mitra where idmitra=".$_SESSION['mitra']);

while($ent=mysql_fetch_array($milk)){

 if($ent['statussaldo']=='minta')

      { 

   if($ent['tipesaldo']=='topup')

      { ?>
<b><small>Anda request Topup</small></b><br><br>
Silahkan melakukan transfer ke rekening admin MedicalGO:<br>
Senilai: Rp. <?php echo $mul['jumlahsaldo'];?><br>
Nama bank: <?php echo $mul['namabank'];?><br>
Nomor Rekening: <?php echo $mul['norek'];?><br>
Atas nama: <?php echo $mul['namaorang'];?><br><br>
jam operasional finance MedicalGO: <?php echo $mul['jambuka'];?><br>
<small>Setelah transfer, segera lakukan konfirmasi pembayaran</small><br><br>
<center>
<a href="#konfirmasi">
<button style="width:100%;font-size:15px;height:auto;margin-top:0px;padding-bottom:20px;border-radius:0px"class="ladda-button"data-color="green">Konfirmasi pembayaran</button>
</a>
</center>
<?php }

	  if($ent['tipesaldo']=='withdraw')

      {?>
<b><small>Anda request Withdrawal Senilai Rp. <?php echo $ent['jumlahsaldo'];?><br></small></b><br><br>
<? }}

 if($ent['statussaldo']=='dijemput')

 {

?><br>
<b><small>Request <?php echo $ent['tipesaldo'];?> Anda sedang diproses Admin</small></b><br><br>
<?php }}

$input = "SELECT * FROM trans_mitra WHERE idmitra='".$_SESSION['mitra']."' and statussaldo='minta' or statussaldo='dijemput'";

$result = mysql_query($input);

$count = mysql_num_rows($result);

if($count == 0){?>
</center><center>
<section class="button-demo" style="padding:0;width:100%">
<a href="topup.php?id_mitra=<?php echo $rows['id_mitra'];?>"><button style="width:100%;border-radius:0px" class="ladda-button" data-color="blue" data-style="expand-right">
<small>Toup Up/Deposit saldo</small></button></a>
</section>
<center>
<a href="wd.php?id_mitra=<?php echo $rows['id_mitra'];?>">
<button style="width:100%;font-size:15px;height:auto;margin-top:0px;padding-bottom:20px;border-radius:0px"class="ladda-button"data-color="green">Withdraw Saldo</button>
</a>
</center>
<?php }?>
</div></div>
<div id="payment" class="panel" style="overflow:auto"><div class="content" style="overflow:auto"><br><br><br>
<div style="border-bottom:1px solid #8c8c8c;color:#616161;font-size:14px">
Layanan Selesai
</div>
<?php
$id_mitra = $_SESSION['mitra'];
$kim=mysql_query("SELECT * FROM transaksi where id_mitra='$id_mitra' ORDER BY id_trans DESC LIMIT 100");
while($bow=mysql_fetch_array($kim)){
if($bow['aktif']=='no')
      { ?>
<table style="margin-top:5px;"id="iseqchart">
<tr style="font-size:12px;color:#565656"><td>Kode Invoice</td><td>:</td><td width="50%"> <?php echo $bow['invoice']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Tipe Layanan</td><td>:</td><td width="50%"> <?php echo $bow['layanan']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Tanggal Request</td><td>:</td><td width="50%"> <?php echo $bow['tanggal']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Waktu Kunjungan</td><td>:</td><td width="50%"> <?php echo $bow['timepicker1']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Total</td><td>:</td><td width="50%"> Rp.<?php 
$layanan = $bow['harga'];
$harga = number_format($layanan,0,",",".");
echo $harga;?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Atas Nama</td><td>:</td><td width="50%"> <?php echo $bow["nama_rumah"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Alamat</td><td>:</td><td width="50%"> <?php echo $bow["alamat"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Status</td><td>:</td><td width="50%"> Selesai</td></tr>

</table>
<?php }};?>
<table width="100%" style="color:orange;width:100%;z-index:9999;bottom:0;position:fixed;background-color:#ffff97;box-shadow: 0 2px 5px rgba(0,0,0,.26);">
<tr>
<td style="font-size:11px;padding:10px"width="35%"><center>Total pendapatan</center></td>
<td style="padding:10px"width="10%"><center>-</center></td>
<td style="font-size:11px;padding:10px"width="55%"><center>Rp. 
<?php
$id_mitra = $_SESSION['mitra'];
$tim=mysql_query("SELECT sum(harga) FROM transaksi WHERE id_mitra='$id_mitra' and aktif='no'");
while($pin = mysql_fetch_array($tim)) { 
?>
<?php 
$papa = $pin['sum(harga)'];
$kala = number_format($papa,0,",",".");
echo $kala;?>,-
<?php } ?>
</center></td>
</tr>
</table><br><br><br><br><br>
</div></div>
<div id="dashboard"class="parsel" style="overflow:auto">
<div class="content" style="overflow:auto"><br>
<script src="autorefresh.js"></script>
 <script type="text/javascript">
 $(document).ready(function() {
        loadData();
    });

    var loadData = function() {
        $.ajax({    //create an ajax request to load_page.php
            type: "GET",
            url: "getuser.php",             
            dataType: "html",   //expect html to be returned                
            success: function(response){                    
                $("#rekok").html(response);
                setTimeout(loadData, 5000); 
            }

        });
    };

</script>
<div id="rekok" align="left"></div>
<br><br><br>
</div>
</div>
<div id="setting"class="panel">
<div class="content"><br>
<div style="border-bottom:1px solid #8c8c8c;color:#616161;font-size:14px">Setting Profile
</div><style>
#hideme {
    -webkit-animation: cssAnimation 15s forwards; 
    animation: cssAnimation 15s forwards;
}
@keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
@-webkit-keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
</style>
<?php if($rows['catatan']=='')
      { ?>
<div id="hideme"style="width:100%;position:relative;color:#ef2525;z-index:99999;top:0px;padding:20px;box-shadow:5px 2px 8px 1px rgba(0,0,0,0.15);background-color:rgba(255, 255, 82, 0.95)">
<center><small>Lengkapi Informasi Nama pemilik rekening atau rekening anda, untuk tujuan transfer ketika withdraw</small>
<br></center>
</div><?php }else{ ?>
<?php } ?>
<form style="font-size:11px" id="form"action="save.php" enctype="multipart/form-data"  method="post" name="postform">
    <?php
include_once("dbconnect.php");
$id_mitra = $_SESSION['mitra'];
$query=mysql_fetch_array(mysql_query("select * from mitra where id_mitra='$id_mitra'"));
$id_mitra=$query['id_mitra'];
$nama_mitra = $query['nama_mitra'];
$mitra_email = $query['mitra_email'];
$kendaraan = $query['kendaraan'];
$nomorhp = $query['nomorhp'];
$no_ktp = $query['no_ktp'];
$pengalaman = $query['pengalaman'];
$catatan = $query['catatan'];
$alamat = $query['alamat'];
$catatan = $query['catatan'];
$kelamin = $query['kelamin'];
$tempatlahir = $query['tempatlahir'];
$tgllahir = $query['tgllahir'];
$namadokumen = $query['namadokumen'];
$sebagai = $query['sebagai'];
$alamatkantor = $query['alamatkantor'];
	?>
<input type="hidden" name="id_mitra" value="<?php echo $id_mitra;?>"/>
<br><br>
<table style="font-size:11px;color:#000;">
<tr>
<td>Nama </td>
<td><input type="text" name="nama_mitra"required="required" value="<?php echo $nama_mitra;?>"></td>
</tr>
<tr>
<td>Nomor KTP/ID <br><small>(tidak dapat diganti)</small></td>
<td><input type="text" name="no_ktp"required="required" value="<?php echo $no_ktp;?>" disabled=disabled></td>
</tr>
<tr>
<td>Tempat Lahir </td>
<td><input type="text" name="tempatlahir"required="required" value="<?php echo $tempatlahir;?>"></td>
</tr>
<tr>
<td>Tanggal Lahir </td>
<td><input type="text" name="tgllahir"required="required" value="<?php echo $tgllahir;?>"></td>
</tr>
<tr>
<td>Jenis Kelamin <br><small>(tidak dapat diganti)</small></td>
<td><input type="text" name="kelamin"required="required" value="<?php echo $kelamin;?>" disabled=disabled></td>
</tr>
<tr>
<td>Spesialisasi sebagai <br><small>(tidak dapat diganti)</small></td>
<td><input type="text" name="sebagai"required="required" value="<?php echo $sebagai;?>" disabled=disabled></td>
</tr>
<tr>
<td>Lama Pengalaman </td>
<td><input type="text" name="alamatkantor"required="required" value="<?php echo $alamatkantor;?>"></td>
</tr>
<tr>
<td>Ijazah terakhir </td>
<td><input type="text" name="namadokumen"required="required" value="<?php echo $namadokumen;?>"></td>
</tr>
<tr>
<td>Login Email </td>
<td><input type="email" name="mitra_email"required="required" value="<?php echo $mitra_email;?>"></td>
</tr>
<tr>
<td>Login Password </td>
<td><input type="password" name="mitra_pass" placeholder="isikan password!!"required="required" value=""></td>
</tr>
<tr>
<td>Nomor Handphone </td>
<td><input type="number" name="nomorhp"required="required" value="<?php echo $nomorhp;?>"></td>
</tr><tr><td>Alamat Rumah </td><td><input type="text" name="alamat"required="required" value="<?php echo $alamat;?>"></td></tr>
<tr><td>Nama Bank - Nomor Rekening</td><td><input type="text" name="catatan"required="required" value="<?php echo $catatan;?>"><br><br></td></tr>
	<tr>
      <td></td>
      <td><br><button style="width:200px;font-size:12px;height:auto;margin-top:-20px;padding-bottom:20px;"class="ladda-button"data-color="blue" type="submit" name="kirim">Simpan</button>
	  <br> 	</td>
     
    </tr>
    </table>
    
    </form>
<br><center><a href="#jogin"><img src="../back.png" width="20px"/><b> Kembali</b></a></center><br><br>
</div>
</div>

<div id="registerulang"class="panel">
<div class="content"><br>
<div style="border-bottom:1px solid #8c8c8c;color:red;font-size:14px">
<br>Anda Wajib melakukan Registrasi ulang<br>Memperbarui seluruh data sesuai kondisi saat ini<br>Anda akan diberikan 10 point Loyality
</div><style>
#hideme {
    -webkit-animation: cssAnimation 15s forwards; 
    animation: cssAnimation 15s forwards;
}
@keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
@-webkit-keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
</style>
<?php if($rows['catatan']=='')
      { ?>
<div id="hideme"style="width:100%;position:relative;color:#ef2525;z-index:99999;top:0px;padding:20px;box-shadow:5px 2px 8px 1px rgba(0,0,0,0.15);background-color:rgba(255, 255, 82, 0.95)">
<center>
<br></center>
</div><?php }else{ ?>
<?php } ?>
<form style="font-size:11px" id="form"action="save.php" enctype="multipart/form-data"  method="post" name="postform">
    <?php
include_once("dbconnect.php");
$id_mitra = $_SESSION['mitra'];
$query=mysql_fetch_array(mysql_query("select * from mitra where id_mitra='$id_mitra'"));
$id_mitra=$query['id_mitra'];
$nama_mitra = $query['nama_mitra'];
$mitra_email = $query['mitra_email'];
$kendaraan = $query['kendaraan'];
$nomorhp = $query['nomorhp'];
$no_ktp = $query['no_ktp'];
$pengalaman = $query['pengalaman'];
$catatan = $query['catatan'];
$alamat = $query['alamat'];
$catatan = $query['catatan'];
$kelamin = $query['kelamin'];
$tempatlahir = $query['tempatlahir'];
$tgllahir = $query['tgllahir'];
$namadokumen = $query['namadokumen'];
$sebagai = $query['sebagai'];
$saldo = $query['saldo'];
$alamatkantor = $query['alamatkantor'];
$samdo=$saldo+0;
	?>
<input type="hidden" name="saldo" value="<?php echo $samdo;?>"/>
<input type="hidden" name="id_mitra" value="<?php echo $id_mitra;?>"/>
<input type="hidden" name="tgldaftar" value="<?php echo date("Y-m-d");?>"/>
<br><br>
<table style="font-size:11px;color:#000;">
<tr>
<td>Nama </td>
<td><input type="text" name="nama_mitra"required="required" value="<?php echo $nama_mitra;?>"></td>
</tr>
<tr>
<td>Nomor KTP/ID <br><small>(tidak dapat diganti)</small></td>
<td><input type="text" name="no_ktp"required="required" value="<?php echo $no_ktp;?>" disabled=disabled></td>
</tr>
<tr>
<td>Tempat Lahir </td>
<td><input type="text" name="tempatlahir"required="required" value="<?php echo $tempatlahir;?>"></td>
</tr>
<tr>
<td>Tanggal Lahir </td>
<td><input type="text" name="tgllahir"required="required" value="<?php echo $tgllahir;?>"></td>
</tr>
<tr>
<td>Jenis Kelamin <br><small>(tidak dapat diganti)</small></td>
<td><input type="text" name="kelamin"required="required" value="<?php echo $kelamin;?>" disabled=disabled></td>
</tr>
<tr>
<td>Spesialisasi sebagai <br><small>(tidak dapat diganti)</small></td>
<td><input type="text" name="sebagai"required="required" value="<?php echo $sebagai;?>" disabled=disabled></td>
</tr>
<tr>
<td>Lama Pengalaman </td>
<td><input type="text" name="alamatkantor"required="required" value="<?php echo $alamatkantor;?>"></td>
</tr>
<tr>
<td>Ijazah terakhir </td>
<td><input type="text" name="namadokumen"required="required" value="<?php echo $namadokumen;?>"></td>
</tr>
<tr>
<td>Login Email </td>
<td><input type="email" name="mitra_email"required="required" value="<?php echo $mitra_email;?>"></td>
</tr>
<tr>
<td>Login Password </td>
<td><input type="password" name="mitra_pass" placeholder="isikan password!!"required="required" value=""></td>
</tr>
<tr>
<td>Nomor Handphone </td>
<td><input type="number" name="nomorhp"required="required" value="<?php echo $nomorhp;?>"></td>
</tr><tr><td>Alamat Rumah </td><td><input type="text" name="alamat"required="required" value="<?php echo $alamat;?>"></td></tr>
<tr><td>Nama Bank - Nomor Rekening</td><td><input type="text" name="catatan"required="required" value="<?php echo $catatan;?>"><br><br></td></tr>
	<tr>
      <td></td>
      <td><br><button style="width:200px;font-size:12px;height:auto;margin-top:-20px;padding-bottom:20px;"class="ladda-button"data-color="blue" type="submit" name="jimin">Simpan</button>
	  <br> 	</td>
     
    </tr>
    </table>
    
    </form>
<br><center><a href="#jogin"><img src="../back.png" width="20px"/><b> Kembali</b></a></center><br><br>
</div>
</div>
 <div id="loading" style="display:none"></div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>
<script>function onReady(callback){var intervalID=window.setInterval(checkReady,1000);function checkReady(){if(document.getElementsByTagName('body')[0]!==undefined){window.clearInterval(intervalID);callback.call(this);}}}
function show(id,value){document.getElementById(id).style.display=value?'block':'none';}
onReady(function(){show('dashboard',true);show('loading',false);});
</script>
 </main>
        <script src="../js/jquery.slideandswipe.js"></script>

        <script src="../js/jquery.slideandswipe.min.js"></script>

        <div id="ssm-overlay ssm-toggle-nav"></div>

        <script>
            $(document).ready(function() {
                $('.nav').slideAndSwipe();
            });
        </script>
</body>