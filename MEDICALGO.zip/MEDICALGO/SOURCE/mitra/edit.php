<?php
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: fdex.php#login");
}
$res=mysql_query("SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
?>
<?php 
$result = mysql_query("SELECT * FROM transaksi WHERE id_trans='" . $_GET["id_trans"] . "'");
$row= mysql_fetch_array($result);
$fow = mysql_query("SELECT * FROM users WHERE id='" . $row["id_users"] . "'");
$nok= mysql_fetch_array($fow);
if(count($_POST)>0) {
date_default_timezone_set('Asia/Jakarta');
$static_date=date("d-m-Y");
$bay = date('D', strtotime($static_date));
$bayList = array(
	'Sun' => 'Minggu',
	'Mon' => 'Senin',
	'Tue' => 'Selasa',
	'Wed' => 'Rabu',
	'Thu' => 'Kamis',
	'Fri' => 'Jumat',
	'Sat' => 'Sabtu'
);
if ($bayList[$bay]=='Sabtu'){
$reward=0;
}if ($bayList[$bay]=='Minggu'){
$reward=0;
}
$getliburan=date("Y-m-d");
$mekot = mysql_query("SELECT * FROM liburnasional WHERE tanggal_liburan='$getliburan'");
$tomi= mysql_fetch_array($mekot);		
$nasional=$tomi['tanggal_liburan'];	
if ($getliburan==$nasional){
$reward=0;
}
$pekul = mysql_query("SELECT * FROM mitra WHERE id_mitra='" . $_POST["id_mitra"] . "'");
$cum= mysql_fetch_array($pekul);	
$awalsaldo=$cum['saldo'];	
$sudahsaldo=$awalsaldo+$reward;
$gado=$sudahsaldo;
$awal=$_POST['awal'];
$harga=$_POST['harga'];
$transport=$_POST['transport'];
$deskripsi=$_POST['deskripsi'];
$jumlahan=$awal+$transport;
mysql_query("UPDATE transaksi set status_trans='dijemput', id_mitra='" . $_POST["id_mitra"] . "', online='" . $_POST["online"] . "', harga='" . $jumlahan . "', awal='" . $_POST["awal"] . "', transport='" . $_POST["transport"] . "', deskripsi='" . $_POST["deskripsi"] . "' WHERE id_trans='" . $_POST["id_trans"] . "'");

mysql_query("UPDATE mitra set latmitra='" . $_POST["lat"] . "', lngmitra='" . $_POST["lng"] . "', saldo='$gado' WHERE id_mitra='" . $_POST["id_mitra"] . "'");
$message = "Record Modified Successfully";
}
?>
<head>
<meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../demo.css"/><link rel="stylesheet"href="../css/bemo.css"><link rel="stylesheet"href="../dist/ladda.min.css">
</head><body onkeydown="javascript:if(window.event.keyCode == 13) window.event.keyCode = 9;"><!--sodrops top bar-->
<div class="sodrops-top" style="z-index:9999"><span class="actions"><ul><li>
<a href="javascript:history.go(0)"><img src="refresh.png"width="25px"/></a></li></ul></span>
<div style="margin-left:20px;margin-top:13px;font-size:18px;font-weight:bold">Konfirmasi</div></div>
<div style="width:100%;position:absolute;color:#565656;font-size:14px;">
<script>if(!navigator.geolocation){alert("Your phone does not support maps Location.")}navigator.geolocation.getCurrentPosition(success,error);function success(f){var g=f.coords.latitude;var e=f.coords.longitude;var h=f.coords.accuracy;document.getElementById("lat").value=g;document.getElementById("lng").value=e}function error(b){alert("ERROR("+b.code+"): "+b.message)};
</script>
<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.6.1.min.js"></script>		
<script type="text/javascript" src="autosave5/jquery-1.6.1.js"></script>		
	<script type="text/javascript">
	$(document).ready(function(){	
	
		autosave();
	});
	
	function autosave()
	{
		
		var t = setTimeout("autosave()", 5000);
		$('#timestamp').show(50).delay(8000);	
		var id = $("#id").val();
		var lat = $("#lat").val();
		var lng = $("#lng").val();
		
		if (lat.length > 0 || lng.length > 0)
		{
			$.ajax(
			{
				type: "POST",
				url: "autosave.php",
				data: "&id=" + id + "&lat=" + lat + "&lng=" + lng,
				cache: false,
				success: function(message)
				{	
					$('#timestamp').hide(50).delay(3000);
					$("#timestamp").empty().append(message);
				}
			});
		}
	} 
	</script>	
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=true"></script><br><br><br>
<script>if(!navigator.geolocation){alert("Your phone does not support maps Location.")}navigator.geolocation.getCurrentPosition(success,error);function success(c){var b=c.coords.latitude;var d=c.coords.longitude;var a=c.coords.accuracy;document.getElementById("lat").value=b;document.getElementById("lng").value=d}function error(a){}</script>
<form id="article_form" method="post" action="autosave.php">
<input type="hidden" id="id" name="id" value="<?php echo $rows['id_mitra'];?>" />
<input type="hidden" id="lat" type="float" name="lat"/>
<input type="hidden" id="lng" type="float" name="lng"/>
</form><br>
<iframe style="z-index:9999"width="100%" height="400" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/directions?origin=<?php echo $rows['latmitra']?>,<?php echo $rows['lngmitra']?>&amp;destination=<?php echo $row['lat']?>,<?php echo $row['lng']?>&amp;key=AIzaSyAO4lbxY6SKygcJxTuzu-Qi7kAAP9SdAwM" allowfullscreen="no"></iframe>
<table width="100%" style="margin-top: -30px;position: absolute;border:1px solid grey;padding:10px;background: #fbfb41;padding: 10px;">
<tr><th colspan="2"><small style="color: green"><center>Estimasi biaya transportasi</center></small></th></tr><tr>
<td style="border:1px solid grey;padding:10px;font-size:11px;color:#444;font-weight:bold" width="50%"><center>
<small>Jarak Tempuh : </small><br>
<small>Berdasarkan jalan pintas jarak</small><br>
<?php
$menarif=mysql_query("SELECT * FROM tarif where id_tarif='1'");
$vision=mysql_fetch_array($menarif);
$latfrom= $rows['latmitra'];
$lngfrom= $rows['lngmitra'];
$lat= $row['lat'];
$lng= $row['lng'];
$urlApi = "https://dev.virtualearth.net/REST/v1/Routes/DistanceMatrix?origins=".$latfrom.",".$lngfrom."&destinations=".$lat.",".$lng."&travelMode=driving&key=Ap2D3Kzfhmdy7jATbLxY14xRhnKW25efAyj2dUjxyxD6IqZS9gHAoI8SZRLX1C63";
$result = file_get_contents($urlApi);
$data   = json_decode($result, true);
$eks = $data['resourceSets'][0]['resources'][0]['results'][0]['travelDistance'];
$yipe=$_POST['tipe'];

$tarif= $vision['transportasi'];

$fon=round($eks, 0)*$tarif;
$pembulatan=round($eks, 0);
$zonk=$pembulatan*$tarif;

echo $pembulatan;
?> Km
</center></td><td width="50%" style="border:1px solid grey;padding:10px;font-size:11px;color:#444;font-weight:bold"width="80%">
<center>
</center>
<center>Tarif transport:<br></small>
Rp. <?php   
if($zonk < $tarif)
      {
$arip = number_format($tarif,0,",","."); echo $arip;
      } 
if($zonk > $tarif)
      {
$surip = number_format($zonk,0,",","."); echo $surip;
      }    
if($zonk>='10000000')
      {
      echo"Maaf, Terlalu jauh !!. kami tidak dapat melayani anda";
      } 
                        
    ;
 ?>,-</center>
</td></tr></table>
<form style="padding:15px;"width="100%"method="post"action="<?php echo $_SERVER['PHP_SELF']?>"><br><br>
<input type="hidden" name="deskripsi"value="<?php echo $pembulatan; ?>"/>
<input type="hidden" name="transport"value="<?php   
if($zonk < $tarif)
      {
echo $tarif;
      } 
if($zonk > $tarif)
      {
echo $zonk;
      }    
if($zonk>='10000000')
      {
      echo"";
      } 
                        
    ;
 ?>"/>
<input name="lat"type="hidden"id="lat"/>
<input name="lng"type="hidden"id="lng"/>
<input type="hidden"name="status_trans"value="dijemput"/>
<input type="hidden"name="id_trans"value="<?php echo $row['id_trans']; ?>"/>
<input type="hidden"name="id_mitra"value="<?php echo $_SESSION['mitra']; ?>"/>
<input type="hidden"name="harga"value="<?php echo $row['harga']; ?>"/>
<input type="hidden"name="awal"value="<?php echo $row['harga']; ?>"/><br>
<input type="hidden"name="online"value="read"/><br><br><br><center><small><b>Rincian Layanan</b></small><br>
<div style="font-size:12px">
<b><small>Request <?php echo $row["layanan"]; ?></small></b><br>
<table style="width:100%">
<tr style="font-size:12px;color:#565656"><td>Kode Invoice</td><td>:</td><td width="50%"> <?php echo $row['invoice']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Tanggal Request</td><td>:</td><td width="50%"> <?php echo $row['tanggal']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Waktu Kunjungan</td><td>:</td><td width="50%"> <?php echo $row['timepicker1']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Atas Nama</td><td>:</td><td width="50%"> <?php echo $row["nama_rumah"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Alamat</td><td>:</td><td width="50%"> <?php echo $row["alamat"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Deskripsi Keluhan</td><td>:</td><td width="50%"> <?php echo $row["keterangan"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Harga Layanan</td><td>:</td><td width="50%"> <?php echo $row["harga"]; ?></td></tr>

</table>

</div></center>
<div class="mop"style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">
<b>Total invoice: Rp. <?php 
$layanan = $row['harga'];
if($zonk < $tarif)
      {
$transport=$tarif;
      } 
if($zonk > $tarif)
      {
$transport=$zonk;
      }    
if($zonk>='10000000')
      {
$transport=0;
      } 
$bayangan =$layanan+$transport;
$harga = number_format($bayangan,0,",",".");
echo $harga;?>
</b></div>
<?php
date_default_timezone_set('Asia/Jakarta');
//***$static_date=date("d-m-Y");
$static_date=date("d-m-Y");
$bay = date('D', strtotime($static_date));
$bayList = array(
	'Sun' => 'Minggu',
	'Mon' => 'Senin',
	'Tue' => 'Selasa',
	'Wed' => 'Rabu',
	'Thu' => 'Kamis',
	'Fri' => 'Jumat',
	'Sat' => 'Sabtu'
);
if ($bayList[$bay]=='Sabtu'){
?>
Terimakasih Anda bekerja maksimal tetap melayani pada hari sabtu
<?php }if ($bayList[$bay]=='Minggu'){
?>
Terimakasih karena Anda melayani pada hari Minggu atau Hari libur nasional
<?php } 
$getliburan=date("Y-m-d");
$mekot = mysql_query("SELECT * FROM liburnasional WHERE tanggal_liburan='$getliburan'");
$tomi= mysql_fetch_array($mekot);		
$nasional=$tomi['tanggal_liburan'];	
if ($getliburan==$nasional){?>
Terimakasih karena melayani pada Hari libur nasional tanggal <?php echo $tomi['tanggal_liburan'];?>
<?php }?>
<br><br>apabila setuju mengambil pekerjaan ini,<br>Mohon Konfirmasi Layanan yang akan diambil Sesuai Permintaan dari Pasien, sementara total invoice akan dibayarkan oleh Pasien sesuai penambahan biaya transportasi.
</center>
<p><section class="button-demo"><button onclick="javascript:showDiv();" type="submit"name="submit"class="ladda-button"data-color="green"data-style="expand-right"style="z-index:0">Ambil Job ini</button></section><script src="../dist/spin.min.js"></script><script src="../dist/ladda.min.js"></script><script>Ladda.bind('.button-demo button');Ladda.bind('.progress-demo button',{callback:function(instance){var progress=0;var interval=setInterval(function(){progress=Math.min(progress+Math.random()*0.1,1);instance.setProgress(progress);if(progress===1){instance.stop();clearInterval(interval);}},200);}});</script></p>
</form><center><a onclick="javascript:showDiv();" href="home.php#dashboard"style="color:orange">Kembali Lihat Permintaan</a></center>
<br><br><br>
</div>
<?php 
$id_mitra = $_SESSION['mitra'];
$view=mysql_query("SELECT * FROM transaksi where id_mitra='$id_mitra'");
while($row=mysql_fetch_array($view)){
	?><?php 
 if($row['status_trans']=='dijemput')
      { ?><script>document.location.href="jemput.php";</script><?php }	} ;
 ?></body>
  <style>#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
 <div id="loading" style="display:none"></div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>