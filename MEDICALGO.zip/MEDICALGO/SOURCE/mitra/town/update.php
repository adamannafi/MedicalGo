   <body> 
    <?php
	include_once("config.php");
$id_layanan= $_GET['id_layanan'];
	$query=mysql_fetch_array(mysql_query("select * from layanan where id_layanan='$id_layanan'"));
$nama_layanan= $query['nama_layanan'];
$keterangan_layanan= $query['keterangan_layanan'];
$harga_layanan= $query['harga_layanan'];
$per= $query['per'];
$khusus= $query['khusus'];
$picture= $query['picture'];
	?><br><br><br><br>
<form action="simpanupdate.php" enctype="multipart/form-data"  method="post" name="postform">

<table style="width:100%;padding:10px">
  <tr style="padding:10px">
    <th colspan="4" style="padding:10px"></th>
  </tr>
 <tr>
    <td style="padding:10px;background:#dadada">Nama Layanan</td>
    <td><input style="padding:10px;width:100%"type="text" placeholder="Tulis nama Menu/Layanan" value="<?php echo $nama_layanan;?>" name="nama_layanan"required="required"></td>
    <td style="padding:10px;background:#dadada">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   <tr>
    <td style="padding:10px;background:#dadada">Harga Layanan</td>
    <td><input style="padding:10px;width:100%"placeholder="Tulis nominal (Rp...?)"type="number" value="<?php echo $harga_layanan;?>" name="harga_layanan"required="required"></td>
  <td style="padding:10px;background:#dadada">Harga Layanan Khusus<br><small>(Harga layanan murah untuk kota tertentu dengan value yang lebih rendah)</small></td>
    <td><input style="padding:10px;width:100%"placeholder="Tulis nominal (Rp...?)"type="number" value="<?php echo $khusus;?>" name="khusus"required="required"></td>
  </tr>
 
      <tr>
	  <td style="padding:10px;background:#dadada">Deskripsi Layanan</td>
    <td><textarea style="padding:10px;width:100%"type="text" name="keterangan_layanan"required="required"><?php echo $keterangan_layanan;?></textarea></td>
    <td style="padding:10px;background:#dadada">Icon Layanan</td>
    <td>
<input type="hidden" name="id_layanan" value="<?php echo $id_layanan;?>"/>
	<input style="border:1px solid grey;padding:10px;width:100%" ID="FileUpload1" value="<?php echo $picture;?>" onchange="IsFileSelected()" type="file" name="picture" size="999999" required="required"></td>

  </tr>
   

			<tr> 
			<td style="padding:10px;background:#dadada">Durasi Layanan</td>
    <td><input style="padding:10px;width:100%"placeholder="Berapa jam layanan berlangsung"type="number" value="<?php echo $per;?>" name="per"required="required"></td>
 
			<td>
<center><a href="index.php"><div style="background:red;width:200px;border:none;padding:10px;width:90%;color:#fff" class="testbutton">Batal</div></a>
</center>
				</td>
				<td><center><button style="background:green;width:200px;border:none;padding:10px;width:90%;color:#fff" class="testbutton" type="submit" name="kirim" value="Simpan Data">Simpan Data</button></center></td>
			</tr>
		</table>
  
		<br>
	</form>
    <p><br /></p></body>