<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT * FROM layanan");
?>
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>
<body style="font-family:Monospace;"><br><br>
<table width="100%;background:#fff"><tr>
<td style="border-right:none;background:none;color:#444;">
<h3>Data Menu Semua layanan Medical GO</h3><a href="add.html"><div class="testbutton">Add New Data</div></a><br>Untuk menambah data layanan klik add new data, <br>apabila ingin menambahkan kota khusus atau kota dengan perbedaan harga klik pengaturan kota khusus<br>
<br/></td>
<td style="border-right:none;background:none">
<center><a href="../kota/index.php"><div style="background:green;width:200px" class="testbutton"><small>Pengaturan Kota Khusus</small></div></a>
</center></td>
</tr></table>
	<table width='100%' border=0>

	<tr>
		<th>Icon Layanan</th>
		<th>Nama Layanan</th>
		<th>Deskripsi Layanan</th>
		<th>Harga Layanan</th>
		<th>Harga Layanan khusus</th>
		<th>Durasi layanan</th>
<th>-</th>
<th>x</th>
	
	</tr>
	<?php 
	while($res = mysql_fetch_array($result)) { 		
		echo "<tr>";
		echo "<td width=10%><img width=100px src=../../fotobarang/$res[picture]> </img></td>";
		echo "<td>".$res['nama_layanan']."</td>";
		echo "<td>".$res['keterangan_layanan']."</td>";
		echo "<td>Rp. ".$res['harga_layanan']."</td>";
		echo "<td>Rp. ".$res['khusus']."</td>";
		echo "<td>".$res['per']." Jam</td>";
		echo "<td> <a href=\"update.php?id_layanan=$res[id_layanan]\">Edit</a></td>";
echo "<td> <a href=\"delete.php?id_layanan=$res[id_layanan]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";				
	}
	?>
	</table>
</body>
</html>