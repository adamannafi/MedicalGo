<html>

<body>
<?php
//including the database connection file
include_once("config.php");

if(isset($_POST['submit'])) {	
	$nama_layanan = $_POST['nama_layanan'];
	$harga_layanan = $_POST['harga_layanan'];
	$keterangan_layanan = $_POST['keterangan_layanan'];
	$per = $_POST['per'];
	$khusus = $_POST['khusus'];
	
	if(empty($_FILES['picture']['name'])){
		$picture=$_POST['picture'];
	}else{
		$picture=$_FILES['picture']['name'];
		//definisikan variabel file dan alamat file
		$uploaddir='../../fotobarang/';
		$alamatfile=$uploaddir.$picture;
		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file($_FILES['picture']['tmp_name'],$alamatfile);
	}
		
$result = mysql_query("INSERT INTO layanan(nama_layanan,harga_layanan,keterangan_layanan,per,khusus,picture) VALUES('$nama_layanan','$harga_layanan','$keterangan_layanan','$per','$khusus','$picture')");

header("Location:index.php");		//display success message
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='index.php'>View Result</a>";
	}
	
?>
</body>
</html>
