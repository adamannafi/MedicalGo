<?php
//including the database connection file
include("config.php");

//getting id of the data from url
$id_layanan = $_GET['id_layanan'];

//deleting the row from table
$result = mysql_query("DELETE FROM layanan WHERE id_layanan='$id_layanan'");

//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>

