<?php
include_once("config.php");
if(isset($_POST['kirim'])){
$nama_layanan = $_POST['nama_layanan'];
	$harga_layanan = $_POST['harga_layanan'];
	$keterangan_layanan = $_POST['keterangan_layanan'];
	$per = $_POST['per'];
	$khusus = $_POST['khusus'];
	$id_layanan = $_POST['id_layanan'];
	
	if(empty($_FILES['picture']['name'])){
		$picture=$_POST['picture'];
	}else{
		$picture=$_FILES['picture']['name'];
		//definisikan variabel file dan alamat file
		$uploaddir='../../fotobarang/';
		$alamatfile=$uploaddir.$picture;
		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file($_FILES['picture']['tmp_name'],$alamatfile);
	}
	$query=mysql_query("update layanan set nama_layanan='$nama_layanan', harga_layanan='$harga_layanan', keterangan_layanan='$keterangan_layanan', per='$per', khusus='$khusus', picture='$picture' where id_layanan='$id_layanan'");
						
	if($query){
		?>
		<blockquote><br><br><br>
          <p></p>
		  <p>Success Saved...<br><a href='index.php'>Show</a></p>
		  <p></p>
		</blockquote>
		<?php
	}else{
		echo mysql_query();
	}
	

}else{
	unset($_POST['kirim']);
}
?>