 <head><meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0"><link rel="stylesheet"type="text/css"href="../demo.css"/><link href="../style.css"rel="stylesheet"><meta name="HandheldFriendly"content="True"><meta name="MobileOptimized"content="320"><meta name="viewport"content="width=device-width, initial-scale=1.0"><style type="text/css">body{font:100%/1.4'Helvetica Neue',arial,helvetica,helve,sans-serif}h1{font-size:2.2em;padding:0 .5em 0}h2{font-size:1.5em}.header{padding:1em 0}.col{padding:1em 0;text-align:center}</style>
</head><body><div class="sodrops-top"><span class="actions"><ul><li><a href="home.php#dashboard"><img src="../home.png"width="25px"/></a></li></ul></span><div style="margin-left:20px;margin-top:7px;font-size:18px;font-weight:bold"><img src="../android1.png"width="130px"/></div></div><center>
<form action="simpanupdate.php" enctype="multipart/form-data"  method="post" name="postform">
   <body style="padding:18px"> 
    <?php
	include_once("dbconnect.php");
$id_mitra = $_GET['id_mitra'];
	$query=mysql_fetch_array(mysql_query("select * from mitra where id_mitra='$id_mitra'"));
	$id_mitra=$query['id_mitra'];
	$nama_mitra = $query['nama_mitra'];
	$no_ktp = $query['no_ktp'];
	$foto_mitra = $query['foto_mitra'];
	$kelamin = $query['kelamin'];
	$sim = $query['sim'];
	$pengalaman = $query['pengalaman'];
	$kendaraan = $query['kendaraan'];
	$nomorhp = $query['nomorhp'];
	$dokumen = $query['dokumen'];
	
	$mitra_email = $query['mitra_email'];
	$mitra_pass = md5($query['mitra_pass']);
	
	?>
   <input type="hidden" name="id_mitra" value="<?php echo $id_mitra;?>"/>
    <input type="hidden" name="foto_mitra" value="<?php echo $foto_mitra?>" />
    <br><br>
    <table style="color:black;">
   <tr>
<input type="hidden" name="nama_mitra" value="<?php echo $nama_mitra;?>">
<input type="hidden" name="foto_mitra" value="<?php echo $foto_mitra;?>">
<input type="hidden" name="kelamin" value="<?php echo $kelamin;?>">
<input type="hidden" name="dokumen" value="<?php echo $dokumen;?>">
<input type="hidden" name="mitra_pass" value="<?php echo $mitra_pass;?>">
<td>Nama Medis</td>
<td><?php echo $nama_mitra;?></td>
</tr>
<tr>
<td>Foto Medis</td>
<td>-</td>
</tr>
<tr>
<td>Nomor KTP</td>
<td><input type="text" name="no_ktp"required="required" value="<?php echo $no_ktp;?>"></td>
</tr>
<tr>
<td>Pria / Wanita</td>
<td>-</td>
</tr>
<tr>
<td>Alamat</td>
<td><input type="text" name="kendaraan"required="required" value="<?php echo $kendaraan;?>"></td>
</tr>
<tr>
<td>Ijazah</td>
<td><input type="text" name="sim"required="required" value="<?php echo $sim;?>"></td>
</tr>
<tr>
<td>Pengalaman (tahun)</td>
<td><input type="text" name="pengalaman"required="required" value="<?php echo $pengalaman;?>"></td>
</tr>
<tr>
<td>Nomor handphone</td>
<td><input type="int" name="nomorhp"required="required" value="<?php echo $nomorhp;?>"></td>
</tr>
<tr>
<td>Dokumen</td>
<td><?php echo $dokumen;?></td>

      <td ><p></p></td>
    </tr>
<tr>
<td>Email</td>
<td><input type="email" name="mitra_email"required="required" value="<?php echo $mitra_email;?>"></td>
</tr>
<tr>
<td>Password</td>
<td><input type="password" name="mitra_pass"required="required" value="<?php echo $mitra_pass;?>" onFocus="value=''"></td>
</tr>
    <tr>
      <td></td>
      <td><br><input type="submit" value="Simpan"  onclick="return confirm('Apakah Anda yakin akan mengubah account?')"name="kirim" /><br> <br><a href="home.php#dashboard"style="color:orange">Batal Ubah data</a></td>
     
    </tr>
    </table>
    
    </form>
    <p><br /></p>
    </center></body>