<?php
include_once("dbconnect.php");
if(isset($_POST['kirim'])){
	if (empty($_POST['mitra_pass'])) {
   ?>
<script>window.alert("Isikan Password anda!");window.history.back(-2);</script><?php
  return false;
}
$id_mitra=$_POST['id_mitra'];
$nama_mitra = $_POST['nama_mitra'];
$mitra_email = $_POST['mitra_email'];
$kendaraan = $_POST['kendaraan'];
$nomorhp = $_POST['nomorhp'];
$no_ktp = $_POST['no_ktp'];
$pengalaman = $_POST['pengalaman'];
$catatan = $_POST['catatan'];
$alamat = $_POST['alamat'];
$catatan = $_POST['catatan'];
$kelamin = $_POST['kelamin'];
$tempatlahir = $_POST['tempatlahir'];
$tgllahir = $_POST['tgllahir'];
$namadokumen = $_POST['namadokumen'];
$sebagai = $_POST['sebagai'];
$alamatkantor = $_POST['alamatkantor'];
$mitra_pass=$_POST['mitra_pass'];
$jet = md5($mitra_pass);
$query=mysql_query("update mitra set nama_mitra='$nama_mitra', alamatkantor='$alamatkantor', namadokumen='$namadokumen', catatan='$catatan', tempatlahir='$tempatlahir', tgllahir='$tgllahir', nama_mitra='$nama_mitra', mitra_email='$mitra_email', mitra_pass='$jet', nomorhp='$nomorhp' where id_mitra='$id_mitra'");			
if($query){
		?>
<script>window.history.back(-2);</script>
		<?php
	

}};
?>

<?php
include_once("dbconnect.php");
if(isset($_POST['jimin'])){
	if (empty($_POST['mitra_pass'])) {
   ?>
<script>window.alert("Isikan Password anda!");window.history.back(-2);</script><?php
  return false;
}
$id_mitra=$_POST['id_mitra'];
$mitra_pass=$_POST['mitra_pass'];
$nama_mitra = $_POST['nama_mitra'];
$mitra_email = $_POST['mitra_email'];
$kendaraan = $_POST['kendaraan'];
$nomorhp = $_POST['nomorhp'];
$no_ktp = $_POST['no_ktp'];
$pengalaman = $_POST['pengalaman'];
$catatan = $_POST['catatan'];
$alamat = $_POST['alamat'];
$catatan = $_POST['catatan'];
$kelamin = $_POST['kelamin'];
$tempatlahir = $_POST['tempatlahir'];
$tgllahir = $_POST['tgllahir'];
$tgldaftar = $_POST['tgldaftar'];
$namadokumen = $_POST['namadokumen'];
$sebagai = $_POST['sebagai'];
$saldo = $_POST['saldo'];
$alamatkantor = $_POST['alamatkantor'];
$jet = md5($mitra_pass);
$query=mysql_query("update mitra set nama_mitra='$nama_mitra', alamatkantor='$alamatkantor', namadokumen='$namadokumen', catatan='$catatan', tempatlahir='$tempatlahir', tgllahir='$tgllahir', nama_mitra='$nama_mitra', mitra_email='$mitra_email', mitra_pass='$jet', nomorhp='$nomorhp', tgldaftar='$tgldaftar', saldo='$saldo' where id_mitra='$id_mitra'");			
if($query){
		?>
<script>window.history.back(-2);</script>
		<?php
	

}};
?>