<?php
session_start();
include_once '../dbconnect.php';
$idsaldo = $_GET["idsaldo"];
$result = mysql_query("SELECT id, saldo, idsaldo, first_name, tipesaldo, jumlahsaldo, statussaldo, tgl_request, banksaldo, namauser, nomorrek, phone FROM trans_user INNER JOIN users on trans_user.id_users=users.id");
$row= mysql_fetch_array($result);
if(isset($_POST['topup'])){
$saldo=$row['saldo'];
$total=$_POST['jumlahsaldo'];
$pensaldoan=$saldo+$total;
mysql_query("UPDATE trans_user set statussaldo='finish' WHERE idsaldo='" . $_POST["idsaldo"] . "' and statussaldo='dijemput'");
mysql_query("UPDATE transaksi set tipebayar='transfer', status_trans='otw', online='read', namegroup='" . $_POST["idsaldo"] . "' WHERE id_users='" . $_POST["id"] . "' and status_trans='dijemput'");
header("Location: index.php"); }

if(isset($_POST['withdraw'])){
$bando=$row['saldo'];
$bopang=$_POST['jumlahsaldo'];
$withdraw=$bando-$bopang;
mysql_query("UPDATE trans_user set statussaldo='finish' WHERE idsaldo='" . $_POST["idsaldo"] . "' and statussaldo='dijemput'");
mysql_query("UPDATE sopir set saldo='$withdraw' WHERE id_sopir='" . $_POST["id"] . "'");
header("Location: index.php"); }
?><head><meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../../demo.css"/></head><body style="background: -moz-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* ff3.6+ */
background: -webkit-gradient(linear, left bottom, right top, color-stop(0%, rgba(168,252,255,1)), color-stop(100%, rgba(59,127,255,1))); /* safari4+,chrome */
background: -webkit-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* safari5.1+,chrome10+ */
background: -o-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* opera 11.10+ */
background: -ms-linear-gradient(29deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* ie10+ */
background: linear-gradient(61deg, rgba(168,252,255,1) 0%, rgba(59,127,255,1) 100%); /* w3c */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#A8FCFF', endColorstr='#3B7FFF',GradientType=1 ); /* ie6-9 */" onkeydown="javascript:if(window.event.keyCode == 13) window.event.keyCode = 9;"><!--sodrops top bar-->
<div style="background: #fff;
    -webkit-box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
    box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
    display: block;
    margin: 0 auto;
    min-height: 0;
    width: 450px;padding:15px;color:#000"><br><br>
<center><small><b>Payment <?php echo $row['first_name']; ?></b></small><br><br>
<?php 
if($row['tipesaldo']=='topup')
      { ?> 
<b>Detail Transfers</b><br>
<table><br>
<tr style="font-size:12px;color:#565656"><td>ID Transaction</td><td>:</td><td width="50%"> <?php echo $row['idsaldo']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Date<td>:</td><td width="50%"> <?php echo $row["tgl_request"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Name user</td><td>:</td><td width="50%"> <?php echo $row['first_name']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Price invoice</td><td>:</td><td width="50%">MYR <?php
$nominal = $row['jumlahsaldo']; 
$jumlah = number_format($nominal,0,",",".");
echo $jumlah; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Name Bank User</td><td>:</td><td width="50%"> <?php echo $row['namauser']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Name Bank</td><td>:</td><td width="50%"> <?php echo $row["banksaldo"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Account Number</td><td>:</td><td width="50%"> <?php echo $row["nomorrek"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>
<br><br>Already payment to MedicalGO bank account:<br>
Name bank: <?php 
$her=mysql_query("SELECT * FROM infobank where idinfo='1'");
$mul=mysql_fetch_array($her);
echo $mul['namabank'];?><br>
Account Number: <?php echo $mul['norek'];?><br>
Name: <?php echo $mul['namaorang'];?><br><br>
if payment from user <?php echo $row['first_name']; ?> already correct please click confirm.

</td></tr>

</table>
<form name="frmUser"method="post"action="<?php echo $_SERVER['PHP_SELF']?>"><br><br>
<center>
<input type="hidden"name="jumlahsaldo" value="<?php echo $row['jumlahsaldo']; ?>">
<input type="hidden"name="id" value="<?php echo $row['id']; ?>">
<input type="hidden"name="idsaldo" value="<?php echo $row['idsaldo']; ?>">
<p><button style="border:1px solid green;padding:4px;color:green;font-size:18px;"type="submit"name="topup"class="btnSubmit"> Confirm</button></p><br>

	  <?php } ?>
	  <?php 
if($row['tipesaldo']=='withdraw')
      { ?>
<b>Withdraw</b><br>
<table><br>
<tr style="font-size:12px;color:#565656"><td>Nota</td><td>:</td><td width="50%"> <?php echo $row['idsaldo']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Tanggal<td>:</td><td width="50%"> <?php echo $row["tgl_request"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Nama user</td><td>:</td><td width="50%"> <?php echo $row['first_name']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Jumlah Withdraw</td><td>:</td><td width="50%">Rp. <?php
$nominal = $row['jumlahsaldo']; 
$jumlah = number_format($nominal,0,",",".");
echo $jumlah; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Nama pemilik rekening</td><td>:</td><td width="50%"> <?php echo $row['namauser']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Nama Bank</td><td>:</td><td width="50%"> <?php echo $row["banksaldo"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Nomor Rekening</td><td>:</td><td width="50%"> <?php echo $row["nomorrek"]; ?><br><br>
apabila pembayaran admin sudah transfer ke rekening <?php echo $row['first_name']; ?>, admin dapat melakukan konfirmasi.

</td></tr>
</table>
<form name="frmUser"method="post"action="<?php echo $_SERVER['PHP_SELF']?>"><br><br>
<center>
<input type="hidden"name="jumlahsaldo" value="<?php echo $row['jumlahsaldo']; ?>">
<input type="hidden"name="id" value="<?php echo $row['id']; ?>">
<input type="hidden"name="idsaldo" value="<?php echo $row['idsaldo']; ?>">
<p><button style="border:1px solid green;padding:4px;color:green;font-size:18px;"type="submit"name="withdraw"class="btnSubmit"> Konfirmasi</button></p><br>

	  <?php } ?></center><br>
</center>
<form name="frmUser"method="post"action="<?php echo $_SERVER['PHP_SELF']?>"><br><br>
<center>
<input type="hidden"name="statussaldo" value="otw">
<input type="hidden"name="idsaldo" value="<?php echo $idsaldo;?>">
<p><button style="border:1px solid green;padding:4px;color:green;font-size:18px;"type="submit"name="submit"class="btnSubmit"> Konfirmasi</button></p><br>
<a href="index.php"style="color:orange">Kembali</a>
</center></form></div>
</body>