<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
$result = mysql_query("SELECT idsaldo, first_name, tipesaldo, jumlahsaldo, statussaldo, tgl_request, banksaldo, namauser, nomorrek, phone FROM trans_user INNER JOIN users on trans_user.id_users=users.id");
?>
<link rel="stylesheet"type="text/css"href="../button.css"/>
<html>

<body style="font-family:Monospace;"><center>
<h3>Payment By User</h3><small>Waiting admin confirm</small>
</center>
<table width="100%;background:#fff"><tr>
<td style="border-right:none;background:none;color:grey"><center>
<h3>Pembayaran Sewa</h3><br>
Menampilkan payment dari user penyewa yang harus di confirm oleh admin lapakrental
</center></td>
<td style="border-right:none;background:none">
<center><a href="print.php" target="blank"><button id="cmd" style="background:green;border:none"><div style="background:green;width:200px" class="testbutton">Print Data</div></button></a>
</center></td>
</tr></table>
<table width='100%' border=0>

	<tr>
		<th>ID Request</th>
		<th>Date</th>
		<th>Name User</th>
		<th>User Phone</th>
<th>Invoice Price</th>
<th>Status</th>
		<th>Name Bank</th>
		<th>Name User</th>
		<th>Account Number</th>
		<th>Navigation</th>
	
	</tr>
	<?php 
	while($res = mysql_fetch_array($result)) {
$nominal = $res['jumlahsaldo']; 
$jumlah = number_format($nominal,0,",",".");
		echo "<tr>";
		echo "<td>".$res['idsaldo']."</td>";
		echo "<td>".$res['tgl_request']."</td>";
		echo "<td>".$res['first_name']."</td>";
		echo "<td>".$res['phone']."</td>";
		echo "<td>Rp ".$jumlah."</td>";	echo "<td width=5%>";
	if($res['statussaldo']=='dijemput')
      {
echo "Confirmed";		
		
  }echo "</td>";
		echo "<td>".$res['banksaldo']."</td>";
		echo "<td>".$res['namauser']."</td>";
		echo "<td>".$res['nomorrek']."</td>";
			echo "<td width=5%>";
	if($res['statussaldo']=='dijemput')
      {
echo "<a href=\"layani.php?idsaldo=$res[idsaldo]\" style=background:green;padding:10px;color:#fff>Confirm</a>";		
		
  }
  if($res['statussaldo']=='finish')
      {
echo "Done";
  }
  if($res['statussaldo']=='minta')   {
echo "Tunggu konfirmasi...";		
		
  }
	  
  echo "</td>";
	
}
	?>
	</table>
</body>
</html>
