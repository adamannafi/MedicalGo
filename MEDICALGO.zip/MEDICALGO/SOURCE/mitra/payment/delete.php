<?php
//including the database connection file
include("config.php");

//getting id of the data from url
$id_saldo = $_GET['idsaldo'];

//deleting the row from table
$result = mysql_query("DELETE FROM trans_user WHERE id_saldo='$id_saldo'");

//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>

