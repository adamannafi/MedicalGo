<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: fdex.php#login");
}
$res=mysql_query("SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
?>
<?php 
$result = mysql_query("SELECT * FROM transaksi WHERE id_mitra='" . $_SESSION['mitra'] . "' and status_trans='otw'");
$row= mysql_fetch_array($result);
if(count($_POST)>0) {
mysql_query("UPDATE transaksi set status_trans='ttd' WHERE id_trans='" . $_POST["id_trans"] . "'");
header("Location: home.php#payment");
}
?>
<head><meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../demo.css"/>
<link rel="stylesheet" href="../css/bemo.css">
<link rel="stylesheet" href="../dist/ladda.min.css"></head>
<body><div class="sodrops-top" style="z-index:9999">
<span class="actions"><ul><li><a href="javascript:history.go(0)">
<img src="refresh.png"width="25px"/></a></li></ul></span><div style="margin-left:20px;margin-top:13px;font-size:18px;font-weight:bold;color:#fff;">Mulai Terapi</div></div><div style="padding:45px;z-index:999;position:absolute;color:#565656;font-size:14px"><br><br>
<p>
<br><center><small><b style="color:green">Memulai Layanan <?php echo $row["layanan"]; ?></b></small></center>
<br style="font-size:12px;color:#565656"><b><small>Kode Invoice :</small></b><br/><?php echo $row["invoice"]; ?>
<br style="font-size:12px;color:#565656"><b><small>Tanggal Request :</small></b><br/><?php echo $row['tanggal']; ?>
<br style="font-size:12px;color:#565656"><b><small>Keterangan Keluhan :</small></b><br/><?php echo $row['keterangan']; ?>
<br style="font-size:12px;color:#565656"><b><small>Harga Layanan :</small></b><br/>Rp. <?php $awal = $row['awal'];$kapi = number_format($awal,0,",",".");echo $kapi; ?>
<br style="font-size:12px;color:#565656"><b><small>Tarif transport :</small></b><br/>Rp. <?php $transport = $row['transport'];$porti = number_format($transport,0,",",".");echo $porti; ?>
<br style="font-size:12px;color:#565656"><b><small>Tipe pembayaran:</small></b><br/>
<?php
$cash=$row['tipebayar'];
if ($cash=='cash') { ?>
<small>Pasien memilih pembayaran cash, Medis bisa meminta pembayaran cash ke Pasien sesuai nominal layanan <br>Mohon tidak meminta uang tambahan kepada Pasien</small>
<?php } 
if ($cash=='point') {?>
<small>Pasien memilih pembayaran Point, 10 Point dari Pasien Akan ditambahkan dalam balance anda setelah layanan selesai <br>Mohon tidak meminta uang tambahan kepada Pasien</small>
<?php } 
if ($cash=='transfer') {?>
<small>Pasien memilih pembayaran Transfer, Pembayaran anda sudah diterima admin untuk diberikan kepada Medis <br>Mohon tidak meminta uang tambahan kepada Pasien</small>
<?php  } ?><br>

<?php
date_default_timezone_set("Asia/Bangkok");
$startTime = date("Y-m-d H:i:s");
$startHour = date("H:i:s");
$pike = date("Y-m-d H:i:s");
$timestamp = strtotime($pike);
$timestamp_one_hour_later = $timestamp + 3600; // 3600 sec. = 1 hour

$cenvertedTime = date('Y-m-d H:i:s',strftime($timestamp_one_hour_later));
?>
</p>
<center> <br><br>Waktu Saat ini<br>
<h1><?php echo $startHour;?></h1></center>
<br><br>
Medis,<br> Tombol selesai akan muncul apabila jam layanan sudah selesai.
apabila telah selesai menyelesaikan Layanan Terapi sesuai permintaan Pasien Silahkan Klik "Selesai".<br>Selanjutnya Pasien akan mengisi formulir feedback dan testimoni bahwa layanan telah selesai</center>
<?php
$timeend=$row['timeend'];
if ($timeend=='0') { ?>
<form id="form"action="jame.php" enctype="multipart/form-data"  method="post" name="postform">
<input type="hidden"name="timestart"id="timestart" value="<?php echo $startTime;?>">
<input type="hidden"name="timeend"id="timeend" value="<?php echo $cenvertedTime;?>">
<input type="hidden" name="id_trans" value="<?php echo $row['id_trans'];?>"/>
<button style="border-radius:10px;border:0;background:green;color:#fff;" type="submit" name="kirim" /><center>Mulai Layanan</center></button><br>
    </form>
<?php } else { ?>
<?php
$now = date("Y-m-d H:i:s");
$timeend=$row['timeend'];
if ($now>=$timeend) { ?>
<form name="frmUser"method="post"action="<?php echo $_SERVER['PHP_SELF']?>">
<input type="hidden"name="id_trans"value="<?php echo $row['id_trans']; ?>"/><br>
<p><section class="button-demo"><button type="submit"name="submit"class="ladda-button" data-color="green" data-style="expand-right">Selesai</button></section><script src="../dist/spin.min.js"></script>
<script src="../dist/ladda.min.js"></script>
<script>Ladda.bind(".button-demo button");Ladda.bind(".progress-demo button",{callback:function(a){var c=0;var b=setInterval(function(){c=Math.min(c+Math.random()*0.1,1);a.setProgress(c);if(c===1){a.stop();clearInterval(b)}},200)}});</script></p>
</form>
<?php } else { ?>
<center>
<small>Waktu Mulai</small><br>
<?php echo $row['timestart']; ?><br>
<br><small>Waktu Selesai</small><br>
<?php echo $row['timeend']; ?>
<br>
</center>
</small>
<?php } ?>

<?php } ?>
<br><a href="jemput.php"style="color:orange">Kembali Lihat layanan</a>
</div>
</div>
</body>