<link rel="stylesheet"href="../themes/base/jquery.ui.all.css">
<script src="../js/jquery.min.js"></script>
<script src="../js/jquery-ui.min.js"></script>
<script src="../jquery.ui.addresspicker.js"></script>
<link rel="stylesheet"type="text/css"href="../demo.css"/>
<style type="text/css">body{padding:25px;font-size:12px;}ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:#000;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:0;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#home{display:none}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<link rel="stylesheet"href="../css/bemo.css">
<link rel="stylesheet"href="../dist/ladda.min.css">
</head><body>

<?php
include_once("dbconnect.php");
$id_barang= $_GET['id_barang'];
$query=mysql_fetch_array(mysql_query("select * from barang where id_barang='$id_barang'"));
$id_barang=$query['id_barang'];
$gambar= $query['gambar'];
?><center>
<?php
 if($query['gambar']=='0')
      { ?>
<img src="../nopic.png" style="width:300px;top:0;"/>
<?php }
 if($query['gambar']=='')
      { ?>
<img src="../nopic.png" style="width:300px;top:0;"/>
<?php }
else{?>
<img src="../fotobarang/<?php echo $query['gambar'];?>" style="width:300px;top:0;"/>
<?php } ?></center>
<div style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">

<p >Nama Chemical : <?php echo $query['nama_barang'];?></p>
<p >Jenis : <?php echo $query['jenis'];?></p>
<p >Ukuran/isi : <?php echo $query['tipe'];?></p>
<p >Deskripsi : <br><?php echo $query['keterangan_barang'];?></p>
<p >Fungsi Chemical : <br><?php echo $query['harga_harian'];?> </p>
<p >Harga: IDR <?php echo $query['harga_bulanan'];?></p></div>
<center>
<p style="color:#000"><label>Upload Gambar/Foto barang yang akan di sewakan</label></p>
<form action="simpangambar.php" enctype="multipart/form-data"  method="post" name="postform">
   <body> <br><br>
   
<input type="hidden" name="id_barang" value="<?php echo $id_barang; ?>"/>

<div style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">
<input type="file" accept="image/*" name="gambar" id="fileInput" size="999999"/>
</div>
<br><br>
<section class="button-demo" style="padding:0px">
<button style="float:right;width:150px;font-size:12px;height:auto"type="submit"name="kirim"class="ladda-button"data-color="green"data-style="expand-right">Upload</button>
</section>

<script src="../dist/spin.min.js"></script>
<script src="../dist/ladda.min.js"></script>
<script>Ladda.bind(".button-demo button");Ladda.bind(".progress-demo button",{callback:function(b){var a=0;var c=setInterval(function(){a=Math.min(a+Math.random()*0.1,1);b.setProgress(a);if(a===1){b.stop();clearInterval(c)}},200)}});</script>
</form>
<a href="javascript:history.go(-1)"><button style="margin-top:-15px;float:left;width:100px;font-size:12px;height:auto"class="ladda-button"data-color="red"data-style="expand-right">Kembali </button></a>

</center>
</body>