<?php
    session_start();
    if(isset($_SESSION['first_name'])){
	    header("Location: page.php");
	}
	
include ('database_connection.php');
if (isset($_POST['formsubmitted'])) {
    $error = array();//buat array untuk menampung pesan eror  
    if (empty($_POST['name'])) {//jika variabel nama kosong 
        $error[] = 'Silahkan masukkan nama ';//tambahkan ke array sebagai pesan error
    } else {
        $name = $_POST['name'];//jika ada maka masukan isi dari variabel nama
		$lat = $_POST['lat'];
		$lng = $_POST['lng'];
		$fotouser = $_POST['fotouser'];
		$jeniskelamin = $_POST['jeniskelamin'];
		$ktp = $_POST['ktp'];
		$referal = $_POST['referal'];
		$userlahir = $_POST['userlahir'];
		$usertgllahir = $_POST['usertgllahir'];
		$useralamat = $_POST['useralamat'];
		$kunci = $_POST['kunci'];
		$phone = $_POST['phone'];
		$promohabis = $_POST['promohabis'];
		
    }

    if (empty($_POST['e-mail'])) {
        $error[] = 'Please Enter your Email ';
    } else {


        if (preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/", $_POST['e-mail'])) {
           //regular expression untuk validasi email
            $Email = $_POST['e-mail'];
        } else {
             $error[] = 'Email tidak valid';
        }


    }


    if (empty($_POST['Password'])) {
        $error[] = 'Silahkan masukkan password ';
    } else {
        $Password = md5($_POST['Password']);
    }


    if (empty($error)) //kirim ke database jika tidak ada eror

    { 

        // memastikan apakah email sudah ada di database atau belum
        $query_verify_email = "SELECT * FROM users  WHERE Email ='$Email'";
        $result_verify_email = mysqli_query($dbc, $query_verify_email);
        if (!$result_verify_email) {//if the Query Failed ,similar to if($result_verify_email==false)
            echo ' Terjadi eror pada database ';
        }

        if (mysqli_num_rows($result_verify_email) == 0) { // Jika tidak ada user lain yang teregistrasi telah menggunakan email ini


            // membuat kode aktivasi
            $activation = md5(uniqid(rand(), true));


            $query_insert_user = "INSERT INTO `users` (`id`, `first_name`, `email`, `password`, `phone`, `lat`, `lng`, `forgot_pass_identity`, `fotouser`, `modified`, `status`, `jeniskelamin`, `ktp`, `referal`, `userlahir`, `usertgllahir`, `useralamat`, `kunci`, `point`, `promohabis`) VALUES (NULL, '$name', '$Email', '$Password', '$phone', '$lat', '$lng', '$activation', '$fotouser', '$modified', '$status', '$jeniskelamin', '$ktp', '$referal', '$userlahir', '$usertgllahir', '$useralamat', '0', '0', '$promohabis');";


            $result_insert_user = mysqli_query($dbc, $query_insert_user);
            if (!$result_insert_user) {
                echo 'Query Failed ';
            }

            if (mysqli_affected_rows($dbc) == 1) { //Jika data yang dimasukan ke database sukses


                // kirim email
				$message = "Terimakasih sudah mendaftar di Aplikasi Medical GO \"Selamat menggunakan layanan kami\" \n\n";
                $message .= "Anda bisa langsung Login, Selanjutnya Mohon untuk melakukan aktivasi. Untuk aktivasi akun anda, silahkan klik link di bawah ini:\n\n";
                $message .= "Setelah akun anda aktif, anda mendapatkan 10 point sebagai promo point untuk pembayaran jasa layanan kami\n\n";
                $message .= WEBSITE_URL . '/activate.php?email=' . urlencode($Email) . "&key=$activation";
                $message .= "Atau copy link tersebut ke browser kemudian klik enter untuk mengaktifkan link tersebut\n\n";
                mail($Email, 'Konfirmasi Registrasi', $message, 'From: admin@hospital.barisandata.com');

                


                // Jika registrasi berhasil dan email telah terkirim
                echo '<div class="success" style="color: #4F8A10;background-color: #f8ffeb;background-image: url(images/success.png);font-size: 11px;">Terimakasih telah melakukan registrasi, sebuah email telah dikirim ke '.$Email.' Coba cek inbox atau spam folder, Silahkan klik pada link aktivasi untuk mengaktifkan account anda. kemudian login di aplikasi </div>';


            } else { // Jika terjadi kesalahan maka : 
                echo '<div class="errormsgbox">Tidak dapat melakukan registrasi karena kesalahan system</div>';
            }

        } else { // email addres telah terdaftar
            echo '<div class="errormsgbox" >email yang anda masukkan telah teregistrasi
</div>';
        }

    } else {//Jika terdapat kesalahan pada array error maka tampilkan
        
        

echo '<div class="errormsgbox"> <ol>';
        foreach ($error as $key => $values) {
            
            echo '	<li>'.$values.'</li>';


       
        }
        echo '</ol></div>';

    }
  
    mysqli_close($dbc);//Tutup koneksi database

}



?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<title>Registration Form</title>
<link href="../mitra/parsley/bower_components/bootstrap/dist/css/bootstrap.css" rel="stylesheet">
<link href="../mitra/parsley/doc/assets/docs.css" rel="stylesheet">
<link href="../mitra/parsley/src/parsley.css" rel="stylesheet">
<style class="example">
.form-section {
  padding-left: 15px;
  border-left: 2px solid #FF851B;
  display: none;
}
.form-section.current {
  display: inherit;
}
.btn-info, .btn-default {
  margin-top: 10px;
}
</style>

<script src="../mitra/parsley/bower_components/jquery/dist/jquery.min.js"></script>

    
    
    
<style type="text/css">
body {
	font-family:"Lucida Grande", "Lucida Sans Unicode", Verdana, Arial, Helvetica, sans-serif;
	font-size:12px;
}
.registration_form {
	margin:0 auto;
}
label {
	width: 10em;
	float: left;
	margin-right: 0.5em;
	display: block
}

fieldset {
	background:#EBF4FB none repeat scroll 0 0;
	border:2px solid #B7DDF2;
}
legend {
	color: #fff;
	background: #80D3E2;
	border: 1px solid #781351;
	padding: 2px 6px
}
.elements {
	padding:10px;
}
p {
	border-bottom:1px solid #B7DDF2;
	color:#666666;
	font-size:11px;
	margin-bottom:20px;
	padding-bottom:10px;
}
a{
    color:#0099FF;
font-weight:bold;
}

/* Box Style */


 .success, .warning, .errormsgbox, .validation {
	border: 1px solid;
	margin: 0 auto;
	padding:10px 5px 10px 50px;
	background-repeat: no-repeat;
	background-position: 10px center;
     font-weight:bold;
    width: 80%;
     
}

.success {
   
	color: #4F8A10;
	background-color: #DFF2BF;
	background-image:url('images/success.png');
}
.warning {

	color: #9F6000;
	background-color: #FEEFB3;
	background-image: url('images/warning.png');
}
.errormsgbox {
 
	color: #D8000C;
	background-color: #FFBABA;
	background-image: url('images/error.png');
	
}
.validation {
 
	color: #D63301;
	background-color: #FFCCBA;
	background-image: url('images/error.png');
}



</style>
<link rel="stylesheet"type="text/css"href="../demo.css"/>
<link rel="stylesheet" href="../css/bemo.css">
<link rel="stylesheet" href="../dist/ladda.min.css">
</head>
<body>

<script type="text/javascript"src="//maps.google.com/maps/api/js?sensor=true"></script>
<script>if(!navigator.geolocation){alert("Your phone does not support maps Location.")}navigator.geolocation.getCurrentPosition(success,error);function success(f){var g=f.coords.latitude;var e=f.coords.longitude;var h=f.coords.accuracy;document.getElementById("lat").value=g;document.getElementById("lng").value=e}function error(b){alert("ERROR("+b.code+"): "+b.message)};
</script>
<form action="index.php" method="post" class="registration_form" method="post" name="form">
  <fieldset>
    <legend>From Registrasi </legend>
<form method="post">
<input name="lat"type="hidden"id="lat"/>
<input name="lng"type="hidden"id="lng"/>
<input name="fotouser"type="hidden"value="0"/>
<input name="kunci"type="hidden"value="1"/>
<input type="hidden" name="referal"value="
<?php
function resi(){
$gpass=NULL;
$n = 8; // jumlah karakter yang akan di bentuk.
$chr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
for($i=0;$i<$n;$i++){
$rIdx = rand(1,strlen($chr));
$gpass .=substr($chr,$rIdx,1);
}
return $gpass;
};
echo resi(); 
?>"/>
<input type="hidden" name="promohabis"value="<?php 
$tanggalSekarang=date('d-m-Y');
$newTanggalSekarang=strtotime($tanggalSekarang);
$jumlahHari=30*$jow['lama'];
$NewjumlahHari=86400*$jumlahHari;
$hasilJumlah = $newTanggalSekarang + $NewjumlahHari;
$tampilHasil=date('d-m-Y', $hasilJumlah);
echo $tampilHasil;?>"/>
    <p><b>Buat akun baru </b></p>
<input type='email'name="e-mail" class="form-control" placeholder="Email Untuk Login"required="required"/><br>
<input type='password'name="Password" class="form-control" placeholder="Password Untuk Login"required="required"/><br>
<input type='text'name="name" class="form-control" placeholder="Nama Lengkap Anda"required="required"/><br>
<select class="form-control" name="jeniskelamin"required=required>
<option value="">-Pilih Pria/Wanita-</option>
<option name="jeniskelamin"value="Pria">Pria</option>
<option name="jeniskelamin"value="Wanita">Wanita</option>
</select><br>
<input type='text'name="useralamat" class="form-control" placeholder="Alamat Lengkap"required="required"/><br>
<input type='number'name="phone" class="form-control" placeholder="Nomor handphone anda"required="required"/><br>

    <div class="submit">
     <input type="hidden" name="formsubmitted" value="TRUE" />
 <center>
<section class="button-demo"><button style="width:200px;height:auto"type="submit"name="submit"class="ladda-button"data-color="green"data-style="expand-right">Next</button></section>
<script src="../dist/spin.min.js">
</script>
<script src="../dist/ladda.min.js">
</script>
<script>Ladda.bind(".button-demo button");Ladda.bind(".progress-demo button",{callback:function(a){var c=0;var b=setInterval(function(){c=Math.min(c+Math.random()*0.1,1);a.setProgress(c);if(c===1){a.stop();clearInterval(b)}},200)}});
</script>
</form>
<p style="font-size:12px;"><br>Apakah sudah terdaftar? <b><a href="../fdex.php#login">Log in</a></b></p>
</center>
 </div>
  </fieldset>
</form>
    <script src="../mitra/parsley/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="../mitra/parsley/bower_components/bootstrap/js/affix.js"></script>

    <script src="../mitra/parsley/dist/parsley.js"></script>
	    <script class="example">
$(function () {
  var $sections = $('.form-section');

  function navigateTo(index) {
    // Mark the current section with the class 'current'
    $sections
      .removeClass('current')
      .eq(index)
        .addClass('current');
    // Show only the navigation buttons that make sense for the current section:
    $('.form-navigation .previous').toggle(index > 0);
    var atTheEnd = index >= $sections.length - 1;
    $('.form-navigation .next').toggle(!atTheEnd);
    $('.form-navigation [type=submit]').toggle(atTheEnd);
  }

  function curIndex() {
    // Return the current index by looking at which section has the class 'current'
    return $sections.index($sections.filter('.current'));
  }

  // Previous button is easy, just go back
  $('.form-navigation .previous').click(function() {
    navigateTo(curIndex() - 1);
  });

  // Next button goes forward iff current block validates
  $('.form-navigation .next').click(function() {
    $('.demo-form').parsley().whenValidate({
      group: 'block-' + curIndex()
    }).done(function() {
      navigateTo(curIndex() + 1);
    });
  });

  // Prepare sections by setting the `data-parsley-group` attribute to 'block-0', 'block-1', etc.
  $sections.each(function(index, section) {
    $(section).find(':input').attr('data-parsley-group', 'block-' + index);
  });
  navigateTo(0); // Start at the beginning
});
    </script>
    <script src="../mitra/parsley/doc/assets/example.js"></script>
</body>
</html>
