<?php

/*setting untuk koneksi ke database */
DEFINE('DATABASE_USER', 'barisand_hospital');
DEFINE('DATABASE_PASSWORD', '}c63AXvSHcrP');
DEFINE('DATABASE_HOST', 'localhost');
DEFINE('DATABASE_NAME', 'barisand_hospital');
/*setting default time zone untuk dapat mengirimm email */
date_default_timezone_set('UTC');

//menetukan pengirim email
define('EMAIL', 'admin@hospital.barisandata.com');

DEFINE('WEBSITE_URL', 'http://hospital.barisandata.com/registrasiemail');


// membuat koneksi ke database
$dbc = @mysqli_connect(DATABASE_HOST, DATABASE_USER, DATABASE_PASSWORD,
    DATABASE_NAME);

if (!$dbc) {
    trigger_error('koneksi tidak sukses: ' . mysqli_connect_error());
}

?>
