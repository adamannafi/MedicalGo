<?php
//including the database connection file
include("dbconnect.php");
//getting id of the data from url
$id_trans = $_GET['id_trans'];
//deleting the row from table
$result = mysql_query("DELETE FROM transaksi WHERE id_trans=$id_trans and status_trans='minta' ");
//redirecting to the display page (index.php in our case)
header("Location:home.php#home");
?>

