<?php
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['user']))
{
	header("Location: home.php#home");
}
$res=mysql_query("SELECT * FROM users WHERE id=".$_SESSION['user']);
$rows=mysql_fetch_array($res);
?>
<head><meta charset="UTF-8"/>
<meta http-equiv="refresh" content="100"><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0"><link rel="stylesheet"type="text/css"href="demo.css"/>
<link rel="stylesheet" href="css/bemo.css">
<link rel="stylesheet" href="dist/ladda.min.css">
</head><body onkeydown="javascript:if(window.event.keyCode==13)window.event.keyCode=9">
<div class="sodrops-top"><span class="actions"><ul>
<li><a href="javascript:history.go(0)" onclick="javascript:showDiv();"><img src="refresh.png"width="25px"/></a></li><li><a onclick="javascript:showDiv();" href="home.php#home"><img src="home.png"width="25px"/></a></li>
</ul></span><div style="color:#fff;margin-left:20px;font-size:18px;font-weight:bold;margin-top:5;">
Invoice
</div></div><br>
<?php 
$id_users = $_SESSION['user'];
$view=mysql_query("SELECT * FROM transaksi INNER JOIN mitra ON transaksi.id_mitra= mitra.id_mitra where transaksi.id_users='$id_users' and transaksi.status_trans='otw'");
while($row=mysql_fetch_array($view)){
$price= $row['price'];
$latmitra= $row['latmitra'];
$lngmitra= $row['lngmitra'];
	?>
<br><br><br><br>
<table id="iseqchart"><tr><th id="index"><center>Profil Medis </center></th></tr><tr style="border-top:1px solid #999"><td><center><div style="font-size:12px"><b>
<?php echo $row['nama_mitra']; ?></b></div><br>
<?php
if($row['foto_mitra']=='0'){
	?>
<img src="profile.png"style="width:80px;border-radius:50%;border:2px solid grey;"/>
	  <?php } else {?>
<img src="foto_mitra/<?php echo $row['foto_mitra'];?>"style="width:80px;border-radius:50%;border:2px solid grey;"/>
	<?php }
	?>
<br>
<table style="width:100%">
<tr style="font-size:12px;color:#565656"><td>Pria/wanita</td><td>:</td><td width="50%"> <?php echo $row["kelamin"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Phone</td><td>:</td><td width="50%"> <?php echo $row['nomorhp']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Sebagai</td><td>:</td><td width="50%"> <?php echo $row["sebagai"]; ?></td></tr></table>
<?php
$cash=$row['tipebayar'];
if ($cash=='cash') { ?>
<small>Anda memilih pembayaran cash, mohon melakukan pembayaran cash ke Medis sesuai nominal layanan <br>Mohon tidak memberikan uang tambahan kepada Medis</small>
<?php } 
if ($cash=='point') {?>
<small>Anda memilih pembayaran Point, 10 Point anda digunakan untuk pembayaran Medis <br>Mohon tidak memberikan uang tambahan kepada Medis</small>
<?php } 
if ($cash=='transfer') {?>
<small>Anda memilih pembayaran Transfer, Pembayaran anda sudah diterima admin untuk diberikan kepada Medis <br>Mohon tidak memberikan uang tambahan kepada Medis</small>
<?php  } ?></td></table>
<div style="color:#444;background-color:#fff;padding:20px;width:100%;">
<br><center><b style="color:green">Invoice Layanan <?php echo $row["layanan"]; ?></b></center>
<b><small>Kode Invoice:</small></b><br/><?php echo $row["invoice"]; ?></br></br>
<b><small>Tanggal Request:</small></b><br/><?php echo $row['tanggal']; ?></br></br>
<b><small>Jenis Layanan:</small></b><br/><?php echo $row['layanan']; ?></br></br>
<b><small>Keterangan Keluhan:</small></b><br/><?php echo $row['keterangan']; ?></br></br>
<b><small>Atas Nama:</small></b><br/><?php echo $row['nama_rumah']; ?></br></br>
<b><small>No. Handphone:</small></b><br/><?php echo $row['nomor']; ?></br></br>
<b><small>Alamat Tujuan:</small></b><br/><?php echo $row['alamat']; ?></br></br>
<b><small>Harga Layanan:</small></b><br/>Rp. <?php $awal = $row['awal'];$kapi = number_format($awal,0,",",".");echo $kapi; ?></br></br>
<b><small>Tarif transport:</small></b><br/>Rp. <?php $transport = $row['transport'];$porti = number_format($transport,0,",",".");echo $porti; ?></br></br>
<div class="mop"style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">
<b><small>Total Biaya: Rp. <?php 
$sistim = $row['harga'];
$rego = number_format($sistim,0,",",".");
echo $rego;?></small>
</b></div>

<br><br>
<p><label style="color:grey">Anda bisa melihat lokasi perjalanan Medis , Jika Medis lama dalam perjalanan atau mengalami kendala yg tidak diinginkan bisa hubungi melalui tombol Telepon.</label></p>
<p>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><center>
<a href="http://hospital.barisandata.com/call.php?id_mitra=<?php echo $row['id_mitra']; ?>" target="_blank"><i style="font-size:60px;color:green" class="fa fa-phone-square" aria-hidden="true"></i></a>
</p>
<iframe width="100%"height="250"frameborder="0"scrolling="yes"marginheight="0"marginwidth="0"src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=<?php echo $row['latmitra']?>,<?php echo $row['lngmitra']?> (custom heading)&amp;output=embed"></iframe></p>
</center>
</div>
<?php }?>
<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.6.1.min.js"></script>		
<script type="text/javascript" src="autosave5/jquery-1.6.1.js"></script>		
	<script type="text/javascript">
	$(document).ready(function(){	
	
		autosave();
	});
	
	function autosave()
	{
		
		var t = setTimeout("autosave()", 5000);
		$('#timestamp').show(50).delay(8000);	
		var id = $("#id").val();
		var lat = $("#lat").val();
		var lng = $("#lng").val();
		
		if (lat.length > 0 || lng.length > 0)
		{
			$.ajax(
			{
				type: "POST",
				url: "autosave.php",
				data: "&id=" + id + "&lat=" + lat + "&lng=" + lng,
				cache: false,
				success: function(message)
				{	
					$('#timestamp').hide(50).delay(3000);
					$("#timestamp").empty().append(message);
				}
			});
		}
	} 
	</script>	
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=true"></script><br><br><br>
<script>if(!navigator.geolocation){alert("Your phone does not support maps Location.")}navigator.geolocation.getCurrentPosition(success,error);function success(c){var b=c.coords.latitude;var d=c.coords.longitude;var a=c.coords.accuracy;document.getElementById("lat").value=b;document.getElementById("lng").value=d}function error(a){}</script>
<form id="article_form" method="post" action="autosave.php">
<input type="hidden" id="id" name="id" value="<?php echo $rows['id_mitra'];?>" />
<input type="hidden" id="lat" type="float" name="lat"/>
<input type="hidden" id="lng" type="float" name="lng"/>
</form><br>
<style>#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<div id="loading" style="display:none">
</div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>
</body>