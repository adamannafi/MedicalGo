<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 session_start();
include_once '../dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: index.php");
}
$res=mysql_query("SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysql_fetch_array($res);
 if($rows['sebagai']=='admin')
      {
	header("Location: ../mitra/dashboard.php");	  
	  }
	   if($rows['sebagai']=='demo')
      {
	header("Location: ../mitra/dashboard.php");	  
	  }
	  
?>
