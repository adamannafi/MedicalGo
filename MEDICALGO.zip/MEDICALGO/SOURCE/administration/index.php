<?php
session_start();
include_once '../dbconnect.php';
if(isset($_POST['btn-login']))
{
	$mitra_email = mysql_real_escape_string($_POST['mitra_email']);
	$mitra_pass = mysql_real_escape_string($_POST['mitra_pass']);
	$mitra_email = trim($mitra_email);
	$mitra_pass = trim($mitra_pass);
	$res=mysql_query("SELECT id_mitra, mitra_email, mitra_pass FROM mitra WHERE mitra_email='$mitra_email'");
	$row=mysql_fetch_array($res);
	$count = mysql_num_rows($res); // if uname/pass correct it returns must be 1 row
	if($count == 1 && $row['mitra_pass']==md5($mitra_pass))
	{
		$_SESSION['mitra'] = $row['id_mitra'];
	?><script>document.location.href="home.php";</script><?php

		}
	else
	{
		?><div style="position:fixed;color:#f00;margin-left:20px">Email & Password not valid, please login again...</div><?php
	}
	
}
?> 
<title>Administrator Services | MedicalGO</title>
<link rel="shortcut icon" type="text/css" href="../Data/FR.png">
<meta charset="UTF-8">
<meta name="description" content="Trol admin">
<meta name="robots" content="index, follow" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="../demo.css"/><link rel="stylesheet"href="../css/bemo.css"><link rel="stylesheet"href="../dist/ladda.min.css"></head>
<style>body,html{height:100%;margin:0}.bg{background-image:url("wallpaper.jpg");height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;z-index:-99999;opacity:.4}</style>
<style>::-webkit-input-placeholder{color:grey}:-moz-placeholder{color:grey;opacity:1}::-moz-placeholder{color:grey;opacity:1}:-ms-input-placeholder{color:grey}::-ms-input-placeholder{color:grey}#input{color:#fff;position:relative;display:inline-block;width:100%}nav{position:absolute;content:'';height:40px;height:2px;background:#53b5e6;transition:all .2s linear;width:0;bottom:1px}input:hover ~ nav{width:100%}</style>
</head>
<body style="background:#b43a49;background:linear-gradient(90deg,rgba(180,58,73,1) 0,rgba(253,29,94,0.773546918767507) 58%,rgba(252,176,69,1) 100%)"><br><br><br>
<div style="background:#fffffffa;border-top:5px solid #09C;-webkit-box-shadow:0 2px 2px 0 rgba(0,0,0,0.14),0 3px 1px -2px rgba(0,0,0,0.12),0 1px 5px 0 rgba(0,0,0,0.2);box-shadow:0 2px 2px 0 rgba(0,0,0,0.14),0 3px 1px -2px rgba(0,0,0,0.12),0 1px 5px 0 rgba(0,0,0,0.2);display:block;margin:0 auto;min-height:0;width:450px;position:fixed;left:0;right:0;z-index:99999">
<center><br><br><h3 style="color:#5792b5">Please Login</h3><p><br><img src="../logo.png"width="150px"/><br><div style="font-weight:bold;color:#666a78;margin-top:20px">MedicalGO Owner Management</div></p>
<form style="width:80%"method="post">
<div id="input"><input style="color:#444;background:url(../email.png) no-repeat 12px;padding-left:40px;vertical-align:middle;border-bottom:1px solid #ddd;background-size:20px" type='text'name="mitra_email"class='holo'placeholder="Email" aria-required="true" required="required"/>
<nav></nav></div>
<br><br>
<div id="input"><input style="color:#444;background:url(../password.png) no-repeat 12px;padding-left:40px;vertical-align:middle;border-bottom:1px solid #ddd;background-size:20px" type="text" name="mitra_pass"class='holo'placeholder="Password" aria-required="true" required="required"/>
<nav></nav></div><br><br>
<section class="button-demo"><button style="width:200px;height:auto"type="submit"name="btn-login"class="ladda-button"data-color="blue"data-style="expand-right">Log in</button></section><script src="dist/spin.min.js"></script><script src="dist/ladda.min.js"></script><script>Ladda.bind(".button-demo button");Ladda.bind(".progress-demo button",{callback:function(e){var f=0;var d=setInterval(function(){f=Math.min(f+Math.random()*0.1,1);e.setProgress(f);if(f===1){e.stop();clearInterval(d)}},200)}});</script></form></center>
<br><br><center>
<small style="color:grey;font-size:11px;">if forget admin password can reset from database<br>or ask high level your adimistrator</small><br><br></center></div>
<div class="bg" style="background-size:cover">
</div>
</body>