<?php
include_once('Veritrans.php');

// Set our server key
Veritrans_Config::$serverKey = 'SB-Mid-server-_KpmQs-mbCh9Bg3ImvT88LOL';

// Uncomment for production environment
// Veritrans_Config::$isProduction = true;

// Comment to disable sanitization
Veritrans_Config::$isSanitized = true;

// Comment to disable 3D-Secure
Veritrans_Config::$is3ds = true;


// Fill transaction data

$jumlah = $_GET['jum'];	
$transaction = array(
    'transaction_details' => array(
        'order_id' => rand(),
        'gross_amount' => $jumlah, // no decimal allowed for creditcard
        )
		
    );

$vtweb_url = Veritrans_Vtweb::getRedirectionUrl($transaction);

// Redirect
header('Location: ' . $vtweb_url);
?>
