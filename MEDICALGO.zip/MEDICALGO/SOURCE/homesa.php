<?php
$session_lifetime = 3600 * 24 * 860; // 2 days
session_set_cookie_params ($session_lifetime);
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['user']))
{
	header("Location: fdex.php#login");
}
$res=mysql_query("SELECT * FROM users WHERE id=".$_SESSION['user']);
$rows=mysql_fetch_array($res);
?>
<?php
$jiew=mysql_query("SELECT * FROM transaksi where id_users='".$_SESSION['user']."' and aktif='yes'");
$jow=mysql_fetch_array($jiew);
	?>
<?php 
 if($jow['status_trans']=='dijemput')
      { ?>
<script>document.location.href="about.php#row";</script><?php }
?>
<?php
if($jow['status_trans']=='otw')
      {?>
<script>document.location.href="about.php#otw";</script><?php }?>
<?php 
 if($jow['status_trans']=='ttd')
      { ?>
<script>document.location.href="homesa.php#ttd";</script><?php }
?>
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link href="css/timepicki.css"rel="stylesheet">
<link rel="stylesheet"href="themes/base/jquery.ui.all.css">
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<link rel="stylesheet"type="text/css"href="demo.css"/>
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:#000;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:-50px;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#cari{display:none}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<link rel="stylesheet"href="css/bemo.css">
<link rel="stylesheet"href="dist/ladda.min.css">
<link href="estilos.css" rel="stylesheet"/>
</head><body onkeydown="javascript:if(window.event.keyCode==13)window.event.keyCode=9">
   <div id="mobile-nav"></div>
    <nav>
<div style="border-radius: 0px 0px 0px 100px;top:0;width:100%;background:#cacaca;height:200px;">
<center>
<img src="profile.png" style="margin-top:70px;width:100px;height:auto;border-radius:50%;top:0;"/>
<br><i style="color:#fff;margin-top:60px"><?php echo $rows['first_name'];?><br></i></center>
</div>
      <ul class="menu" style="font-family:Segoe UI light;">
        <li><a href="home.php#home"><img style="vertical-align:middle" src="dist/favorit.png" width="20px"/>  Menu</a></li>
        <li><a href="home.php#basrent"><img style="vertical-align:middle" src="dist/history.png" width="20px"/>  History</a></li>
        <li><a href="home.php#saldo"><img style="vertical-align:middle" src="dist/free.png" width="20px"/>  Point</a></li>
        <li><a href="about.php#about" onclick="javascript:showDiv();"><img style="vertical-align:middle" src="dist/jadwal.png" width="20px"/>  invoice</a></li>
		<li><a href="home.php#setting"><img style="vertical-align:middle" src="dist/setting.png" width="20px"/>  Settings</a></li>
		<li><a href="logout.php?logout"><img style="vertical-align:middle" src="dist/logout.png" width="20px"/>  Sign Out</a></li>
      </ul>
    </nav>
	
<header style="border-radius: 0px 0px 20px 20px;background: #7b0000;position: fixed;width: 100%;height: 90px;z-index: 999;border-bottom: 5px solid #c81b22;">
<div style="margin-top:15px;margin-right:20px;font-size:20px;font-family:Segoe UI light;color:#fff">
<center><img src="logo.png"width="60px"/></center></div>
</header>
<div id="saldo"class="panel" style="background:#fff"><div class="content" style="background:#fff;color:#000"><br><br><br><br>
<center style="color:#000"><h4>Point anda saat ini:</h4>
<b><?php 
$sistim = $rows['saldo'];
$jimjim = $rows['point'];
$saldo = $sistim/1000;
$kaldu=$saldo+$jimjim;
echo $kaldu;?></b>
</center><br>
<center style="padding:10px;font-size:12px;color:grey;font-family:Segoe UI light">atau senilai Rp. <?php 
$kitim = $rows['saldo'];
$jimjim = $rows['point'];
$ridim=$jimjim*1000;
$sistim=$kitim+$ridim;
$saldo = number_format($sistim,0,",",".");
echo $saldo;?>,-<br>Setelah registrasi anda mendapat 10 point. Point anda dapat digunakan untuk pembayaran Layanan.<br>
<?php
$promohabis=$rows['promohabis'];
 if($promohabis=='-')
      { ?>
<?php }else{?>
Point promo anda akan Expired jika tidak digunakan untuk order layanan hingga tanggal <?php echo $promohabis; ?>
<?php } ?>
</center>
<br>
<center style="font-size:14px;color:#000;font-family:Segoe UI;background:#dedede;border-top:1px solid grey;border-bottom:1px solid grey;border-style:dashed;">
<?php 
$her=mysql_query("SELECT * FROM infobank where idinfo='1'");
$mul=mysql_fetch_array($her);
$milk=mysql_query("SELECT * FROM trans_saldo where id_users=".$_SESSION['user']);
while($ent=mysql_fetch_array($milk)){
 if($ent['statussaldo']=='minta')
      { 
   if($ent['tipesaldo']=='topup')
      { ?>
<b><small>Anda request Topup</small></b><br><br>
Silahkan melakukan transfer ke rekening admin MedicalGO:<br>
Nama bank: <?php echo $mul['namabank'];?><br>
Nomor Rekening: <?php echo $mul['norek'];?><br>
Atas nama: <?php echo $mul['namaorang'];?><br><br>
Nomor Handphone: <?php echo $mul['jambuka'];?><br>
<small>Setelah transfer, segera lakukan konfirmasi pembayaran</small><br><br>
<center>
<a href="#konfirmasi">
<button style="width:100%;font-size:15px;height:auto;margin-top:0px;padding-bottom:20px;border-radius:0px;"class="ladda-button"data-color="green">Konfirmasi pembayaran</button>
</a>
</center>
	  <?php }
	  if($ent['tipesaldo']=='withdraw')
      {?>
<b><small>Anda request Withdrawal</small></b><br><br>

	  <? }}
 if($ent['statussaldo']=='dijemput')
 {
?><br>
<b><small>Request <?php echo $ent['tipesaldo'];?> Anda sedang diproses Admin</small></b><br><br>
<?php }}
$input = "SELECT * FROM trans_saldo WHERE id_users='".$_SESSION['user']."' and statussaldo='minta' or statussaldo='dijemput'";
$result = mysql_query($input);
$count = mysql_num_rows($result);
if($count == 0){?>
 </center>
 <noscript><center>
<section class="button-demo" style="padding:0;width:100%">
<a href="topup.php?id=<?php echo $rows['id'];?>"><button style="width:100%;border-radius:0px;" class="ladda-button" data-color="blue" data-style="expand-right">
<small>Toup Up/Deposit saldo</small></button></a>
</section>
<center>
<a href="wd.php?id=<?php echo $rows['id'];?>">
<button style="width:100%;font-size:15px;height:auto;margin-top:0px;padding-bottom:20px;border-radius:0px;"class="ladda-button"data-color="green">Withdraw Saldo</button>
</a>
</center></noscript>
<?php }?>
</div></div>
<div id="konfirmasi"class="panel" style="background:#fff"><div class="content" style="background:#fff;color:#000"><br>
<center>
<b><small>Konfirmasikan pembayaran anda</small></b></center>
<br>
<form id="form"action="topup.php" method="post">
<input name="id_users" type="hidden" value="<?php echo $_SESSION['user'];?>"/>
<center style="color:#000"><div id="input">Nama bank :<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='text'name="banksaldo"class='holo' placeholder="Tulis Nama bank anda" aria-required="true" required="required"/>
<nav></nav></div><br>
<center style="color:#000"><div id="input">Nomor Rekening :<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='number'name="nomorrek"class='holo' placeholder="Tulis Nomor rekening anda" aria-required="true" required="required"/>
<nav></nav></div><br>
<center style="color:#000"><div id="input">Atas Nama :<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='text'name="namauser"class='holo' placeholder="Tulis Nama akun pemilik rekening" aria-required="true" required="required"/>
<nav></nav></div><br>
<button type="submit"name="konfirmasi" style="width:200px;color:#fff;background:green;border:none;padding:10px;border-radius:20px;" onclick="javascript:showDiv();">Konfirm</button>
<br><br>
<a href="car.php#saldo"style="color:orange">Kembali</a>
</center>
</form>
</div></div>
<div id="beby"class="panel" style="background:#fff"><div class="content" style="background:#fff;color:#000"><br><br><br><br>
<br><?php include "dbconnect.php";?>
<script src="jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		<!-- event textbox keyup
		$("#golek").keyup(function() {
			var strcari = $("#golek").val(); <!-- mendapatkan nilai dari textbox -->
			if (strcari != "") <!-- jika value strcari tidak kosong-->
			{
				$("#jesil").html("<img width=300px src='loading.gif'/>") <!-- menampilkan animasi loading -->
				<!-- request data ke cari.php lalu menampilkan ke <div id="hasil"></div> -->
				$.ajax({
					type:"post",
					url:"caricar.php",
					data:"r="+ strcari,
					success: function(data){
						$("#jesil").html(data);
					}
				});
			}
		});
    });
</script>
<br><br><center><a href="#cari"><img src="back.png" width="20px"/><b> Kembali</b></a></center><br><br>
<div><center><input type="text" name="golek" id="golek" placeholder="Ketik nama kota, lalu klik lihat" style="width: 90%;border-bottom: 1px solid #989494;border-left: none;border-right: none;border-top: none;padding: 5px;"/></center></div>
</div></div>

<div id="setting"class="panel" style="background:#fff">
<div class="content" style="background:#fff;color:#000"><br><br>
<form id="form"action="mitra/simpanuss.php" enctype="multipart/form-data"  method="post" name="postform">
   <?php
	include_once("dbconnect.php");
$id = $_SESSION['user'];
	$query=mysql_fetch_array(mysql_query("select * from users where id='$id'"));
	$id=$query['id'];
	$first_name = $query['first_name'];
$password= $query['password'];
	$email = $query['email'];
	$phone = $query['phone'];
	$jeniskelamin = $query['jeniskelamin'];
	$ktp = $query['ktp'];
	$referal = $query['referal'];
$fotouser= $query['fotouser'];
	?>
<input type="hidden" name="id" value="<?php echo $id;?>"/>
<br><br>
<center>
<?php
 if($fotouser=='0')
      { ?>
<img src="profile.png" style="width:100px;"/>
<?php }else{?>
<img src="/fotouser/<?php echo $fotouser;?>" style="width:250px;"/><br><br>
<?php } ?>
</center>
<table style="color:#000;">
<input type="hidden" name="fotouser" value="<?php echo $fotouser?>" />
<input type="hidden" name="password" value="<?php echo $query['password'];?>">
<tr>
<td>Ganti Foto</td>
<td><input type="file" name="fotouser" size="999999" value="<?php echo $fotouser;?>"/></td>
</tr>
<tr>
<td>Nama </td>
<td><input type="text" name="first_name"required="required" value="<?php echo $first_name;?>"></td>
</tr>
<tr>
<td>Pria/Wanita </td>
<td><input type="text" name="jeniskelamin"required="required" value="<?php echo $jeniskelamin;?>"></td>
</tr>
<tr>
<td>Nomor KTP </td>
<td><input type="text" name="ktp"required="required" value="<?php echo $ktp;?>"></td>
</tr>
<tr>
<tr>
<tr>
<td>Email </td>
<td><input type="text" name="email"required="required" value="<?php echo $email;?>"></td>
</tr>
<tr>
<td>Password </td>
<td><input type="password" name="password" placeholder="isikan password!!"required="required" value=""></td>
</tr>
<tr>
<td>Nomor Handphone </td>
<td><input type="text" name="phone"required="required" value="<?php echo $phone;?>"></td>
</tr>
    <tr>
      <td></td>
      <td><br><input style="background:green;color:#fff;" type="submit" value="Simpan"  onclick="return confirm('Apakah Anda yakin akan mengubah account?')"name="kirim" /><br> <br><a href="home.php#home"style="color:orange">Batal Ubah data</a></td>
     
    </tr>
    </table>
    
    </form>
</div></div>

<div id="home"class="panel"><div class="content"><br><br>	
<?php 
$jiew=mysql_query("SELECT * FROM layanan");
while($jows=mysql_fetch_array($jiew)){
?>
<table style="padding:10px;margin-top:26px;background: none;border-top:1px solid #ffd9d9;border-bottom:1px solid #ffd9d9"id="iseqchart">
<tr style="font-size:10px">

<td width="20%">
<?php
 if($jows['picture']=='0')
      { ?>
<img src="nopic.png" style="margin-top: -40px;width:80px;"/>
<?php }
 if($jows['picture']=='')
      { ?>
<img src="nopic.png" style="margin-top: -40px;width:80px;"/>
<?php }
else{?>
<img src="fotobarang/<?php echo $jows['picture'];?>" style="margin-top: -40px;width:70px;"/>
<?php } ?></td>

<td width="50%"style="padding:10px">
<b><small><?php echo $jows['nama_layanan'];?>
</small></b><br><?php echo $jows['keterangan_layanan'];?>
</td>
<td style="padding:10px">
<a onclick="javascript:showDiv();" href="homesin.php?id_layanan=<?php echo $jows['id_layanan'];?>"><section class="button-demo" style="padding:0px">
<button style="float:right;width:80px;font-size:12px;height:auto;border-radius: 20px;background: #fff;color: #7b0000;border:2px solid #7b0000;"class="ladda-button"data-color="green"data-style="expand-right">Pilih</button>
</section>
</a></td>
</tr>
</table>
<script src="dist/spin.min.js">
</script>
<script src="dist/ladda.min.js">
</script>
<script>Ladda.bind(".button-demo button");Ladda.bind(".progress-demo button",{callback:function(a){var c=0;var b=setInterval(function(){c=Math.min(c+Math.random()*0.1,1);a.setProgress(c);if(c===1){a.stop();clearInterval(b)}},200)}});
</script>
<?php } ?>
</div></div>
<div id="basrent"class="panel" style="background:#fff" >
<div class="content" style="width:100%;padding-right:0px;padding-left:0px"><br><br><br><b><center style="font-size:14px;color:#444">History Layanan</center></b>
<?php
$users = $_SESSION['user'];
$kim=mysql_query("SELECT * FROM transaksi where id_users='$users' ORDER BY id_trans DESC");
while($bow=mysql_fetch_array($kim)){
if($bow['aktif']=='no')
      { ?>
<table style="padding:10px;margin-top:5px;background-color: #f4f4f5;"id="iseqchart">
<tr style="font-size:12px;color:#565656"><td>Kode Invoice</td><td>:</td><td width="50%"> <?php echo $bow['invoice']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Tipe Layanan</td><td>:</td><td width="50%"> <?php echo $bow['layanan']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Tanggal Request</td><td>:</td><td width="50%"> <?php echo $bow['tanggal']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Waktu Kunjungan</td><td>:</td><td width="50%"> <?php echo $bow['timepicker1']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Harga Layanan</td><td>:</td><td width="50%"> Rp.<?php echo $bow['harga']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Atas Nama</td><td>:</td><td width="50%"> <?php echo $bow["nama_rumah"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Alamat</td><td>:</td><td width="50%"> <?php echo $bow["alamat"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Status</td><td>:</td><td width="50%"> Selesai</td></tr>

</table>
  <br><br><?php }};?>
</div> </div>
<div id="ttd"class="panel" style="background:#fff" >
<div class="content" style="width:100%;padding-right:0px;padding-left:0px"><br><br><br>
<?php
$users = $_SESSION['user'];
$jir=mysql_query("SELECT * FROM transaksi where id_users='$users' ORDER BY id_trans DESC");
while($tong=mysql_fetch_array($jir)){
if($tong['status_trans']=='ttd')
      { ?>
<table style="color:#444;padding:10px;margin-top:5px;background-color: #f4f4f5;"id="iseqchart">
<tr><td>
<center><b><small>Halo <?php echo $tong['nama_rumah']; ?>, </small></b><br>Layanan <?php echo $tong['layanan']; ?> dengan Kode Invoice <?php echo $tong['invoice']; ?> sudah selesai. <br> 
<img src="logobig.png" width="200px"/>
<br>Silahkan tanda tangan untuk konfirmasi, Klik tombol tanda tangan!...<br><br>
<a target="_blank" href="http://hospital.barisandata.com/SecureURL-kKHGAvk_WkkvKAKBkAkbAA/signature.php?invoice=<?php echo $tong['invoice']; ?>" width="100%"style="border-radius:10px;width:100%;padding:15px;
background:-webkit-gradient(linear, 82% 0%, 10% 21%, from(#6E0070), to(#370061));
color:#fff;font-weight:bold;font-size:13px;font-decoration:none;underline:none">Tanda Tangan</a><br><br>
</center>
</td></tr>
</table>
  <br><br><?php }};?>
</div> </div>
<div id="loading" style="display:none">
</div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>
<script src="js/jret.js"></script>
<script src="js/mostrar_nav.js"></script>
</body>
<script>function onReady(callback){var intervalID=window.setInterval(checkReady,1000);function checkReady(){if(document.getElementsByTagName('body')[0]!==undefined){window.clearInterval(intervalID);callback.call(this);}}}
function show(id,value){document.getElementById(id).style.display=value?'block':'none';}
onReady(function(){show('home',true);show('loading',false);});
</script>