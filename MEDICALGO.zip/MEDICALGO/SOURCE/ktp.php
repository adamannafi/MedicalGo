<?php
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['user']))
{
	header("Location: fdex.php#login");
}
$res=mysql_query("SELECT * FROM users WHERE id=".$_SESSION['user']);
$rows=mysql_fetch_array($res);
?>
<?php 
$id_users = $_SESSION['user'];
$view=mysql_query("SELECT * FROM transaksi where id_users='$id_users'");
while($row=mysql_fetch_array($view)){
	?><?php 
 if($row['status_trans']=='minta' && $row['user_attach']=='0')
      { ?>
<script>document.location.href=" uploadstnk.php#about";</script><?php }
?><?php 
 if($row['status_trans']=='minta' && $row['user_attach']=='1')
      { ?>
<script>document.location.href=" about.php#about";</script><?php }
?><?php 
 if($row['status_trans']=='otw')
      { ?>
<script>document.location.href=" about.php#otw";</script><?php }	   
  
if($row['status_trans']=='dijemput')
      {?>
<script>document.location.href=" about.php#about";</script><?php }	} ;
 ?>
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link href="css/timepicki.css"rel="stylesheet">
<link rel="stylesheet"href="themes/base/jquery.ui.all.css">
<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="jquery.ui.addresspicker.js"></script>
<link rel="stylesheet"type="text/css"href="demo.css"/>
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:#000;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:0;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}}</style>
<link rel="stylesheet"href="css/bemo.css">
<link rel="stylesheet"href="dist/ladda.min.css">
</head>
<?php
if(isset($_POST['tambah'])){
if (empty($_POST['kendaraan'])) {
   ?>
<script>window.alert("Isi kolom Merek Mobil!");window.history.back(-2);</script><?php
  return false;
}
if (empty($_POST['lat'])) {
   ?>
<script>window.alert("Nyalakan GPS, Agar peta lokasi anda terdeteksi akurat!");window.history.back(-2);</script><?php
  return false;
}if (empty($_POST['alamat'])) {
   ?>
<script>window.alert("Error... anda belum mengisi kolom alamat");window.history.back(-2);</script><?php
  return false;
}if (empty($_POST['nama_rumah'])) {
   ?>
<script>window.alert("Error... anda belum mengisi kolom nama");document.location.href="stnk.php#home";</script><?php
  return false;
}if (empty($_POST['nama_rumah'])) {
   ?>
<script>window.alert("Error... anda belum mengisi kolom nama");document.location.href="stnk.php#home";</script><?php
  return false;
}if (empty($_POST['timepicker1'])) {
   ?>
<script>window.alert("Error... tentukan jam penjemputan dokumen");document.location.href="stnk.php#home";</script><?php
  return false;
}
$tanggal= $_POST['tanggal'];
$id_users= $_POST['id_users'];
$id_mitra= $_POST['id_mitra'];
$nama_rumah= $_POST['nama_rumah'];
$keterangan	= $_POST['timepicker1'];
$lat= $_POST['lat'];
$lng= $_POST['lng'];
$kodetrans= $_POST['kodetrans'];
$harga= $_POST['harga'];
$status_trans= $_POST['status_trans'];
$aktif= $_POST['aktif'];
$nomor= $_POST['nomor'];
$foto_mobil= $_POST['foto_mobil'];
$foto_ktp= $_POST['foto_ktp'];
$foto_bpkb= $_POST['foto_bpkb'];
$foto_stnk= $_POST['foto_stnk'];
$mitra_attach= $_POST['mitra_attach'];
$alamat= $_POST['alamat'];
$online= $_POST['online'];
$layanan= $_POST['layanan'];
$kendaraan= $_POST['kendaraan'];
$deskripsi= $_POST['deskripsi'];
$invoice= $_POST['invoice'];
$jatuhtempo= $_POST['jatuhtempo'];
$input = "SELECT id_users FROM transaksi WHERE id_users='$id_users' and status_trans='minta'";
$result = mysql_query($input);
$count = mysql_num_rows($result); // if email not found then register
if($count == 0){
	if(mysql_query("INSERT INTO transaksi VALUES('', '$tanggal', '$id_users', '$id_mitra', '$nama_rumah', '$keterangan', '$lat', '$lng', '$kodetrans', '$harga', '$status_trans', '$aktif', '$nomor', '$foto_mobil', '$mitra_attach', '$alamat', '$online', '$layanan', '$kendaraan', '$deskripsi', '$invoice', '$foto_ktp', '$foto_bpkb', '$foto_stnk', '$jatuhtempo')"))
			{
			?>
<script>document.location.href="uploadstnk.php#about";</script><?php
		}
		else
		{
			?>
<?php
		}		
	}
	else{
			?>
<?php
	}
	
}
	
?>
<script>$(function(){var a=$("#addresspicker").addresspicker({componentsFilter:"country:ID"})});</script>
<body onload="getLocation()" onkeydown="javascript:if(window.event.keyCode==13)window.event.keyCode=9">
<div class="sodrops-top">
<span class="actions">
<ul>
<li><a href="javascript:history.go(0)"><img src="refresh.png"width="25px"/></i></a></li>
<li><a><img src="fa-list-ul.png"width="25px"/></a>
<ul class="dropdown">
<li><a href="about.php#about">History</a></li>
<li><a href="fdex.php#jogin">Home</a></li>
<li><a href="logout.php?logout">Logout</a></li>
</ul></li>
</ul>
</span>
<div style="margin-left:20px;font-size:18px;font-weight:bold"><a href="fdex.php#jogin" style="color:#grey;text-decoration:none"><img style="vertical-align:middle"src="back.png" width="20px"/></a><img src="android1.png"width="40px"/>
</div>
</div>
<?php 
$jin=mysql_query("SELECT * FROM layanan where id_layanan='2'");
$esti=mysql_fetch_array($jin);
?> 
<div id="home"class="panel"><div class="content"><br>
<form id="form"action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
<br><center><b style="font-family:Segoe UI light;color:grey">Request Perpanjangan STNK</b></center><p><label style="font-size:13px"><label>Lokasi Jemput dokumen: <br>Rumah anda, Apartemen, kantor dll <br>(Geser Marker sesuai Lokasi anda saat ini)</label>
<div id="mapholder"></div>
<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
<script type="text/javascript"src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAO4lbxY6SKygcJxTuzu-Qi7kAAP9SdAwM&callback=initMap"></script>
<script>var x=document.getElementById("demo");function getLocation(){if(navigator.geolocation){navigator.geolocation.getCurrentPosition(showPosition,showError)}else{x.innerHTML="Geolocation is not supported by this browser."}}function showPosition(a){lat=a.coords.latitude;lon=a.coords.longitude;document.getElementById("lat").value=lat;document.getElementById("lng").value=lon;latlon=new google.maps.LatLng(lat,lon);mapholder=document.getElementById("mapholder");mapholder.style.height="250px";mapholder.style.width="100%";var c={center:latlon,zoom:14,mapTypeId:google.maps.MapTypeId.ROADMAP,mapTypeControl:false,navigationControlOptions:{style:google.maps.NavigationControlStyle.SMALL}};var d=new google.maps.Map(document.getElementById("mapholder"),c);var b=new google.maps.Marker({position:latlon,map:d,title:"You are here!",draggable:true});google.maps.event.addListener(b,"dragend",setCoordinates)}function setCoordinates(a){document.getElementById("lat").value=a.latLng.lat();document.getElementById("lng").value=a.latLng.lng()}function showError(a){switch(a.code){case a.PERMISSION_DENIED:x.innerHTML="User denied the request for Geolocation.";break;case a.POSITION_UNAVAILABLE:x.innerHTML="Location information is unavailable.";break;case a.TIMEOUT:x.innerHTML="The request to get user location timed out.";break;case a.UNKNOWN_ERROR:x.innerHTML="An unknown error occurred.";break}}</script>
</p>
<input type="hidden" name="id_users"value="<?php echo $rows['id']; ?>"/>
<input type="hidden" name="nomor"value="<?php echo $rows['phone']; ?>"/>
<input type="hidden" name="invoice"value="0"/>
<input type="hidden" name="jatuhtempo"value="
<?php
$tanggalSekarang=date('d-m-Y');
$newTanggalSekarang=strtotime($tanggalSekarang);
$jumlahHari=365-14;
$NewjumlahHari=86400*$jumlahHari;
$hasilJumlah = $newTanggalSekarang + $NewjumlahHari;
$tampilHasil=date('d-m-Y', $hasilJumlah);
echo $tampilHasil;
?>
"/>
<input type="hidden" name="foto_mobil"value="0"/>
<input type="hidden" name="foto_ktp"value="0"/>
<input type="hidden" name="foto_bpkb"value="0"/>
<input type="hidden" name="foto_stnk"value="0"/>
<input type="hidden"name="lat"id="lat"/>
<input type="hidden"name="lng"id="lng"/>
<input type="hidden" name="layanan"value="<?php echo $esti['nama_layanan']; ?>"/>
<input type="hidden" name="tanggal"value="<?php echo date('d-m-Y'); ?>"/>
<input type="hidden" name="harga"value="<?php echo $esti['harga_layanan']; ?>"/>
<input type="hidden" name="id_mitra"value="0"/>
<input type="hidden" name="mitra_attach"value="0"/>
<input type="hidden" name="status_trans"value="minta"/>
<input type="hidden" name="aktif"value="yes"/>
<input type="hidden" name="online" value="unread"/>
<input type="hidden" name="kodetrans"value="
<?php
function resi(){
$gpass=NULL;
$n = 8; // jumlah karakter yang akan di bentuk.
$chr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
for($i=0;$i<$n;$i++){
$rIdx = rand(1,strlen($chr));
$gpass .=substr($chr,$rIdx,1);
}
return $gpass;
};
echo resi(); 
?>"/>
<p><label>Tambahkan nama jalan: </label>
<div class="demo"><div class='input'>
<input id="addresspicker"type="text"name="alamat"placeholder="Ketik Nama Jalan, Kota, Nomor rumah"required="required"/>
</div></div></p>
<p><label>Contact person :</label>
<input id="nama_rumah" name="nama_rumah"type="text"placeholder="Nama anda"required="required"/></p><p>
<label>Nomor handphone :</label>
<?php echo $rows['phone']; ?></p><p>
<label style="color:#565656">Lengkapi Deskripsi :
</label><p><input id="kendaraan" name="kendaraan"type="text"placeholder="Apa merek Mobil, Tipe Mobil"required="required"/></p><p>
</p>
<p>
<textarea id="deskripsi" name="deskripsi"placeholder="deskripsikan permasalahan anda (opsional)"required="required">
</textarea></p>
<p><label>Tentukan jam :<br>(untuk biro jasa yang akan menjemput dokumen anda)</label><div class="inner cover indexpicker"><input id="timepicker1"type="text"placeholder="Pilih Jam kunjungan"name="timepicker1"required="required"/></div>
<script src="js/timepicki.js"></script>
<script>$("#timepicker1").timepicki();</script></p><br><br><br><br>
<section class="button-demo">
<button style="width:200px;height:auto"type="submit"name="tambah"class="ladda-button" data-color="green" data-style="expand-right">Lanjut</button>
</section>
<script src="dist/spin.min.js"></script>
<script src="dist/ladda.min.js"></script>
<script>Ladda.bind(".button-demo button");Ladda.bind(".progress-demo button",{callback:function(e){var f=0;var d=setInterval(function(){f=Math.min(f+Math.random()*0.1,1);e.setProgress(f);if(f===1){e.stop();clearInterval(d)}},100)}});</script>
</form></div></div>
<script>$('#form').submit(function(){if($.trim($("#nama_rumah").val())===""||$.trim($("#addresspicker").val())===""){alert('Please input your name, phone, and adress');return false;}});</script>
</div>
</body>