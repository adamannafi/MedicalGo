<?php
session_start();
include_once 'dbconnect.php';
$computerId = $_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT'].$_SERVER['LOCAL_ADDR'].$_SERVER['LOCAL_PORT']; 
$benjo=str_replace(' ', '', $computerId);
	$res=mysqli_query($mysqli, "SELECT * FROM users WHERE forgot_pass_identity='$benjo'");
	$row=mysqli_fetch_array($res);
	$rembo=$row['forgot_pass_identity'];
	
$res=mysqli_query($mysqli, "SELECT * FROM users WHERE forgot_pass_identity='".$benjo."'");
$row=mysqli_fetch_array($res);
$tession = $row['id'];
if($tession)
{
		$_SESSION['user'] = $tession;
	?>
<script>document.location.href="home.php";</script><?php
}
if(!isset($_SESSION['user']))
{
	?>
<script>document.location.href="fdex.php#login";
</script><?php
}
if(isset($_POST['btn-login']))
{

	$email = mysql_real_escape_string($_POST['email']);
	$upass = mysql_real_escape_string($_POST['pass']);
	$email = trim($email);
	$upass = trim($upass);
	$res=mysql_query("SELECT id, first_name, password, kunci FROM users WHERE email='$email'");
	$row=mysql_fetch_array($res);
		
	if($row['kunci']=='1')
      { ?> <style>
#hideme {
    -webkit-animation: cssAnimation 15s forwards; 
    animation: cssAnimation 15s forwards;
}
@keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
@-webkit-keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
</style>
<div id="hideme"style="width:100%;position:relative;color:#ef2525;z-index:99999;top:0px;padding:20px;box-shadow:5px 2px 8px 1px rgba(0,0,0,0.15);background-color:rgba(255, 255, 82, 0.95)"><center>Akun anda belum diverifikasi, mohon periksa email dari kami lalu klik link verifikasi
<br>
<br><center><b><a href="fdex.php#login">Ulangi Login</a></b></center>
</div><?php   return false; }
	$count = mysql_num_rows($res);
	if($count == 1 && $row['password']==md5($upass))
	{
		$_SESSION['user'] = $row['id'];
		?>
<script>document.location.href="home.php#home";
</script><?php
	}
 
	else
	{
		?>
<style>
#hideme {
    -webkit-animation: cssAnimation 15s forwards; 
    animation: cssAnimation 15s forwards;
}
@keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
@-webkit-keyframes cssAnimation {
    0%   {opacity: 1;}
    90%  {opacity: 1;}
    100% {opacity: 0;}
}
</style>
<div id="hideme"style="width:100%;position:relative;color:#ef2525;z-index:99999;top:0px;padding:20px;box-shadow:5px 2px 8px 1px rgba(0,0,0,0.15);background-color:rgba(255, 255, 82, 0.95)"><center>Email atau Password tidak cocok...
<br>
<br><center><b><a href="fdex.php#login">Ulangi Login</a></b></center>
</div><?php
	}

}
?>

<head>
<meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0"><link rel="stylesheet"type="text/css"href="demo.css"/><link href="style.css"rel="stylesheet"><meta name="HandheldFriendly"content="True"><meta name="MobileOptimized"content="320"><meta name="viewport"content="width=device-width, initial-scale=1.0">
<style type="text/css">body{font-family:Segoe UI;}h1{font-size:2.2em;padding:0 .5em 0}h2{font-size:1.5em}.header{padding:1em 0}.col{padding:1em 0;text-align:center}</style>
<link rel="stylesheet" href="css/bemo.css">
<link rel="stylesheet" href="dist/ladda.min.css">
</head>
<body>
<div id="done"class="panel"style="z-index:9999">
<div class="content"style="width:100%;right:0;left:0;">
<br><center><div style="color:green;font-size:14px">
Selamat!! Akun anda telah aktif. Silahkan login dengan aplikasi yang terinstall di smartphone android anda</div><br><br>
</center>
</div>
</div>
<div id="login"class="panel"style="z-index:9999">
<div class="content"style="width:100%;right:0;left:0;">

<div class="w3-container w3-center w3-animate-top">
<center><h3 style="color:#801900">Medical Go</h3>
<img src="logobig.png"width="200px"/>
<br><br></div>

<style>
::-webkit-input-placeholder { /* WebKit, Blink, Edge */
    color:    #ada7a7;
}
:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
   color:    #ada7a7;
   opacity:  1;
}
::-moz-placeholder { /* Mozilla Firefox 19+ */
   color:    #ada7a7;
   opacity:  1;
}
:-ms-input-placeholder { /* Internet Explorer 10-11 */
   color:    #ada7a7;
}
::-ms-input-placeholder { /* Microsoft Edge */
   color:    #ada7a7;
}
#input {
	color: #fff;
    position: relative;
    display: inline-block;
	width:100%
}

nav {
	position: absolute;
	content: '';
	height: 40px;
	height: 2px;
    background: #b10505;
    transition: all 0.2s linear;
    width: 0;
    bottom: 1px;  
}

input:hover ~ nav {
	width: 100%;
}
</style>
<link rel="stylesheet" href="w3.css"><script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
<form id="form" method="post" style="width:100%">
<div id="input"><input style="color:#000;background: url(email.png) no-repeat 12px;
    padding-left: 40px;
    vertical-align: middle;
    border-bottom: 1px solid #ada7a7;
    background-size: 20px;" type='text'name="email"class='holo'placeholder="Email" aria-required="true" required="required"/>
<nav></nav></div>
<br><br>
<style>
.field-icon {
  float: right;
  margin-right: 8px;
  margin-top: -23px;
  position: relative;
  z-index: 2;
  cursor:pointer;
}
</style>
<div id="input"><input id="password" style="color:#000;background:url(password.png) no-repeat 12px;padding-left:40px;vertical-align:middle;border-bottom:1px solid #ada7a7;background-size:20px" type="password" name="pass"class='holo'placeholder="Password" aria-required="true" required="required"/>
<nav></nav></div><span style="color:grey" toggle="#toggle-password" id="eye" class="fa fa-lg fa-eye field-icon toggle-password"></span>
<br>
<script>
$(document).ready(function () {
        $("#eye").click(function () {
            if ($("#password").attr("type") === "password") {
                $("#password").attr("type", "text");
            } else {
                $("#password").attr("type", "password");
            }
        });
  });
</script>
<div style="float:right;padding:20px"><a href="loginregister/forgotPassword.php"style="color:#ada7a7" onclick="javascript:showDiv();"><small>Forgot password</small></a></div></p>
<br>
<section style="width:100%;padding:0"class="button-demo"><button style="background:#b10505;width: 90%;border-radius: 100px;height:auto"type="submit"name="btn-login"class="ladda-button"data-color="green"data-style="expand-right"><small>Sign In</small></button></section>
</form>
<div class="w3-container w3-center w3-animate-bottom">
<p><center>
<small><div style="color:#ada7a7;">Tidak memiliki Akun? <a style="color:#ada7a7" href="fdex.php#reg"> Daftar Sekarang</a>
</small></div></p>
</center>
<script src="dist/spin.min.js">
</script>
<script src="dist/ladda.min.js">
</script></section>
<script>Ladda.bind(".button-demo button");Ladda.bind(".progress-demo button",{callback:function(a){var c=0;var b=setInterval(function(){c=Math.min(c+Math.random()*0.1,1);a.setProgress(c);if(c===1){a.stop();clearInterval(b)}},200)}});
</script>
</div>
</div></div>
<div id="reg" class="panel"><div class="content" style="font-size:11px;padding:20px">
<h3>KEBIJAKAN PRIVASI</h3><br>
Kami di Aplikasi Medical GO menjaga privasi Anda dengan sangat serius. Kami percaya bahwa privasi elektronik sangat penting bagi keberhasilan berkelanjutan dari Internet. Kami percaya bahwa informasi ini hanya dan harus digunakan untuk membantu kami menyediakan layanan yang lebih baik. Itulah sebabnya kami telah menempatkan kebijakan untuk melindungi informasi pribadi Anda.
<br><br>
<h3>RINGKASAN KEBIJAKAN</h3>

Secara umum, Anda akan tetap sebagai anonim ketika Anda menggunakan Aplikasi web kami dan mengakses informasi. Sebelum kami meminta Anda untuk mengisi informasi, kami akan menjelaskan bagaimana informasi ini akan digunakan. Kami tidak akan memberikan informasi pribadi Anda kepada perusahaan lain atau individu tanpa se-izin Anda.

Beberapa bagian dari Aplikasi kami memerlukan pendaftaran untuk mengaksesnya, walaupun biasanya semua yang diminta adalah berupa alamat e-mail dan beberapa informasi dasar tentang Anda.

Ada bagian di mana kami akan meminta informasi tambahan. Kami melakukan ini untuk dapat lebih memahami kebutuhan Anda, dan memberikan Anda palayanan yang kami percaya mungkin berharga bagi Anda. Beberapa contoh informasi Aplikasi kami butuhkan seperti nama, email, alamat rumah, dan info pribadi. Kami memberikan Anda kesempatan untuk memilih untuk tidak menerima materi informasi dari kami.
<br><br>
<h3>PERLINDUNGAN PRIVASI</h3>

Kami akan mengambil langkah yang tepat untuk melindungi privasi Anda. Setiap kali Anda memberikan informasi yang sensitif (misalnya, nomor kartu kredit untuk melakukan pembelian), kami akan mengambil langkah-langkah yang wajar untuk melindungi, seperti enkripsi nomor kartu Anda. Kami juga akan mengambil langkah-langkah keamanan yang wajar untuk melindungi informasi pribadi Anda dalam penyimpanan. Nomor kartu kredit hanya digunakan untuk proses pembayaran dan bukan disimpan untuk tujuan pemasaran. Kami tidak akan memberikan informasi pribadi Anda kepada perusahaan lain atau individu tanpa izin Anda. "Proses order anda kami pastikan aman sebab dengan sistem pembayaran sewa langsung. pembayaran diterima oleh pemilik Mitra Kendaraan/property"
<br><br>
<h3>PENGGUNAAN COOKIE</h3>

Aplikasi ini menggunakan "cookies" untuk mengidentifikasi sesi pengguna pada Aplikasi dan dengan demikian menawarkan kontinuitas selama anggota bernavigasi di dalam Aplikasi. Cookie hanya digunakan pada Aplikasi untuk menyimpan data yang non-kritis. Cookies adalah potongan informasi dimana informasi tersebut ditransfer ke hard drive Smartphone Anda untuk tujuan menyimpan catatan.

Cookie memungkinkan Aplikasi web untuk menjaga informasi pengguna di seluruh koneksi. Cookie berupa string kecil berupa karakter yang digunakan oleh banyak Aplikasi untuk mengirimkan data ke Smartphone Anda, dan dalam keadaan tertentu, mengembalikan informasi ke Aplikasi web. Cookie hanya berisi informasi yang direlakan oleh anggota, dan mereka tidak memiliki kemampuan infiltrasi hard drive pengguna dan mencuri informasi pribadi. Fungsi sederhana cookie adalah membantu pengguna bernavigasi di Aplikasi dengan dengan kendala sesedikit mungkin.

Aplikasi Medical GO mungkin menggunakan perusahaan iklan luar untuk menampilkan iklan di Aplikasi kami. Iklan ini mungkin mengandung cookies, yang tampaknya datang dari Aplikasi web, tetapi pada kenyataannya mereka datang dari mitra kami yang melayani iklan di Aplikasi. Aplikasi tertentu dapat menempatkan "cookie" pada Smartphone Anda untuk memberikan layanan personalisasi dan / atau mempertahankan identitas Anda di beberapa halaman dalam satu sesi.
<br><br>
<h3>KEAMANAN</h3>

Aplikasi ini memiliki langkah-langkah keamanan untuk melindungi kehilangan, penyalahgunaan dan perubahan informasi di dalam kendali kita. Langkah-langkah ini meliputi metode perlindungan data dasar dan kompleks, penyimpanan informasi tertentu secara offline dan pengamanan server database kami. Aplikasi ini memberikan pilihan bagi para pengguna untuk menghapus informasi mereka dari database kami untuk tidak menerima informasi kedepannya atau untuk tidak lagi menerima layanan kami.
<br><br><p>
<center>
<a href="registrasiemail/index.php" onclick="javascript:showDiv();"><button style="width:200px;font-size:12px;height:auto;margin-top:-20px;padding-bottom:20px;"class="ladda-button"data-color="blue">Setuju & Lanjutkan</button></a>
</p><br><br></center>
</div></div>		
<div id="prosedur"class="panel"style="z-index:9999">
<div class="content"style="width:100%;right:0;left:0;">
<center><h3 style="color:#5792b5;font-size:16px">Prosedur pembayaran</h3>
<p><center>
<img src="prosedurpembayaran.png" width="90%"/></center></p>
<br><center><a href="#jogin"><img src="back.png" width="20px"/><b> Kembali</b></a></center><br><br>
</div>
</div>
</body>
<style>#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<div id="loading" style="display:none"></div>
<?php 
$id_users = $_SESSION['user'];
$view=mysql_query("SELECT * FROM transaksi where id_users='$id_users'");
while($row=mysql_fetch_array($view)){
	?><?php 
if($row['status_trans']=='otw')
      { ?><script>document.location.href=" about.php#otw";</script><?php }	   
if($row['status_trans']=='minta')
      { ?><script>document.location.href=" about.php#about";</script><?php }	   
if($row['status_trans']=='dijemput')
      {?><script>document.location.href=" about.php#row";</script><?php }	} ;
 ?>