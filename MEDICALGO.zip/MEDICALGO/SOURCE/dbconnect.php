<?php
error_reporting( E_ALL & ~E_DEPRECATED & ~E_NOTICE );

if(!mysql_connect("localhost","barisand_hospital","}c63AXvSHcrP"))
{
	die('oops connection problem ! --> '.mysql_error());
}
if(!mysql_select_db("barisand_hospital"))
{
	die('oops database selection problem ! --> '.mysql_error());
}
?>