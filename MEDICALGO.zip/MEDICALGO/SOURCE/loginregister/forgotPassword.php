<?php
session_start();
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" type="text/css" media="all" />
</head>
<body>
    	<div class="container">
		<h4>Enter the Email of Your Account to Reset New Password</h4>
        <?php echo !empty($statusMsg)?'<p class="'.$statusMsgType.'">'.$statusMsg.'</p>':''; ?>
		<div class="regisFrm">
			<form action="userAccount.php" method="post">
				<input type="email" name="email" placeholder="EMAIL" required="">
				<div class="send-button">
					<input type="submit" name="forgotSubmit" value="CONTINUE">
				</div>
			</form><br><br>
<center><a href="../fdex.php#login"style="color:orange">Kembali Login</a></center>
		</div>
	</div>
</body>
</html>