<?php
//including the database connection file
include("dbconnect.php");
//getting id of the data from url
$id = $_GET['id'];
//deleting the row from table
$res=mysql_query("SELECT * FROM users WHERE id='$id'");
$rows=mysql_fetch_array($res);
$gaigi=$rows['id'];
$pointawal=$rows['point'];
$koint=$pointawal-10;
$result = mysql_query("UPDATE users set point='$koint', promohabis='-' where id='$gaigi'");
//redirecting to the display page (index.php in our case)
header("Location:about.php#about");
?>

