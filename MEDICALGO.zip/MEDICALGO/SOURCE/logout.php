<?php
session_start();
include "dbconnect.php";  
$id_users=$_SESSION['user'];

//** jika ingin delete otomatis transaksi setelah selesai
//** $query=mysql_query("delete from transaksi where id_users='$id_users'");

if(!isset($_SESSION['user']))
{
	header("Location: fdex.php#login");
}
else if(isset($_SESSION['user'])!="")
{
	header("Location: fdex.php#login");
}

if(isset($_GET['logout']))
{

	session_destroy();
	unset($_SESSION['user']);
	header("Location: fdex.php#login");
}
?>