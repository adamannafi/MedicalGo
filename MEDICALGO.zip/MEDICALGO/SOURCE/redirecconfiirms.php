<?php
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['user']))
{
	header("Location: fdex.php#jogin");
}
$invoice = $_GET["INV"];
$result = mysql_query("SELECT * FROM transaksi WHERE id_users='" . $_SESSION["user"] . "' and status_trans='dijemput'");
$row= mysql_fetch_array($result);
if(count($_POST)>0) {
mysql_query("UPDATE transaksi set status_trans='otw' WHERE id_users='" . $_SESSION["user"] . "' and status_trans='dijemput'");
$message = "Record Modified Successfully";
}
?><head><meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"type="text/css"href="demo.css"/></head><body onkeydown="javascript:if(window.event.keyCode == 13) window.event.keyCode = 9;"><!--sodrops top bar--><div class="sodrops-top"><span class="actions"><ul><li><a href="javascript:history.go(0)"><img src="refresh.png"width="25px"/></a></li></ul></span><div style="margin-left:20px;margin-top:13px;font-size:18px;font-weight:bold">Konfirmasikan</div></div>
<div style="padding:45px;z-index:999;position:absolute;color:#565656;font-size:14px;">
<form name="frmUser"method="post"action="<?php echo $_SERVER['PHP_SELF']?>"><br><br>
<p>
<center><img src="konfirm.jpg"width="350px;"/></p>
<input type="hidden"name="status_trans" value="otw">
<input type="hidden"name="invoice" value="<?php echo $invoice; ?>">
<p><button style="border:1px solid green;padding:4px;color:green;font-size:18px;"type="submit"name="submit"class="btnSubmit"> Konfirmasi</button></p>
</center></form></div>
<?php 
$id_users = $_SESSION['user'];
$view=mysql_query("SELECT * FROM transaksi where id_users='$id_users'");
while($row=mysql_fetch_array($view)){
	?>
<!-------------------><?php 
 if($row['status_trans']=='otw')
      { ?>
<script>document.location.href="about.php#otw";</script>

<?php }	
if($row['status_trans']=='minta')
      { ?>
<script>document.location.href="about.php#about";</script>
	  <?php } }; ?></body>