<?php
session_start();
include_once 'dbconnect.php';

if(isset($_SESSION['user'])!="")
{
	?><script>document.location.href="home.php#home";</script><?php
}

if(isset($_POST['btn-signup']))
{
	$uname = mysql_real_escape_string($_POST['uname']);
	$email = mysql_real_escape_string($_POST['email']);
	$upass = mysql_real_escape_string($_POST['pass']);
	$phone = mysql_real_escape_string($_POST['phone']);
	
	$uname = trim($uname);
	$email = trim($email);
	$upass = trim($upass);
	
	// email exist or not
	$query = "SELECT email FROM users WHERE email='$email'";
	$result = mysql_query($query);
	
	$count = mysql_num_rows($result); // if email not found then register
	
	if($count == 0){
		
		if(mysql_query("INSERT INTO users(first_name,email,password,phone, lat, lng) VALUES('$uname','$email','$upass','$phone','$lat','$lng')"))
		{
			?><div style="color: #329600;
    position: fixed;
    z-index: 99999;
top: 80px;
    left: 55px;
    padding: 20px;box-shadow: 5px 2px 8px 1px rgba(0,0,0,0.15);
    background-color: yellow;">Pendaftaran Berhasil,Silahkan Login</div><?php
		}
		else
		{
			?><div style="color: #329600;
    position: fixed;
    z-index: 99999;
top: 80px;
    left: 55px;
    padding: 20px;
	box-shadow: 5px 2px 8px 1px rgba(0,0,0,0.15);
    background-color: yellow;">Server Sibuk,Coba Ulangi</div><?php
		}		
	}
	else{
			?><div style="color: #329600;
    position: fixed;
    z-index: 99999;
top: 80px;
    left: 55px;
    padding: 20px;
	box-shadow: 5px 2px 8px 1px rgba(0,0,0,0.15);
    background-color: yellow;">Email/ID sudah dimiliki oranglain</div><?php
	}
	
}
?><head><meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0"><link rel="stylesheet"type="text/css"href="demo.css"/>
<link rel="stylesheet" href="css/bemo.css">
<link rel="stylesheet" href="dist/ladda.min.css">
</head><body onkeydown="javascript:if(window.event.keyCode == 13) window.event.keyCode = 9;">
<div id="oke"class="panel"><div class="content">
<br><center><h3 style="color:#a24106;">Daftar Member</h3><p><div style="color: #666a78;">Sudah pernah daftar?<a href="fdex.php#login">Login</a></div></p><form method="post"><input type='text'name="uname"class='holo'placeholder="Username"required="required"/><br><input type='text'name="email"class='holo'placeholder="Email"required="required"/><br><input type='text'name="pass"class='holo'placeholder="Password"required="required"/><br><input type='text'name="phone"class='holo'placeholder="Nomor Handphone"required="required"/><br><br><div class="round-button">
<section class="button-demo">
<button style="width:200px;height:auto"type="submit"name="btn-signup"class="ladda-button" data-color="green" data-style="expand-right">Next</button>
</section><script src="dist/spin.min.js"></script>
		<script src="dist/ladda.min.js"></script>

		<script>
			// Bind normal buttons
			Ladda.bind( '.button-demo button' );
			Ladda.bind( '.progress-demo button', {
				callback: function( instance ) {
					var progress = 0;
					var interval = setInterval( function() {
						progress = Math.min( progress + Math.random() * 0.1, 1 );
						instance.setProgress( progress );
						if( progress === 1 ) {
							instance.stop();
							clearInterval( interval );
						}
					}, 200 );
				}
			} );
		</script>
		</div></form></center></div></div>
		
		</body>