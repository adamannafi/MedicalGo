<?php
//including the database connection file
include("dbconnect.php");
//getting id_trans of the data from url
$id_trans = $_GET['id_trans'];
//deleting the row from table
$res=mysql_query("SELECT * FROM transaksi WHERE id_trans='$id_trans'");
$rows=mysql_fetch_array($res);
$id=$rows['id_users'];
$mes=mysql_query("SELECT * FROM users WHERE id='$id'");
$jows=mysql_fetch_array($mes);
$pointawal=$jows['point'];
$koint=$pointawal-10;
$result = mysql_query("UPDATE transaksi set tipebayar='cash', status_trans='otw' where id_trans='$id_trans'");
//redirecting to the display page (index.php in our case)
header("Location:about.php#about");
?>

