<?php
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['user']))
{
	header("Location: home.php#home");
}
$res=mysql_query("SELECT * FROM users WHERE id=".$_SESSION['user']);
$rows=mysql_fetch_array($res);
?>
<head><meta charset="UTF-8"/>
<meta http-equiv="refresh" content="30"><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0"><link rel="stylesheet"type="text/css"href="demo.css"/>
<link rel="stylesheet" href="css/bemo.css">
<link rel="stylesheet" href="dist/ladda.min.css">
</head><body onkeydown="javascript:if(window.event.keyCode==13)window.event.keyCode=9">
<div class="sodrops-top"><span class="actions"><ul>
<li><a href="javascript:history.go(0)" onclick="javascript:showDiv();"><img src="refresh.png"width="25px"/></a></li><li><a onclick="javascript:showDiv();" href="home.php#home"><img src="home.png"width="25px"/></a></li>
</ul></span><div style="color:#fff;margin-left:20px;font-size:18px;font-weight:bold;margin-top:5;">
Invoice
</div></div><br>
<?php 
$id_users = $_SESSION['user'];
$view=mysql_query("SELECT * FROM transaksi INNER JOIN mitra ON transaksi.id_mitra= mitra.id_mitra where transaksi.id_users='$id_users' and transaksi.status_trans='dijemput'");
while($row=mysql_fetch_array($view)){
$price= $row['price'];
$latmitra= $row['latmitra'];
$lngmitra= $row['lngmitra'];
	?>
	<?php
if($row['status_trans']=='otw')
      {?>
<script>document.location.href="otw.php";</script><?php }?>
	<?php 
 if($row['status_trans']=='dijemput')
      { ?><br><br><br><br>
  <table id="iseqchart"><tr><th id="index"><center>Profil Medis </center></th></tr><tr style="border-top:1px solid #999"><td><center><div style="font-size:12px"><b>
<?php echo $row['nama_mitra']; ?></b></div><br>
<?php
if($row['foto_mitra']=='0'){
	?>
<img src="profile.png"style="width:80px;border-radius:50%;border:2px solid grey;"/>
	  <?php } else {?>
<img src="foto_mitra/<?php echo $row['foto_mitra'];?>"style="width:80px;border-radius:50%;border:2px solid grey;"/>
	<?php }
	?>
<br>
<table style="width:100%">
<tr style="font-size:12px;color:#565656"><td>Pria/wanita</td><td>:</td><td width="50%"> <?php echo $row["kelamin"]; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Phone</td><td>:</td><td width="50%"> <?php echo $row['nomorhp']; ?></td></tr>
<tr style="font-size:12px;color:#565656"><td>Sebagai</td><td>:</td><td width="50%"> <?php echo $row["sebagai"]; ?></td></tr></table></td></tr></table>

<section class="button-demo" style="padding:0;width:100%">
<a href="bayarin.php?id_trans=<?php echo $row['id_trans']; ?>" onclick="javascript:showDiv();"><button style="width:100%" class="ladda-button" data-color="green" data-style="expand-right">
<small>Pembayaran transfer<br>Rp.
<?php 
$jumlah = $row['harga'];
$penjumlahan = $jumlah;
$subtotal = number_format($penjumlahan,0,",",".");
echo $subtotal;?>,- </small></button></a></center>
</section><?php
 $date_now = date("d-m-Y"); // this format is string comparable
 $jatuhtempo=$rows['promohabis'];
if ($date_now > $jatuhtempo) { ?>
<?php
 $point=$rows['point'];
if ($point >= '10') { ?>
<script>document.location.href="cancelpoint.php?id=<?php echo $rows['id'];?>";</script>
<?php } else {?>
 <?php  } ?>
  <?php  }else{ ?>
<section class="button-demo" style="padding:0;width:100%">
<a href="bayarpoint.php?id_trans=<?php echo $row['id_trans']; ?>" onclick="javascript:showDiv();"><button style="width:100%" class="ladda-button" data-color="blue" data-style="expand-right">
<small>Bayar dengan Point <br>
10 Point </small></button></a></center>
</section>
  <?php  } ?>
<section class="button-demo" style="padding:0;width:100%">
<a href="bayarcash.php?id_trans=<?php echo $row['id_trans']; ?>" onclick="javascript:showDiv();"><button style="width:100%" class="ladda-button" data-color="orange" data-style="expand-right">
<small>Bayar Cash Nanti</small><br>
<small style="font-size:9px">(Pembayaran langsung setelah Medis melayani)</small></button></a></center>
</section>
<div style="color:#444;background-color:#fff;padding:20px;width:100%;">
<br><center><b style="color:green">Invoice Layanan <?php echo $row["layanan"]; ?></b></center>
<b><small>Kode Invoice:</small></b><br/><?php echo $row["invoice"]; ?></br></br>
<b><small>Tanggal Request:</small></b><br/><?php echo $row['tanggal']; ?></br></br>
<b><small>Jenis Layanan:</small></b><br/><?php echo $row['layanan']; ?></br></br>
<b><small>Keterangan Keluhan:</small></b><br/><?php echo $row['keterangan']; ?></br></br>
<b><small>Atas Nama:</small></b><br/><?php echo $row['nama_rumah']; ?></br></br>
<b><small>No. Handphone:</small></b><br/><?php echo $row['nomor']; ?></br></br>
<b><small>Alamat Tujuan:</small></b><br/><?php echo $row['alamat']; ?></br></br>
<b><small>Harga Layanan:</small></b><br/>Rp. <?php $awal = $row['awal'];$kapi = number_format($awal,0,",",".");echo $kapi; ?></br></br>
<b><small>Tarif transport:</small></b><br/>Rp. <?php $transport = $row['transport'];$porti = number_format($transport,0,",",".");echo $porti; ?></br></br>

<center>
<a href="cancel.php?id_trans=<?php echo $row['id_trans']; ?>" onClick="return confirm('Yakin membatalkan request?')">
<button style="width:100%;font-size:15px;height:auto;margin-top:0px;padding-bottom:20px;"class="ladda-button"data-color="red">Cancel</button>
</a>
</center>
<br><br>
<iframe width="100%"height="250"frameborder="0"scrolling="yes"marginheight="0"marginwidth="0"src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=<?php echo $row['latmitra']?>,<?php echo $row['lngmitra']?> (custom heading)&amp;output=embed"></iframe></p>
<script src="dist/spin.min.js"></script>
</div>
<?php } }?>
<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.6.1.min.js"></script>		
<script type="text/javascript" src="autosave5/jquery-1.6.1.js"></script>		
	<script type="text/javascript">
	$(document).ready(function(){	
	
		autosave();
	});
	
	function autosave()
	{
		
		var t = setTimeout("autosave()", 5000);
		$('#timestamp').show(50).delay(8000);	
		var id = $("#id").val();
		var lat = $("#lat").val();
		var lng = $("#lng").val();
		
		if (lat.length > 0 || lng.length > 0)
		{
			$.ajax(
			{
				type: "POST",
				url: "autosave.php",
				data: "&id=" + id + "&lat=" + lat + "&lng=" + lng,
				cache: false,
				success: function(message)
				{	
					$('#timestamp').hide(50).delay(3000);
					$("#timestamp").empty().append(message);
				}
			});
		}
	} 
	</script>	
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=true"></script><br><br><br>
<script>if(!navigator.geolocation){alert("Your phone does not support maps Location.")}navigator.geolocation.getCurrentPosition(success,error);function success(c){var b=c.coords.latitude;var d=c.coords.longitude;var a=c.coords.accuracy;document.getElementById("lat").value=b;document.getElementById("lng").value=d}function error(a){}</script>
<form id="article_form" method="post" action="autosave.php">
<input type="hidden" id="id" name="id" value="<?php echo $rows['id_mitra'];?>" />
<input type="hidden" id="lat" type="float" name="lat"/>
<input type="hidden" id="lng" type="float" name="lng"/>
</form><br>
<style>#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<div id="loading" style="display:none">
</div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>
</body>