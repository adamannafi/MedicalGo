<body style="font-family:Segoe UI"><?php
//variabel database
$nama_host="localhost";
$user_db="mypass_app";
$password_db="V_msSxWdc21b";
$nama_db="mypass_app";
$entries=3;
//koneksi database
$koneksi=mysql_connect($nama_host,$user_db,$password_db);

mysql_select_db($nama_db,$koneksi);

date_default_timezone_set('Asia/Jakarta');
$tanggal=date("Y-m-d H:i:s");
//bila terkoneksi
if($koneksi){
//pilih database
mysql_select_db($nama_db);
}else{
echo "Database tidak terkoneksi";
}

?>
<?php
$kodetrans= $_POST['kodetrans']; 
$q = "SELECT * from transaksi INNER JOIN mitra ON transaksi.id_mitra= mitra.id_mitra where kodetrans like '%$kodetrans%'"; 
$result = mysql_query($q); //execute the query $q
echo "<center>";
echo "<b>Cek Status Layanan</b><br>";
echo "<table border='1' cellpadding='5'>";
echo "

<tr bgcolor='orange'>
		<td>Tanggal</td>
		<td>Nama Pelanggan</td>
		<td>Layanan</td>
		<td>Mobil</td>
		<td>Waktu kunjungan</td>
		<td>Kode transaksi</td>
		<td>Invoice Doku</td>
		<td>Ponsel Pasien</td>
		<td>Alamat</td>
		<td>Biaya</td>
		<td>Status Layanan</td>
	
	</tr>
";
while ($data = mysql_fetch_array($result)) {  
echo "
<tr>
<td>".$data['tanggal']."</td>
<td>".$data['nama_rumah']."</td>
<td>".$data['layanan']."</td>
<td>".$data['kendaraan']."</td>
<td>".$data['keterangan']."</td>
<td>".$data['kodetrans']."</td>
<td>".$data['invoice']."</td>
<td>".$data['nomor']."</td>
<td>".$data['alamat']."</td>
<td> Rp. ".$data['harga']."</td>
<td>".$data['status_trans']."</td>
</tr>";
?>
<tr><td colspan=11>Deskripsi Layanan:<br><?php echo $data['deskripsi'];?><br>
<center><label style="color:grey">Lacak Lokasi Mitra</label></center><iframe width="100%"height="250"frameborder="0"scrolling="yes"marginheight="0"marginwidth="0"src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=<?php echo $data['latmitra']?>,<?php echo $data['lngmitra']?> (custom heading)&amp;output=embed"></iframe>
</td></tr></table>
<?php } ?></body>