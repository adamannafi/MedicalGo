<?php
$res=mysql_query("SELECT * FROM users WHERE id=".$_SESSION['user']);
$rows=mysql_fetch_array($res);
if(!mysql_connect("localhost","barisand_hospital","}c63AXvSHcrP"))
{
	die('oops connection problem ! --> '.mysql_error());
}
if(!mysql_select_db("barisand_hospital"))
{
	die('oops database selection problem ! --> '.mysql_error());
}
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: fdex.php#login");
}
$id=$_SESSION['user'];
$TokenCek = mysql_query("select * from users where id='$id'");
$lat = mysql_real_escape_string($_POST['lat']);
$lng = mysql_real_escape_string($_POST['lng']);
$id = (int)$_POST['id'];
//save contents to database
mysql_query("update users set lat='$lat',lng='$lng' where id='$id'");
//get timestamp
//output timestamp
echo 'Last Saved bro '
?>