<?php
include_once("dbconnect.php");
if(isset($_POST['kirim'])){
	if (empty($_POST['password'])) {
   ?>
<script>window.alert("Error... anda belum mengisi kolom password");document.location.href="about.php#open";</script><?php
  return false;
}
	$id =$_POST['id'];
	$first_name =$_POST['first_name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$password = $_POST['password'];
	$password = md5($password);
	$query=mysql_query("update users set first_name='$first_name',email='$email',password='$password',phone='$phone' where id='$id'");
	if($query){
		?>
		<script>document.location.href="about.php#open";</script>
		<?php
	

}}
?>