<?php
$session_lifetime = 3600 * 24 * 860; // 2 days
session_set_cookie_params ($session_lifetime);
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['user']))
{
	header("Location: fdex.php#login");
}
$res=mysql_query("SELECT * FROM users WHERE id=".$_SESSION['user']);
$rows=mysql_fetch_array($res);
?>
<?php
$jiew=mysql_query("SELECT * FROM transaksi where id_users=".$_SESSION['user']);
$jow=mysql_fetch_array($jiew);
	?>
	<?php 
 if($jow['status_trans']=='minta')
      { ?>
<script>document.location.href="about.php#row";</script><?php }
?>
<?php 
 if($jow['status_trans']=='dijemput')
      { ?>
<script>document.location.href="about.php#row";</script><?php }
?>
<?php
if($jow['status_trans']=='otw')
      {?>
<script>document.location.href="about.php#otw";</script><?php }?>
<?php
if(isset($_POST['tambah'])){
	if (empty($_POST['lat'])) {
   ?>
<script>window.alert("GPS anda tidak terdeteksi, nyalakan GPS!");window.history.back(-3);</script><?php
  return false;
}
if (empty($_POST['alamat'])) {
   ?>
<script>window.alert("Isi kolom alamat!");window.history.back(-3);</script><?php
  return false;
}if (empty($_POST['keterangan'])) {
   ?>
<script>window.alert("Error... anda belum mengisi keluhan");window.history.back(-3);</script><?php
  return false;
}
$tanggal= $_POST['tanggal'];
$id_users= $_POST['id_users'];
$id_mitra= $_POST['id_mitra'];
$nama_rumah= $_POST['nama_rumah'];
$keterangan	= $_POST['keterangan'];
$lat= $_POST['lat'];
$lng= $_POST['lng'];
$timepicker1= $_POST['timepicker1'];
$harga= $_POST['harga'];
$status_trans= $_POST['status_trans'];
$aktif= $_POST['aktif'];
$nomor= $_POST['nomor'];
$mitra_attach= $_POST['mitra_attach'];
$alamat= $_POST['alamat'];
$online= $_POST['online'];
$layanan= $_POST['layanan'];
$deskripsi= $_POST['deskripsi'];
$invoice= str_replace(' ', '', stripslashes($_POST["invoice"]));
$foto_ktp= $_POST['foto_ktp'];
$tgl_boking= $_POST['tgl_boking'];
$per= $_POST['per'];
$tipebayar= $_POST['tipebayar'];
$testimoni= $_POST['testimoni'];
$timestart= $_POST['timestart'];
$timeend= $_POST['timeend'];
$awal= $_POST['awal'];
$transport= $_POST['transport'];
$input = "SELECT id_users FROM transaksi WHERE id_users='$id_users' and status_trans='minta'";
$result = mysql_query($input);
$count = mysql_num_rows($result); // if email not found then register
if($count == 0){
	if(mysql_query("INSERT INTO `transaksi` (`id_trans`, `tanggal`, `id_users`, `id_mitra`, `nama_rumah`, `keterangan`, `lat`, `lng`, `timepicker1`, `harga`, `status_trans`, `aktif`, `nomor`, `mitra_attach`, `alamat`, `online`, `layanan`, `deskripsi`, `invoice`, `foto_ktp`, `tgl_boking`, `per`, `tipebayar`, `testimoni`, `timestart`, `timeend`, `awal`, `transport`) VALUES (NULL, '$tanggal', '$id_users', '0', '$nama_rumah', '$keterangan', '$lat', '$lng', '$timepicker1', '$harga', 'minta', 'yes', '$nomor', '$mitra_attach', '$alamat', 'unread', '$layanan', '$deskripsi', '$invoice', '0', '$tgl_boking', '$per', '$tipebayar', '$testimoni', '$timestart', '$timeend', '$awal', '$transport');"))
			{
			?>
<script>document.location.href="about.php#about";</script><?php
		}
		else
		{
			?>
<?php
		}		
	}
	else{
			?>
<?php
	}
	
}
	
?>
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link href="css/timepicki.css"rel="stylesheet">
<link rel="stylesheet"href="themes/base/jquery.ui.all.css">
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="jquery.ui.addresspicker.js"></script>
<link rel="stylesheet"type="text/css"href="demo.css"/>
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:#000;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:-50px;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#cari{display:none}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<link rel="stylesheet"href="css/bemo.css">
<link rel="stylesheet"href="dist/ladda.min.css">
</head>
<body onload="getLocation()" onkeydown="javascript:if(window.event.keyCode==13)window.event.keyCode=9">
<div class="sodrops-top">
<span class="actions" style="margin-top: 10px;float:left">
<ul>
<li><a href="home.php#home" onclick="javascript:showDiv();"><img src="back.png"width="25px" onclick="javascript:showDiv();"/></i></a></li>
</ul>
</span>
<div style="margin-top:15px;margin-left:-40px;font-size:18px;font-family:Segoe UI light">
<center><img style="margin-left: -75px;" src="logo.png"width="60px"/></center>
</div>
</div><br><br><br>

<div style="color:#000;"><br><br>
<form id="form"action="<?php echo $_SERVER['PHP_SELF']?>" method="post"><center><small> <br>Tentukan Lokasi anda untuk <?php echo $_POST["layanan"]; ?></small></center><br>
<div id="mapholder"></div>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=true"></script>
<script type="text/javascript"src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAO4lbxY6SKygcJxTuzu-Qi7kAAP9SdAwM&callback=initMap"></script>
<script>var x=document.getElementById("demo");function getLocation(){if(navigator.geolocation){navigator.geolocation.getCurrentPosition(showPosition,showError)}else{x.innerHTML="Geolocation is not supported by this browser."}}function showPosition(a){lat=a.coords.latitude;lon=a.coords.longitude;document.getElementById("lat").value=lat;document.getElementById("lng").value=lon;latlon=new google.maps.LatLng(lat,lon);mapholder=document.getElementById("mapholder");mapholder.style.height="350px";mapholder.style.width="100%";var c={center:latlon,zoom:14,mapTypeId:google.maps.MapTypeId.ROADMAP,mapTypeControl:false,navigationControlOptions:{style:google.maps.NavigationControlStyle.SMALL}};var d=new google.maps.Map(document.getElementById("mapholder"),c);var b=new google.maps.Marker({position:latlon,map:d,title:"You are here!",draggable:true});google.maps.event.addListener(b,"dragend",setCoordinates)}function setCoordinates(a){document.getElementById("lat").value=a.latLng.lat();document.getElementById("lng").value=a.latLng.lng()}function showError(a){switch(a.code){case a.PERMISSION_DENIED:x.innerHTML="User denied the request for Geolocation.";break;case a.POSITION_UNAVAILABLE:x.innerHTML="Location information is unavailable.";break;case a.TIMEOUT:x.innerHTML="The request to get user location timed out.";break;case a.UNKNOWN_ERROR:x.innerHTML="An unknown error occurred.";break}}</script>
<input type="hidden"name="lat"id="lat"/>
<input type="hidden" name="nomor"value="<?php echo $rows['phone']; ?>"/>
<input type="hidden"name="lng"id="lng"/>
<div style="padding:15px;">
<label><small>Tambahan Alamat Lengkap</small></label>
<div class="demo"><div class='input'>
<input id="addresspicker"type="text"name="alamat"placeholder="Ketik Nama Jalan, Kota, Nomor rumah"required="required"/>
</div></div>
<br>
<p style="color:#565656">
<script>$(function(){var a=$("#addresspicker").addresspicker({componentsFilter:"country:ID"})});</script>
<div id="input" style="font-size:12px">Tentukan Jam kunjungan
<div class="inner cover indexpicker">
<input id="timepicker1"type="text"placeholder="Pilih Jam kunjungan"name="timepicker1"required="required"/></div>
<script src="js/timepicki.js"></script>
<script>$("#timepicker1").timepicki();</script></div><br>
</p>
<div id="input" style="font-size:12px">Tuliskan Keluhan anda :<br>
<textarea style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" type='text'name="keterangan"class='holo' aria-required="true" required="required"/>
</textarea></div>
<br><br>
</div><br><br><br><br><br><br>
<table width="100%" style="width:100%;z-index:9999;bottom:0;position:fixed;background-color:#5cb55c;box-shadow: 0 2px 5px rgba(0,0,0,.26);"><tr>
<td style="font-size:11px;padding:20px;color:#fff"width="50%"><b style="font-size:11px;color:#000">Total Harga</b>
<p style="color:#fff;font-size:11px;">
IDR <?php 
$harian = $_POST["harga"];
$harga_five = number_format($harian,0,",",".");
echo $harga_five;?> <br>(per <?php echo $_POST["per"]; ?> Jam)
</p>

</td>

<input type="hidden" name="nama_rumah"type="text" value="<?php echo $_POST["nama_rumah"]; ?>"/>
<input type="hidden" name="nomor"type="text" value="<?php echo $_POST["nomor"]; ?>"/>
<input type="hidden" name="id_users"type="text" value="<?php echo $_POST["id_users"]; ?>"/>
<input type="hidden" name="status_trans"type="text" value="minta"/>
<input type="hidden" name="online"type="text" value="unread"/>
<input type="hidden" name="tanggal"value="<?php date_default_timezone_set("Asia/Jakarta");  echo date('Y-m-d h:i:s'); ?>"/>
<input type="hidden" name="layanan"value="<?php echo $_POST["layanan"]; ?>"/>
<input type="hidden" name="per"value="<?php echo $_POST["per"]; ?>"/>
<input type="hidden" name="harga"value="<?php echo $_POST["harga"]; ?>"/>
<input type="hidden" name="awal"value="<?php echo $_POST["harga"]; ?>"/>
<input type="hidden" name="id_mitra"value="0"/>
<input type="hidden" name="invoice"value="<?php echo $_POST["invoice"]; ?>"/>
<input type="hidden" name="aktif"value="yes"/>
<input type="hidden" name="tipebayar"value="0"/>
<input type="hidden" name="testimoni"value="0"/>
<input type="hidden" name="timestart"value="0"/>
<input type="hidden" name="timeend"value="0"/>

<td style="font-size:15px;padding:20px;color:#fff;"width="50%">
<center>
<button type="submit"name="tambah" style="font-weight:bold;color:#fff;background:none;border:none" onclick="javascript:showDiv();">Lanjutkan</button>
</center></div>
</form>
</div>
</td>
</tr>
</table>
<script>
$("#bed").change(function(){var a=$(this).val();if(a=="single"){$("#single").val("").show()}else{$("#bed").hide();$("#single").remove()}});
$("#bed").change(function(){var a=$(this).val();if(a=="double"){$("#double").val("").show()}else{$("#bed").hide();$("#double").remove()}});</script>
<div id="loading" style="display:none">
</div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>
</body>