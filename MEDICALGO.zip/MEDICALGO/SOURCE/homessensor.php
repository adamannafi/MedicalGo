<?php
$session_lifetime = 3600 * 24 * 860; // 2 days
session_set_cookie_params ($session_lifetime);
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['user']))
{
	header("Location: fdex.php#login");
}
$res=mysql_query("SELECT * FROM users WHERE id=".$_SESSION['user']);
$rows=mysql_fetch_array($res);
?>
<?php
$jiew=mysql_query("SELECT * FROM transaksi where id_users='".$_SESSION['user']."' and aktif='yes'");
$jow=mysql_fetch_array($jiew);
	?>
	<?php 
 if($jow['status_trans']=='minta')
      { ?>
<script>document.location.href="about.php#row";</script><?php }
?>
<?php 
 if($jow['status_trans']=='dijemput')
      { ?>
<script>document.location.href="about.php#row";</script><?php }
?>
<?php
if($jow['status_trans']=='otw')
      {?>
<script>document.location.href="about.php#otw";</script><?php }?>
<?php 
 if($jow['status_trans']=='ttd')
      { ?>
<script>document.location.href="home.php#ttd";</script><?php }
?>

<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link href="css/timepicki.css"rel="stylesheet">
<link rel="stylesheet"href="themes/base/jquery.ui.all.css">
<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="jquery.ui.addresspicker.js"></script>
<link rel="stylesheet"type="text/css"href="demo.css"/>
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:#000;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:-50px;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#cari{display:none}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<link rel="stylesheet"href="css/bemo.css">
<link rel="stylesheet"href="dist/ladda.min.css">
<style>
.modalDialog {
    position: fixed;
    font-family: Arial, Helvetica, sans-serif;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.8);
    z-index: 99999;
    opacity:0;
    -webkit-transition: opacity 400ms ease-in;
    -moz-transition: opacity 400ms ease-in;
    transition: opacity 400ms ease-in;
    pointer-events: none;
}
.modalDialog:target {
    opacity:1;
    pointer-events: auto;
    overflow: scroll;
}
.modalDialog > div {
    width: 90%;
    position: relative;
    margin: 10% auto;
    padding: 5px 20px 13px 20px;
    border-radius: 10px;
    background: #fff;
}
.close {
    background: #606061;
    color: #FFFFFF;
    line-height: 25px;
    position: absolute;
    right: -12px;
    text-align: center;
    top: -10px;
    width: 24px;
    text-decoration: none;
    font-weight: bold;
    -webkit-border-radius: 12px;
    -moz-border-radius: 12px;
    border-radius: 12px;
    -moz-box-shadow: 1px 1px 3px #000;
    -webkit-box-shadow: 1px 1px 3px #000;
    box-shadow: 1px 1px 3px #000;
}
.close:hover {
    background: #00d9ff;
}
</style>
</head>
<body  >
<div class="sodrops-top">
<span class="actions" style="margin-top: 10px;float:left">
<ul>
<li><a href="home.php#home" onclick="javascript:showDiv();"><img src="back.png"width="25px" onclick="javascript:showDiv();"/></i></a></li>
</ul>
</span>
<div style="margin-top:15px;margin-left:-40px;font-size:18px;font-family:Segoe UI light">
<center><img style="margin-left: -75px;" src="logo.png"width="60px"/></center>
</div>
</div><br><br><br>
<?php 
$id_layanan = $_GET['id_layanan'];
$view=mysql_query("SELECT * FROM layanan where id_layanan='$id_layanan'");
while($row=mysql_fetch_array($view)){
?><br><br><center style="color:#444">Lokasi semua Medis <?php echo $row['nama_layanan'];?></center>
<?php
include_once("dbconnect.php");
?>
    <style>
      #map-canvas {
        width: 100%;
        height: 200px;
      }
    </style>
  <script type="text/javascript" src="//maps.google.com/maps/api/js?sensor=true"></script><script type="text/javascript"src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAO4lbxY6SKygcJxTuzu-Qi7kAAP9SdAwM&callback=initMap"></script> <script>
    var marker;
      function initialize() {
        var mapCanvas = document.getElementById('map-canvas');
        var mapOptions = {
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }     
        var map = new google.maps.Map(mapCanvas, mapOptions);
        var infoWindow = new google.maps.InfoWindow;      
        var bounds = new google.maps.LatLngBounds();
        function bindInfoWindow(marker, map, infoWindow, html) {
          google.maps.event.addListener(marker, 'click', function() {
            infoWindow.setContent(html);
            infoWindow.open(map, marker);
          });
        }
 
function addMarker(lat, lng, info) {
            var pt = new google.maps.LatLng(lat, lng);
            bounds.extend(pt);
var iconBase = 'http://hospital.barisandata.com/terapis.png';
            var marker = new google.maps.Marker({
				icon: iconBase,
                map: map,
                position: pt
            });       
            map.fitBounds(bounds);
            bindInfoWindow(marker, map, infoWindow, info);
          }
          <?php		  
            $query = mysql_query("SELECT * FROM mitra");
          while ($data = mysql_fetch_array($query)) {
            $lat = $data['latmitra'];
            $lng = $data['lngmitra'];
			$nama_mitra = $data['nama_mitra'];
            echo ("addMarker($lat, $lng, '<a style=font-size:12px;color:#000>$nama_mitra</a>');\n");                        
          }
          ?>
        }
      google.maps.event.addDomListener(window, 'load', initialize);
    </script>
    <div id="map-canvas"></div> 

<table style="background-color: #f5fcff;"id="iseqchart">
<tr style="font-size:10px;border-top:1px solid #14a8e0">

<td width="20%">
<?php
 if($row['picture']=='0')
      { ?>
<img src="nopic.png" style="width:100px;top:0;"/>
<?php }
 if($row['picture']=='')
      { ?>
<img src="nopic.png" style="width:100px;top:0;"/>
<?php }
else{?>
<img src="fotobarang/<?php echo $row['picture'];?>" style="width:100px;top:0;"/>
<?php } ?></td>

<td width="40%"style="padding:10px">
<b><small><?php echo $row['nama_layanan'];?>
</small></b><br><?php echo $row['keterangan_layanan'];?>
</td>
<td width="40%"style="padding:10px">
Harga Layanan:<br>
<b><small>IDR 
<?php 
$layanan = $row['khusus'];
$harga = number_format($layanan,0,",",".");
echo $harga;?>
</small></b><br>per <?php echo $row['per'];?>
</td>
</tr>
</table>

<div style="color:#000;padding:20px">
<form id="form"action="homer.php" method="post">
<p style="color:#565656">
<label>Informasi anda</label><br>
<div id="input" style="font-size:12px">Nama Lengkap:<br>
<input style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" placeholder="Your Name" type='text'name="nama_rumah"class='holo'value="<?php echo $rows['first_name']; ?>" aria-required="true" required="required"/>
<nav></nav></div><br><br>
<div id="input" style="font-size:12px">Nomor Telepon :<br>
<input id="addresspicker" style="color:#000;padding:5px;
    vertical-align: middle;
    border-bottom: 1px solid grey;
    background-size: 20px;" placeholder="Your phone number" type='text'name="nomor"class='holo'value="<?php echo $rows['phone']; ?>" aria-required="true" required="required"/>
<nav></nav></div><br><br>
<br><br>
</p></div>
<input type="hidden" name="id_users"type="text" value="<?php echo $_SESSION['user']?>"/>
<input type="hidden" name="tanggal"value="<?php echo date('d-m-Y'); ?>"/>
<input type="hidden" name="layanan"value="<?php echo $row['nama_layanan']; ?>"/>
<input type="hidden" name="harga"value="<?php echo $row['khusus']; ?>"/>
<input type="hidden" name="per"value="<?php echo $row['per']; ?>"/>
<input type="hidden" name="invoice"value="<?php
function resi(){
$gpass=NULL;
$n = 8; // jumlah karakter yang akan di bentuk.
$chr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
for($i=0;$i<$n;$i++){
$rIdx = rand(1,strlen($chr));
$gpass .=substr($chr,$rIdx,1);
}
return $gpass;
};
echo resi(); 
?>"/>

<table width="100%" style="width:100%;z-index:9999;bottom:0;position:fixed;background-color:#5cb55c;box-shadow: 0 2px 5px rgba(0,0,0,.26);">
<tr>
<td style="font-size:12px;padding:20px;color:#fff"width="50%">
<!---null isi harga-->
</td>
<td style="font-size:17px;padding:20px;color:#fff;"width="50%">
<center>
<button type="submit"name="submit" style="font-weight:bold;color:#fff;background:none;border:none" onclick="javascript:showDiv();">Lanjutkan</button>
</center>
</form>
</td>
</tr>
</table>
<div id="loading" style="display:none">
</div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>
</body>
<?php 	}
 ?>