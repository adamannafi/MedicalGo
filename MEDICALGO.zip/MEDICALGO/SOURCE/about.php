<?php
session_start();
include_once 'dbconnect.php';
if(!isset($_SESSION['user']))
{
	header("Location: fdex.php#login");
}
$res=mysql_query("SELECT * FROM users WHERE id=".$_SESSION['user']);
$rows=mysql_fetch_array($res);
?>
<head><meta charset="UTF-8"/>
<meta http-equiv="refresh" content="90"><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1"><meta name="viewport"content="width=device-width, initial-scale=1.0"><link rel="stylesheet"type="text/css"href="demo.css"/>
<link rel="stylesheet" href="css/bemo.css">
<link rel="stylesheet" href="dist/ladda.min.css">
</head><body onkeydown="javascript:if(window.event.keyCode==13)window.event.keyCode=9">
<div class="sodrops-top"><span class="actions"><ul>
<li><a href="javascript:history.go(0)" onclick="javascript:showDiv();"><img src="refresh.png"width="25px"/></a></li><li><a onclick="javascript:showDiv();" href="home.php#home"><img src="home.png"width="25px"/></a></li>
</ul></span><div style="color:#fff;margin-left:20px;font-size:18px;font-weight:bold;margin-top:5;">
Invoice
</div></div><br>
<?php 
$id_users = $_SESSION['user'];
$view=mysql_query("SELECT * FROM transaksi where transaksi.id_users='$id_users' and aktif='yes'");
$may=mysql_num_rows($view);
if($may=='0')
      {?><br><br>
<center style="color:#f54040;"><br><br><img src="audit.png" width="200px"/><br><small>Halo<br>Sayangnya belum ada layanan berlangsung saat ini</small><br><br>
<a href="home.php#home" onclick="javascript:showDiv();">
<button onclick="javascript:showDiv();" style="width:100%;font-size:15px;height:auto;margin-top:0px;padding-bottom:20px;"class="ladda-button"data-color="blue">Request sekarang</button>
</a>
</center>
	  <?php }
while($row=mysql_fetch_array($view)){
$price= $row['price'];
	?>
  	<?php
if($row['status_trans']=='dijemput')
      {?>
<script>document.location.href="dijemput.php";</script><?php }?>
<?php 
 if($row['status_trans']=='otw')
      { ?>
<script>document.location.href="otw.php";</script>
<?php }	   	} ;?>
<?php
$users = $_SESSION['user'];
$jim=mysql_query("SELECT * FROM transaksi where id_users='$users'");
while($jow=mysql_fetch_array($jim)){
if($jow['status_trans']=='minta')
      { ?>
<script>document.location.href="about.php#about";</script>
<div id="about"class="panel" style="background-color:#fff;overflow:auto"><div class="content" style="font-family:Segoe UI;color:#444;background-color:#fff;padding:10px;width:100%;overflow:auto"><br><br>
<br><center><b style="color:green">Layanan <?php echo $jow["layanan"]; ?></b></center></br></br>
<b><small>Kode Invoice:</small></b><br/><?php echo $jow["invoice"]; ?></br></br>
<b><small>Tanggal Request:</small></b><br/><?php echo $jow['tanggal']; ?></br></br>
<b><small>Jenis Layanan:</small></b><br/><?php echo $jow['layanan']; ?></br></br>
<b><small>Keterangan Keluhan:</small></b><br/><?php echo $jow['keterangan']; ?></br></br>
<b><small>Atas Nama:</small></b><br/><?php echo $jow['nama_rumah']; ?></br></br>
<b><small>No. Handphone:</small></b><br/><?php echo $jow['nomor']; ?></br></br>
<b><small>Alamat Tujuan:</small></b><br/><?php echo $jow['alamat']; ?></br></br>
<b><small>Status Layanan:</small></b><br/>Menunggu Respon <?php echo $jow["layanan"]; ?></br>
<p>
<div class="mop"style="padding:10px;color:#565656;border:1px solid #565656; border-style: dashed;">
<b>Total Biaya: Rp. <?php 
$layanan = $jow['harga'];
$harga = number_format($layanan,0,",",".");
echo $harga;?>
</b></div></p>
<p style="color:#444444"><label>Harga invoice belum termasuk transportasi berdasarkan jarak dari lokasi Medis<br> Mohon Menunggu respon Mitra Medis kami<br>membutuhkan 2-5 menit, selalu klik tombol refresh utk cek status<br> Request yang tidak direspon Medis dalam 24 jam otomatis akan Expired</label></p>
<br>
<center>
<a href="cancel.php?id_trans=<?php echo $jow['id_trans']; ?>" onClick="return confirm('Yakin membatalkan request?')">
<button style="width:100%;font-size:15px;height:auto;margin-top:0px;padding-bottom:20px;"class="ladda-button"data-color="red">Cancel</button>
</a>
</center>
</p>
<br><br>
</div></div>
<style>#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<div id="loading" style="display:none">
</div>
<script type="text/javascript">
        function showDiv() {
            div = document.getElementById('loading');
            div.style.display = "block";
        }
</script>
<?php }
if($jow['status_trans']=='ttd')
      { ?>
<script>document.location.href="home.php#ttd";</script>
	  <?php }
	 }?>
</body>